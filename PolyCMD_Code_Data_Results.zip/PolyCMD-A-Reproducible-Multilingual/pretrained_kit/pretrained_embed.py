"""Second-round pretrained baselines (run on a machine with internet).

Embeds every word of PolyCMD (lexicon.json, 44 languages) and of PolyCMD-U
(lexicon_uncovered.json, 11 languages NOT in the encoders' pretraining data) with the
same three public encoders as before, and saves the raw L2-normalised embeddings.
All evaluation protocols (uncovered languages, family holdout, fusion) are then computed
from these embeddings by pretrained2_analyze.py, so this script has to run only once.

Usage (Windows, in the kit folder):
  pip install sentence-transformers numpy
  python pretrained_embed.py
Output: emb_<model>.npz  (one per model) - send these three files back.
"""
import json, time, numpy as np
from sentence_transformers import SentenceTransformer

MODELS = ['sentence-transformers/LaBSE', 'intfloat/multilingual-e5-base',
          'sentence-transformers/paraphrase-multilingual-mpnet-base-v2']
A = json.load(open('lexicon.json', encoding='utf-8'))
U = json.load(open('lexicon_uncovered.json', encoding='utf-8'))
words = [r['word'] for r in A] + [r['word'] for r in U]
print(len(A), 'PolyCMD words +', len(U), 'PolyCMD-U words')
for name in MODELS:
    t0 = time.time()
    model = SentenceTransformer(name)
    prefix = 'query: ' if 'e5' in name else ''
    E = model.encode([prefix + w for w in words], batch_size=64, normalize_embeddings=True,
                     show_progress_bar=True).astype(np.float32)
    np.savez_compressed(f"emb_{name.split('/')[-1]}.npz", E=E, n_main=len(A))
    print(name, E.shape, f'{time.time() - t0:.0f} s', flush=True)
print('Done - send the three emb_*.npz files back.')
