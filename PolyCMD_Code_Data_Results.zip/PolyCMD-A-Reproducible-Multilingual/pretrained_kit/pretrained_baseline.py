"""Pretrained multilingual baselines for PolyNET (reviewer request).

Runs the SAME leave-one-language-out protocol as the paper: for each test language L,
every word of L is matched against the words of the other 43 languages (memory), and the
concept of the most similar memory words is predicted (nearest neighbour on cosine
similarity of multilingual embeddings). Optionally decoded with mutual exclusivity (ME).

Models (public, Hugging Face):
  sentence-transformers/LaBSE                    (109 languages, ~1.9 GB)
  intfloat/multilingual-e5-base                  (~100 languages, ~1.1 GB)
  sentence-transformers/paraphrase-multilingual-mpnet-base-v2  (50+ languages, ~1.1 GB)

Usage (needs internet once to download the models):
  pip install sentence-transformers scipy numpy
  python pretrained_baseline.py lexicon.json
Output: pretrained_results.json  (per-language accuracy, with and without ME)
        pretrained_scores_<model>.npz  (per-word 43-concept similarity scores, for fusion analysis)
Runs on CPU in about 5-15 minutes per model (1,813 short words).
"""
import sys, json, time, numpy as np
from scipy.optimize import linear_sum_assignment

LEX = sys.argv[1] if len(sys.argv) > 1 else 'lexicon.json'
MODELS = ['sentence-transformers/LaBSE', 'intfloat/multilingual-e5-base',
          'sentence-transformers/paraphrase-multilingual-mpnet-base-v2']
DEV = ['en', 'fr', 'pl', 'tr', 'fa', 'te', 'th', 'he']          # same split as the paper
T = 0.02                                                          # same temperature as the paper's baselines

R = json.load(open(LEX, encoding='utf-8'))
CONCEPTS = sorted({r['concept'] for r in R}); CID = {c: i for i, c in enumerate(CONCEPTS)}; C = len(CONCEPTS)
LANGS = sorted({r['lang'] for r in R}); TEST = [l for l in LANGS if l not in DEV]
words = [r['word'] for r in R]; y = np.array([CID[r['concept']] for r in R]); lang = np.array([r['lang'] for r in R])

def me(P):
    r, c = linear_sum_assignment(-np.log(P + 1e-12)); o = P.argmax(1).copy(); o[r] = c; return o

from sentence_transformers import SentenceTransformer
out = {}
for name in MODELS:
    t0 = time.time()
    model = SentenceTransformer(name)
    prefix = 'query: ' if 'e5' in name else ''                    # E5 models expect a prefix
    E = model.encode([prefix + w for w in words], batch_size=64, normalize_embeddings=True,
                     show_progress_bar=True)
    res = {}; scores = np.zeros((len(words), C), dtype=np.float32)
    for L in LANGS:
        te = np.where(lang == L)[0]; tr = np.where(lang != L)[0]
        S = E[te] @ E[tr].T                                        # cosine similarity
        sc = np.full((len(te), C), -1.0)
        for c in range(C):
            m = y[tr] == c
            if m.any(): sc[:, c] = S[:, m].max(1)
        scores[te] = sc
        P = np.exp((sc - sc.max(1, keepdims=True)) / T); P /= P.sum(1, keepdims=True)
        res[L] = dict(acc=float((sc.argmax(1) == y[te]).mean()), acc_me=float((me(P) == y[te]).mean()), n=len(te))
    mean = lambda k: 100 * np.mean([res[l][k] for l in TEST])
    out[name] = dict(per_lang=res, test_mean_acc=mean('acc'), test_mean_acc_me=mean('acc_me'),
                     seconds=time.time() - t0)
    np.savez_compressed(f"pretrained_scores_{name.split('/')[-1]}.npz", scores=scores, y=y, lang=lang)
    print(f'{name}: {mean("acc"):.1f}% inductive, {mean("acc_me"):.1f}% with ME on {len(TEST)} test languages',
          flush=True)
json.dump(out, open('pretrained_results.json', 'w'), indent=1)
print('Saved pretrained_results.json - send this file (and the .npz files) back for the paper.')
