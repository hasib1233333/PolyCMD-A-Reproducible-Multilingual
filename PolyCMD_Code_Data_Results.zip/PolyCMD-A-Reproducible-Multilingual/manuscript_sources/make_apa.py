"""Writes refs_apa.tex: an alphabetical author-year (APA 7 style) reference list with
natbib labels, so \\citep and \\citet produce (Author, Year) citations.
Only references cited in the manuscript (read from the .aux file) are listed.
Usage: python3 make_apa.py manuscript.aux refs.bib refs_apa.tex"""
import re, sys, bibtexparser
aux, bib, out = sys.argv[1:4]
cited = []
for line in open(aux):
    m = re.match(r'\\citation\{(.+)\}', line)
    if m:
        for k in m.group(1).split(','):
            if k not in cited: cited.append(k)
db = {e['ID']: e for e in bibtexparser.load(open(bib), bibtexparser.bparser.BibTexParser(common_strings=True)).entries}

def clean(s): return re.sub(r'\s+', ' ', s.replace('\n', ' ')).strip()
def nob(s): return re.sub(r'(?<!\\)[{}]', '', s)
def initials(first):
    out = []
    for p in re.split(r'\s+', first.strip()):
        if not p: continue
        pieces = []
        for q in nob(p).replace('.', ' ').split('-'):
            q = q.strip()
            m = re.match(r'(\\[\'"`^~][a-zA-Z]|[^\W\d_])', q)
            if m: pieces.append(m.group(0) + '.')
        if pieces: out.append('-'.join(pieces))
    return ' '.join(out)
def people(e):
    a = e.get('author', '').strip()
    if a.startswith('{') and a.endswith('}') and ' and ' not in a: return [(nob(a), '')], False, True
    names = [clean(x) for x in re.split(r'\s+and\s+', a)]
    etal = names[-1].lower() == 'others'
    if etal: names = names[:-1]
    res = []
    for n in names:
        if ',' in n: last, first = [x.strip() for x in n.split(',', 1)]
        else: parts = n.split(); last, first = parts[-1], ' '.join(parts[:-1])
        res.append((nob(last), initials(first)))
    return res, etal, False
def author_list(ps, etal, corp):
    if corp: return ps[0][0]
    f = [f'{l}, {i}' if i else l for l, i in ps]
    if etal: return ', '.join(f) + ', et al.'
    if len(f) == 1: return f[0]
    return ', '.join(f[:-1]) + ', \\& ' + f[-1]
def short(ps, etal, corp):
    if corp: return ps[0][0]
    if len(ps) == 1 and not etal: return ps[0][0]
    if len(ps) == 2 and not etal: return f'{ps[0][0]} and {ps[1][0]}'
    return f'{ps[0][0]} et~al.'
ent = []
for k in cited:
    e = db[k]; ps, etal, corp = people(e)
    ent.append(dict(k=k, e=e, ps=ps, etal=etal, corp=corp, year=e.get('year', 'n.d.'), sh=short(ps, etal, corp)))
ent.sort(key=lambda x: (nob(x['ps'][0][0]).lower().replace('\\', ''), x['year'], clean(x['e']['title']).lower()))
seen = {}
for x in ent:
    seen.setdefault((x['sh'], x['year']), []).append(x)
for grp in seen.values():
    if len(grp) > 1:
        for i, x in enumerate(grp): x['year'] = x['year'] + 'abcdefgh'[i]
def title(t): return clean(t).rstrip('.')
items = []
for x in ent:
    e = x['e']; typ = e['ENTRYTYPE']
    s = f"{author_list(x['ps'], x['etal'], x['corp'])} ({x['year']}). "
    if typ == 'article':
        j = clean(e.get('journal', ''))
        if j.lower().startswith('arxiv'):
            s += f"{title(e['title'])}. \\textit{{arXiv preprint}} {re.sub(r'(?i)arxiv preprint ', '', j)}."
        else:
            s += f"{title(e['title'])}. \\textit{{{j}}}"
            if 'volume' in e: s += f", \\textit{{{e['volume']}}}"
            if 'number' in e: s += f"({clean(e['number'])})"
            if 'pages' in e: s += f", {clean(e['pages'])}"
            s += '.'
    elif typ == 'inproceedings':
        s += f"{title(e['title'])}. In \\textit{{{clean(e['booktitle'])}}}"
        if 'pages' in e: s += f" (pp.~{clean(e['pages'])})"
        s += '.'
    else:
        s += f"\\textit{{{title(e['title'])}}}."
        if 'howpublished' in e: s += ' ' + clean(e['howpublished']).rstrip('.') + '.'
        if 'note' in e: s += ' ' + clean(e['note']).rstrip('.') + '.'
    if 'doi' in e: s += f" \\url{{https://doi.org/{e['doi']}}}"
    elif 'url' in e: s += f" \\url{{{e['url']}}}"
    lab = f"{x['sh']}({x['year']}){author_list(x['ps'], x['etal'], x['corp'])}"
    items.append(f"\\bibitem[{{{x['sh']}}}({x['year']})]{{{x['k']}}}\n{s}")
with open(out, 'w') as f:
    f.write('\\begin{thebibliography}{%d}\n' % len(items) + '\n\n'.join(items) + '\n\\end{thebibliography}\n')
print(len(items), 'references (alphabetical, author-year)')
