PolyNET - Language Resources and Evaluation manuscript, LaTeX sources
Main file: manuscript.tex (pdfLaTeX). Body: body.tex and sec_*.tex; tables: tab_*.tex; figures: fig_*.pdf, fig_flow.tex, fig_arch.tex.
References: author-year (APA 7 style), alphabetical, in refs_apa.tex (generated from refs.bib by make_apa.py).
Compile:
  pdflatex manuscript
  python3 make_apa.py manuscript.aux refs.bib refs_apa.tex   (only if citations change)
  pdflatex manuscript
  pdflatex manuscript
