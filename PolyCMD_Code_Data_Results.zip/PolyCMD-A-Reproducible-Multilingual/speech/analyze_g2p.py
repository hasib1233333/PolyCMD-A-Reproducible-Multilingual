"""Section 'How phonetic is the romanised code?': tables, figure and macros."""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import sys, os, json, glob, numpy as np, matplotlib
sys.path.insert(0, TEXT_DIR); os.chdir(TEXT_DIR)
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import Counter, defaultdict
from scipy.stats import wilcoxon, spearmanr
exec(open('figures.py').read().split("D = {json")[0])
from common import R, TEST
P = TEXT_DIR + '/paper/'
G = {json.load(open(f))['lang']: json.load(open(f)) for f in glob.glob(SPEECH_DIR + '/outg2p/fold_*.json')}
LS = [l for l in TEST if l in G]
NOV = {'ja', 'tg', 'vi'}                       # no eSpeak voice: pronunciation = romanisation
LV = [l for l in LS if l not in NOV]
scr = {l: Counter(r['script'] for r in R if r['lang'] == l).most_common(1)[0][0] for l in LS}
K = ['rom', 'pho', 'hyb_rom', 'hyb_pho']
NAME = {'rom': 'romanised $\\to$ romanised (PolyNET)', 'pho': 'pronunciation $\\to$ pronunciation',
        'hyb_rom': 'both in memory $\\to$ romanised', 'hyb_pho': 'both in memory $\\to$ pronunciation'}
acc = lambda k, ls=LV: np.array([G[l][k] for l in ls])
st = {'n': len(LV)}
with open(P + 'tab_g2p.tex', 'w') as f:
    best = max(100 * acc(k + '+ME').mean() for k in K); best_i = max(100 * acc(k).mean() for k in K)
    for k in K:
        a, b = 100 * acc(k).mean(), 100 * acc(k + '+ME').mean()
        pa = '' if k == 'rom' else wilcoxon(acc(k + '+ME'), acc('rom+ME'), zero_method='zsplit').pvalue
        A = f'\\textbf{{{a:.1f}}}' if abs(a - best_i) < 1e-9 else f'{a:.1f}'
        B = f'\\textbf{{{b:.1f}}}' if abs(b - best) < 1e-9 else f'{b:.1f}'
        def sci(x):
            e = int(np.floor(np.log10(x))); return f'${x / 10 ** e:.2f}\\times10^{{{e}}}$'
        f.write(f"{NAME[k]} & {A} & {B} & {'--' if k == 'rom' else sci(pa)} \\\\\n")
        st[k] = (a, b); st['p_' + k] = None if k == 'rom' else float(pa)
        st['wl_' + k] = (int((acc(k + '+ME') > acc('rom+ME')).sum()), int((acc(k + '+ME') < acc('rom+ME')).sum()))
sim = {l: G[l]['rom_pho_sim'] for l in LV}; eq = {l: G[l]['rom_eq_pho'] for l in LV}
st['sim_mean'] = float(np.mean(list(sim.values()))); st['eq_mean'] = float(np.mean(list(eq.values())))
d = np.array([G[l]['pho+ME'] - G[l]['rom+ME'] for l in LV]); s = np.array([sim[l] for l in LV])
rho = spearmanr(s, d); st['rho'] = float(rho.correlation); st['rho_p'] = float(rho.pvalue)
by = defaultdict(list)
for l in LV: by[scr[l]].append(l)
S = sorted(by, key=lambda x: np.mean([sim[l] for l in by[x]]))
st['by_script'] = {x: dict(n=len(by[x]), sim=float(np.mean([sim[l] for l in by[x]])),
                           rom=float(100 * np.mean([G[l]['rom+ME'] for l in by[x]])),
                           pho=float(100 * np.mean([G[l]['pho+ME'] for l in by[x]])),
                           hyb=float(100 * np.mean([G[l]['hyb_pho+ME'] for l in by[x]]))) for x in S}
st['lang_sim'] = {l: sim[l] for l in LV}
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.2), gridspec_kw={'wspace': .3, 'width_ratios': [1, 1.3]})
axs[0].barh(range(len(S)), [st['by_script'][x]['sim'] for x in S], .6, color=BLUE)
for i, x in enumerate(S):
    axs[0].text(st['by_script'][x]['sim'] + .01, i, f"{st['by_script'][x]['sim']:.2f}", va='center', fontsize=6)
axs[0].set_yticks(range(len(S)), [f'{x} ({len(by[x])})' for x in S]); axs[0].set_xlim(0, 1.05)
axs[0].set_xlabel('AWED similarity, romanisation vs. pronunciation'); axs[0].grid(axis='y', visible=False)
axs[0].set_title('(a) How phonetic is romanisation?')
x = np.arange(len(S)); w = .27
for i, (k, c, lab) in enumerate((('rom', GRAY, 'romanised (PolyNET)'), ('pho', ORANGE, 'pronunciation (G2P)'),
                                 ('hyb', BLUE, 'both in memory, G2P query'))):
    axs[1].bar(x + (i - 1) * w, [st['by_script'][s_][k] for s_ in S], w * .92, color=c, label=lab)
axs[1].set_xticks(x, S, rotation=35, fontsize=6); axs[1].set_ylim(0, 128); axs[1].set_yticks(range(0, 101, 20)); axs[1].set_ylabel('Accuracy + ME (%)')
axs[1].set_title('(b) Accuracy by script, unseen languages'); axs[1].grid(axis='x', visible=False)
axs[1].legend(frameon=False, fontsize=5.5, ncol=3, loc='upper center', bbox_to_anchor=(.5, 1.0))
fig.savefig(P + 'fig_g2p.pdf'); plt.close()
json.dump(st, open(SPEECH_DIR + '/results_g2p.json', 'w'), indent=1)
print(json.dumps(st, indent=1))
