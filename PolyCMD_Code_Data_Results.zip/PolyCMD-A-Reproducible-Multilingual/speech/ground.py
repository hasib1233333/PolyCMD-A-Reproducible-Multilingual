"""Speech grounding experiments (leave-one-language-out, as in the text study).

For every held-out language L the models are trained on the other 43 languages
only. The test input is the phone string that Allosaurus recognises from audio.

Models (all share PolyNET's fusion weights and temperature, fixed in advance):
  text   PolyNET trained on romanised text only (the paper's model, unchanged)
  pho    PolyNET whose training words are eSpeak-NG IPA transcriptions (g2p)
  hyb    PolyNET-S: training memory holds both forms of every word  [proposed]
  base_* n-gram kNN / edit-distance NN / AWED NN on the hyb memory
Usage: python3 ground.py <lang> ...   -> out/fold_<lang>.npz
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import sys, os, json, numpy as np
sys.path.insert(0, TEXT_DIR); sys.path.insert(0, SPEECH_DIR)
os.chdir(TEXT_DIR)
from common import R, CONCEPTS, CID, C, softmax_sim
from models import PolyNET2, WindowNet, NgramKNN, skeleton, romanize
from phon import ipa2lat, FastAWED
from rapidfuzz.process import cdist
from rapidfuzz.distance import Levenshtein
os.chdir(SPEECH_DIR); os.makedirs('out', exist_ok=True)

TUNE = json.load(open(TEXT_DIR + '/results/tuned.json'))
W = tuple(TUNE['weights']); T = TUNE['T']; TS = (1, T, T, T)
VOICE = {'no': 'nb', 'kz': 'kk'}; NO_VOICE = {'ja', 'tg', 'vi'}

def build_pho():
    """eSpeak-NG grapheme-to-phoneme for every lexicon word (cached)."""
    f = 'cache/g2p.json'
    if os.path.exists(f): return json.load(open(f))
    import espeak
    P = {}
    for r in R:
        k = f"{r['lang']}|{r['concept']}"
        P[k] = ipa2lat(espeak.g2p(r['word'], VOICE.get(r['lang'], r['lang']))) if r['lang'] not in NO_VOICE \
            else romanize(r['word'])
    json.dump(P, open(f, 'w'), ensure_ascii=False); return P
PHO = build_pho()

class PolyNETS(PolyNET2):
    """PolyNET on pre-encoded (a-z) strings; AWED view compiled for speed."""
    def fit(self, words, y, C):
        self.C = C
        self.views = {0: WindowNet(mode='phon', **self.net_kw).fit(words, y, C),
                      1: NgramKNN(romanize).fit(words, y, C),
                      2: NgramKNN(lambda w: skeleton(romanize(w)), n=(1, 2)).fit(words, y, C),
                      3: FastAWED().fit(words, y, C)}
        return self

class EditFast:
    def fit(self, words, y, C): self.W = list(words); self.y = np.asarray(y); self.C = C; return self
    def scores(self, q):
        S = cdist(q, self.W, scorer=Levenshtein.normalized_similarity)
        out = np.full((len(q), self.C), -1.0)
        for c in range(self.C):
            m = self.y == c
            if m.any(): out[:, c] = S[:, m].max(1)
        return out

def train_sets(exclude):
    tr = [r for r in R if r['lang'] not in exclude]
    rom = [romanize(r['word']) for r in tr]; pho = [PHO[f"{r['lang']}|{r['concept']}"] for r in tr]
    y = [CID[r['concept']] for r in tr]
    return {'text': (rom, y), 'pho': (pho, y), 'hyb': (rom + pho, y + y)}

def score_all(sets, Q):
    out = {}
    for k in ('text', 'pho', 'hyb'):
        m = PolyNETS(W, TS, net_kw=dict(epochs=60), seed=0).fit(*sets[k], C)
        V = m.view_scores(Q)                              # per-view scores, for speech-condition fusion tuning
        out[k] = m.fuse(V).astype(np.float32)
        for v in range(4): out[f'{k}_view{v}'] = V[v].astype(np.float32)
    w, y = sets['hyb']
    out['base_ngram'] = softmax_sim(NgramKNN(romanize).fit(w, y, C).scores(Q), T).astype(np.float32)
    out['base_edit'] = softmax_sim(EditFast().fit(w, y, C).scores(Q), T).astype(np.float32)
    out['base_awed'] = softmax_sim(FastAWED().fit(w, y, C).scores(Q), T).astype(np.float32)
    return out

def load(fn): return [json.loads(l) for l in open(fn)]

def run(L):
    if L == 'en_real':                       # real voices; English held out, plus an in-vocabulary reference
        U = load('cache/amnist.jsonl') + load('cache/fsdd.jsonl')
        Q = [ipa2lat(u['phones']) for u in U]
        res = score_all(train_sets({'en'}), Q)
        ref = score_all(train_sets(set()), Q)        # English words available (not zero-shot)
        res.update({f'invocab_{k}': v for k, v in ref.items() if k.startswith(('hyb', 'pho', 'base_awed'))})
        meta = dict(y=[CID[u['concept']] for u in U], dataset=[u['dataset'] for u in U],
                    speaker=[u['speaker'] for u in U], rep=[u['rep'] for u in U], q=Q)
    else:
        U = [u for f in ('cache/synth_0.jsonl', 'cache/synth_1.jsonl') for u in load(f) if u['lang'] == L]
        Q = [ipa2lat(u['phones']) for u in U]
        res = score_all(train_sets({L}), Q)
        meta = dict(y=[CID[u['concept']] for u in U], voice=[u['voice'] for u in U],
                    snr=[-1 if u['snr'] is None else u['snr'] for u in U], q=Q)
    np.savez_compressed(f'out/fold_{L}.npz', **res, meta=json.dumps(meta))
    print(L, len(Q), {k: round(float((v.argmax(1) == np.array(meta['y'])).mean()), 3) for k, v in res.items()
                      if 'view' not in k}, flush=True)

if __name__ == '__main__':
    for L in sys.argv[1:]: run(L)
