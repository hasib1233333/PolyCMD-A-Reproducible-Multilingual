"""Speech-condition fusion (PolyNET-S): choose memory type, view weights and
temperature on the development languages' SYNTHETIC speech only
(fr, pl, tr, fa, te, th, he; English is excluded because its real recordings are
a test set). Baseline temperatures are tuned the same way, so every method gets
the same amount of tuning. Writes speech_tuned.json and out2/fold_*.npz with
the tuned PolyNET-S ('polys') and tuned baselines ('*_t').
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import sys, os, json, glob, itertools, numpy as np
sys.path.insert(0, TEXT_DIR); os.chdir(TEXT_DIR)
from common import R, CONCEPTS, DEV
from models import mutual_exclusivity
os.chdir(SPEECH_DIR); os.makedirs('out2', exist_ok=True)
CAT = {r['concept']: r['category'] for r in R}
MASK = {c: np.array([CAT[k] == c for k in CONCEPTS]) for c in ('number', 'unit', 'weekday', 'month')}
TDEV = [l for l in DEV if l != 'en']

def slotmask(P, y):
    P = P.copy()
    for i, t in enumerate(y): P[i, ~MASK[CAT[CONCEPTS[t]]]] = 1e-30
    return P / P.sum(1, keepdims=True)

def fuse(z, mem, w, T):
    L = w[0] * z[f'{mem}_view0'].astype(float)
    for v in (1, 2, 3):
        if w[v]: L = L + w[v] * z[f'{mem}_view{v}'].astype(float) / T
    L -= L.max(1, keepdims=True); P = np.exp(L); return P / P.sum(1, keepdims=True)

def retemp(P, T_old, T_new):
    L = np.log(np.maximum(P.astype(float), 1e-38)) * (T_old / T_new)
    L -= L.max(1, keepdims=True); Q = np.exp(L); return Q / Q.sum(1, keepdims=True)

def groups(m):
    v = np.array(m['voice']); s = np.array(m['snr'])
    return [np.where((v == a) & (s == b))[0] for a in ('v1', 'v2') for b in (-1, 20, 10, 5)]

def score(P, y, G):
    return np.mean([(mutual_exclusivity(slotmask(P[g], y[g])) == y[g]).mean() for g in G])

if __name__ == '__main__':
    F = {}
    for L in TDEV:
        z = np.load(f'out/fold_{L}.npz', allow_pickle=True); m = json.loads(str(z['meta']))
        F[L] = (z, np.array(m['y']), groups(m))
    best = []
    for mem, w0, w1, w2, w3, T in itertools.product(('text', 'pho', 'hyb'), (0, .5, 1), (0, .5, 1), (0, .25, .5),
                                                    (0, .5, 1), (.02, .05, .1, .2, .5)):
        if w1 + w2 + w3 == 0 and w0 == 0: continue
        a = np.mean([score(fuse(z, mem, (w0, w1, w2, w3), T), y, G) for z, y, G in F.values()])
        best.append((a, mem, (w0, w1, w2, w3), T))
    best.sort(key=lambda b: -b[0])
    bt = {}
    for k in ('base_ngram', 'base_edit', 'base_awed'):
        r = [(np.mean([score(retemp(z[k], .02, T), y, G) for z, y, G in F.values()]), T) for T in (.02, .05, .1, .2, .5)]
        bt[k] = max(r)[1]; print(k, r)
    cfg = dict(mem=best[0][1], w=best[0][2], T=best[0][3], dev_acc=best[0][0], base_T=bt, dev_langs=TDEV,
               top5=[(float(a), m_, list(w), t) for a, m_, w, t in best[:5]])
    json.dump(cfg, open('speech_tuned.json', 'w'), indent=1); print(json.dumps(cfg, indent=1))
    for f in glob.glob('out/fold_*.npz'):
        z = np.load(f, allow_pickle=True); d = {k: z[k] for k in z.files}
        d['polys'] = fuse(z, cfg['mem'], cfg['w'], cfg['T']).astype(np.float32)
        zz = {k[8:]: z[k] for k in z.files if k.startswith('invocab_')}
        if f"{cfg['mem']}_view0" in zz:
            d['invocab_polys'] = fuse(zz, cfg['mem'], cfg['w'], cfg['T']).astype(np.float32)
        for k, T in bt.items():
            d[k + '_t'] = retemp(z[k], .02, T).astype(np.float32)
            if 'invocab_' + k in z.files: d['invocab_' + k + '_t'] = retemp(z['invocab_' + k], .02, T).astype(np.float32)
        d = {k: v for k, v in d.items() if 'view' not in k}
        np.savez_compressed(f.replace('out/', 'out2/'), **d)
