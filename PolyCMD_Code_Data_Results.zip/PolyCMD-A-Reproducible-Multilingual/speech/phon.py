"""IPA <-> PolyNET phonological code, and a compiled AWED nearest-neighbour.

ipa2lat maps an IPA string (from the Allosaurus phone recogniser or from
eSpeak-NG grapheme-to-phoneme) onto the same lowercase Latin alphabet that
PolyNET's romanisation bridge produces, so that speech and text share one code.
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import sys, unicodedata, re, numpy as np
sys.path.insert(0, TEXT_DIR)
from models import ALPHA, VOW, _SUB, _indel

# multi-character IPA units first (affricates, digraphs), then single symbols
MULTI = [('t͡ʃ', 'c'), ('tʃ', 'c'), ('d͡ʒ', 'j'), ('dʒ', 'j'), ('t͡ɕ', 'c'), ('tɕ', 'c'), ('d͡ʑ', 'j'),
         ('dʑ', 'j'), ('t͡s', 'ts'), ('ts', 'ts'), ('d͡z', 'dz'), ('k͡p', 'k'), ('kp', 'k'), ('ɡ͡b', 'g'), ('gb', 'g'), ('ʈʂ', 'c'),
         ('tʂ', 'c')]
SINGLE = {
 # vowels
 'a': 'a', 'ɑ': 'a', 'ɐ': 'a', 'æ': 'a', 'ɒ': 'a', 'ʌ': 'a', 'ɶ': 'a',
 'e': 'e', 'ɛ': 'e', 'ə': 'e', 'ә': 'e', 'ɜ': 'e', 'ɘ': 'e', 'ɞ': 'e', 'ε': 'e', 'ø': 'e', 'œ': 'e',
 'i': 'i', 'ɪ': 'i', 'ɨ': 'i', 'y': 'i', 'ʏ': 'i', 'ɯ': 'u', 'ɤ': 'o',
 'o': 'o', 'ɔ': 'o', 'ɵ': 'o',
 'u': 'u', 'ʊ': 'u', 'ʉ': 'u',
 # consonants
 'p': 'p', 'b': 'b', 'ɓ': 'b', 'm': 'm', 'ɱ': 'm', 'f': 'f', 'ɸ': 'f', 'v': 'v', 'β': 'v', 'ʋ': 'v', 'w': 'w',
 'ɥ': 'w', 'ʍ': 'w', 't': 't', 'ʈ': 't', 'd': 'd', 'ɖ': 'd', 'ɗ': 'd', 'n': 'n', 'ɳ': 'n', 'ɲ': 'n',
 'ŋ': 'n', 'ɴ': 'n', 'θ': 't', 'ð': 'd', 's': 's', 'z': 'z', 'ʃ': 's', 'ʒ': 'z', 'ɕ': 's', 'ʑ': 'z',
 'ʂ': 's', 'ʐ': 'z', 'ç': 'h', 'ʝ': 'j', 'x': 'x', 'ɣ': 'g', 'χ': 'x', 'ʁ': 'r', 'ħ': 'h', 'ʕ': '',
 'h': 'h', 'ɦ': 'h', 'l': 'l', 'ɫ': 'l', 'ɭ': 'l', 'ʎ': 'l', 'ʟ': 'l', 'ɬ': 'l', 'ɮ': 'l',
 'r': 'r', 'ɾ': 'r', 'ɹ': 'r', 'ɻ': 'r', 'ɽ': 'r', 'ʀ': 'r', 'ɺ': 'r', 'j': 'j', 'c': 'k', 'ɟ': 'g',
 'k': 'k', 'g': 'g', 'ɡ': 'g', 'q': 'q', 'ɢ': 'g', 'ʔ': '', 'ʡ': '', 'ʄ': 'g', 'ɠ': 'g',
}

def ipa2lat(s):
    s = unicodedata.normalize('NFD', s or '')
    s = ''.join(ch for ch in s if not unicodedata.combining(ch))      # drop diacritics/ties
    s = re.sub(r'[ˈˌːˑ\.\|‖\-\(\)\d\s̚ʰʲʷˠˤʼ̃͡]', '', s)            # stress, length, tones, secondary art.
    out, i = [], 0
    while i < len(s):
        for a, b in MULTI:
            if s.startswith(a, i):
                out.append(b); i += len(a); break
        else:
            out.append(SINGLE.get(s[i], '')); i += 1
    r = ''.join(out)
    r = re.sub(r'(.)\1+', r'\1', r)                                     # geminates / repeats
    return r or '?'

# ------------------------------------------------------------- compiled AWED
import numba
CH = {c: i for i, c in enumerate(ALPHA)}; UNK = 26
SUB = np.ones((27, 27))
for a in ALPHA:
    for b in ALPHA:
        SUB[CH[a], CH[b]] = _SUB[(a, b)]
SUB[UNK, UNK] = 0
IND = np.array([_indel(c) for c in ALPHA] + [1.0])

def enc(s): return np.array([CH.get(c, UNK) for c in s], dtype=np.int64)

@numba.njit(cache=True)
def _awed(a, b, SUB, IND):
    prev = np.zeros(len(b) + 1)
    for j in range(len(b)): prev[j + 1] = prev[j] + IND[b[j]]
    cur = np.zeros(len(b) + 1)
    for i in range(len(a)):
        cur[0] = prev[0] + IND[a[i]]
        for j in range(len(b)):
            x = prev[j + 1] + IND[a[i]]; y = cur[j] + IND[b[j]]; z = prev[j] + SUB[a[i], b[j]]
            cur[j + 1] = min(x, min(y, z))
        prev, cur = cur, prev
    return prev[len(b)]

@numba.njit(cache=True)
def _scores(q, qn, T, Tn, Toff, ylab, C, SUB, IND):
    out = np.full(C, -1.0)
    for k in range(len(Tn)):
        t = T[Toff[k]:Toff[k] + Tn[k]]
        tn = 0.0
        for c in t: tn += IND[c]
        s = 1.0 - _awed(q, t, SUB, IND) / max(qn, tn)
        if s > out[ylab[k]]: out[ylab[k]] = s
    return out

class FastAWED:
    """Same scores as models.AWEDNN on already-encoded (a-z) strings."""
    def fit(self, words, y, C):
        self.C = C; self.W = list(words); self.y = np.asarray(y); self._pack(); return self
    def add(self, words, y):
        self.W += list(words); self.y = np.r_[self.y, y]; self._pack()
    def _pack(self):
        E = [enc(w) for w in self.W]
        self.Tn = np.array([len(e) for e in E]); self.Toff = np.r_[0, np.cumsum(self.Tn)[:-1]]
        self.T = np.concatenate(E)
    def scores(self, words):
        out = np.zeros((len(words), self.C)); cache = {}
        for i, w in enumerate(words):
            if w not in cache:
                q = enc(w); qn = float(IND[q].sum())
                cache[w] = _scores(q, qn, self.T, self.Tn, self.Toff, self.y, self.C, SUB, IND)
            out[i] = cache[w]
        return out
