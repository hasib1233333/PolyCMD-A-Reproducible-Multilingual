"""Does PolyNET's romanised code behave like pronunciation? (text input)

Leave-one-language-out, same languages, fusion weights and decoding as the text study,
with four input codes for training memory -> test word:
  rom      romanisation (anyascii)            -> romanisation     [paper's model]
  pho      eSpeak-NG G2P pronunciation        -> G2P pronunciation
  hyb_rom  both forms in memory               -> romanisation
  hyb_pho  both forms in memory               -> G2P pronunciation
G2P of the *test* language is an extra assumption (a pronunciation dictionary or rules
for that language must exist); ja, tg, vi have no eSpeak voice and keep romanisation.
Also measures how close romanisation is to pronunciation (AWED similarity rom vs pho).
Usage: python3 text_g2p.py <lang> ... -> outg2p/fold_<lang>.json
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import sys, os, json, numpy as np
sys.path.insert(0, SPEECH_DIR); sys.path.insert(0, TEXT_DIR)
import ground                                       # PHO cache, PolyNETS, W/TS (chdir inside)
from ground import PHO, PolyNETS, W, TS
os.chdir(TEXT_DIR)
from common import R, CID, C
from models import romanize, mutual_exclusivity, awed, _indel
os.makedirs(SPEECH_DIR + '/outg2p', exist_ok=True)

def enc(r, kind):
    return romanize(r['word']) if kind == 'rom' else PHO[f"{r['lang']}|{r['concept']}"]

def run(L):
    tr = [r for r in R if r['lang'] != L]; te = [r for r in R if r['lang'] == L]
    y = [CID[r['concept']] for r in tr]; yt = np.array([CID[r['concept']] for r in te])
    out = {'lang': L, 'n': len(te)}
    models = {}
    for mem in ('rom', 'pho', 'hyb'):
        words = [enc(r, 'rom') for r in tr] if mem == 'rom' else [enc(r, 'pho') for r in tr] if mem == 'pho' \
            else [enc(r, 'rom') for r in tr] + [enc(r, 'pho') for r in tr]
        models[mem] = PolyNETS(W, TS, net_kw=dict(epochs=60), seed=0).fit(words, y if mem != 'hyb' else y + y, C)
    for name, mem, q in (('rom', 'rom', 'rom'), ('pho', 'pho', 'pho'), ('hyb_rom', 'hyb', 'rom'), ('hyb_pho', 'hyb', 'pho')):
        P = models[mem].scores([enc(r, q) for r in te])
        out[name] = float((P.argmax(1) == yt).mean()); out[name + '+ME'] = float((mutual_exclusivity(P) == yt).mean())
    sims = []
    for r in te:
        a, b = enc(r, 'rom'), enc(r, 'pho')
        sims.append(1 - awed(a, b) / max(sum(map(_indel, a)), sum(map(_indel, b))))
    out['rom_pho_sim'] = float(np.mean(sims)); out['rom_eq_pho'] = float(np.mean([enc(r, 'rom') == enc(r, 'pho') for r in te]))
    json.dump(out, open(f'{SPEECH_DIR}/outg2p/fold_{L}.json', 'w'))
    print(L, {k: round(v, 3) for k, v in out.items() if isinstance(v, float)}, flush=True)

if __name__ == '__main__':
    for L in sys.argv[1:]: run(L)
