"""Speech front end. Produces cached phone recognitions (Allosaurus, universal
'uni2005' model, language-independent IPA inventory) for

  synth : every PolyCMD word in every language with an eSpeak-NG voice, two
          voices x four noise levels (clean, 20, 10, 5 dB SNR white noise)
  fsdd  : Free Spoken Digit Dataset (real voices, 6 speakers, 8 kHz), digits 1-9
  amnist: AudioMNIST (real voices, 60 speakers, 48 kHz), digits 1-9, 10 reps

Usage: python3 recognize.py synth <shard> <nshards> | fsdd | amnist
Output: cache/<name>.jsonl  (one JSON record per utterance)
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import sys, os, json, glob, zlib, numpy as np, soundfile as sf
from scipy.signal import resample_poly
sys.path.insert(0, TEXT_DIR)
os.makedirs('cache', exist_ok=True)
from allosaurus.app import read_recognizer
REC = read_recognizer('uni2005')
import tempfile
TMP = os.path.join(tempfile.gettempdir(), f'rec_{os.getpid()}.wav')

def recognise(y16):
    y = y16 / (np.abs(y16).max() + 1e-9) * 0.9
    y = np.r_[np.zeros(1600), y, np.zeros(1600)]
    sf.write(TMP, y, 16000, subtype='PCM_16')
    return REC.recognize(TMP)

VOICE = {'no': 'nb', 'kz': 'kk'}
NO_VOICE = {'ja', 'tg', 'vi'}          # unsupported by eSpeak-NG (script or voice missing)
VOICES = [('v1', '', 160, 50), ('v2', '+f2', 200, 70)]
SNRS = [None, 20, 10, 5]

def synth(shard, nshards):
    import espeak
    R = json.load(open(TEXT_DIR + '/lexicon.json'))
    items = [r for r in R if r['lang'] not in NO_VOICE]
    items = items[shard::nshards]
    out = open(f'cache/synth_{shard}.jsonl', 'w')
    for k, r in enumerate(items):
        base = VOICE.get(r['lang'], r['lang'])
        for vid, var, rate, pitch in VOICES:
            x = espeak.synth(r['word'], base + var, rate, pitch).astype(float) / 32768
            y = resample_poly(x, 320, 441)                   # 22.05 kHz -> 16 kHz
            rng = np.random.default_rng(zlib.crc32(f"{r['lang']}|{r['concept']}|{vid}".encode()))
            for snr in SNRS:
                z = y.copy()
                if snr is not None:
                    p = np.mean(y ** 2); z = y + rng.normal(0, np.sqrt(p / 10 ** (snr / 10)), len(y))
                out.write(json.dumps(dict(lang=r['lang'], concept=r['concept'], word=r['word'], voice=vid,
                                          snr=snr, phones=recognise(z)), ensure_ascii=False) + '\n')
        if k % 50 == 0: out.flush(); print(shard, k, len(items), flush=True)
    out.close()

def real(name):
    out = open(f'cache/{name}.jsonl', 'w')
    if name == 'fsdd':
        files = sorted(glob.glob('data/fsdd/recordings/[1-9]_*.wav'))
    else:
        files = sorted(glob.glob('data/amnist/data/*/[1-9]_*_[0-9].wav'))
    for k, f in enumerate(files):
        d, spk, rep = os.path.basename(f)[:-4].split('_')
        x, sr = sf.read(f)
        if x.ndim > 1: x = x.mean(1)
        y = resample_poly(x, 2, 1) if sr == 8000 else resample_poly(x, 1, 3) if sr == 48000 else x
        out.write(json.dumps(dict(dataset=name, digit=int(d), speaker=spk, rep=int(rep),
                                  concept=f'num_{int(d)}', phones=recognise(y))) + '\n')
        if k % 500 == 0: out.flush(); print(name, k, len(files), flush=True)
    out.close()

if __name__ == '__main__':
    if sys.argv[1] == 'synth': synth(int(sys.argv[2]), int(sys.argv[3]))
    else: real(sys.argv[1])
