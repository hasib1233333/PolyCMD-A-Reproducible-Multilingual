"""Speech results: tables, figures and LaTeX macros for the paper."""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import sys, os, json, glob, numpy as np, matplotlib
sys.path.insert(0, TEXT_DIR)
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import Counter, defaultdict
from scipy.stats import wilcoxon
os.chdir(TEXT_DIR)
exec(open('figures.py').read().split("D = {json")[0])           # shared IEEE style + palette
from common import R, CONCEPTS, CID, TEST, DEV
from models import mutual_exclusivity
os.chdir(SPEECH_DIR)
PAPER = TEXT_DIR + '/paper/'

CAT = {r['concept']: r['category'] for r in R}
CATS = ['number', 'unit', 'weekday', 'month']
MASK = {c: np.array([CAT[k] == c for k in CONCEPTS]) for c in CATS}
METH = [('base_ngram_t', 'n-gram kNN'), ('base_edit_t', 'Edit-distance NN'),
        ('base_awed_t', 'AWED NN'), ('text', 'PolyNET (text fusion, text memory)'),
        ('hyb', 'PolyNET (text fusion, text+IPA memory)'), ('polys', 'PolyNET-S (speech-tuned fusion)')]

def decode(P, y, slot, me):
    """slot: restrict candidates to the category of the expected slot."""
    P = P.astype(float).copy()
    if slot:
        cats = [CAT[CONCEPTS[t]] for t in y]
        for i, c in enumerate(cats): P[i, ~MASK[c]] = 1e-12
        P /= P.sum(1, keepdims=True)
    return mutual_exclusivity(P) if me else P.argmax(1)

def fold(L):
    z = np.load(f'out2/fold_{L}.npz', allow_pickle=True); meta = json.loads(str(z['meta']))
    return {k: z[k] for k in z.files if k != 'meta'}, meta

# ======================================================= synthetic speech, LOLO
SYN = sorted(os.path.basename(f)[5:-4] for f in glob.glob('out2/fold_*.npz') if 'real' not in f)
SYN_T = [l for l in SYN if l in TEST]
acc = defaultdict(dict)          # acc[(L, voice, snr)][(meth, slot, me)]
for L in SYN:
    P, m = fold(L); y = np.array(m['y']); v = np.array(m['voice']); s = np.array(m['snr'])
    for vo in ('v1', 'v2'):
        for sn in (-1, 20, 10, 5):
            idx = np.where((v == vo) & (s == sn))[0]
            for k, _ in METH:
                for slot in (0, 1):
                    for me in (0, 1):
                        acc[(L, vo, sn)][(k, slot, me)] = float((decode(P[k][idx], y[idx], slot, me) == y[idx]).mean())

def mean_acc(langs, k, slot, me, snrs=(-1,), voices=('v1', 'v2')):
    return 100 * np.mean([acc[(L, vo, sn)][(k, slot, me)] for L in langs for vo in voices for sn in snrs])

def per_lang(langs, k, slot, me, snrs=(-1,)):
    return np.array([np.mean([acc[(L, vo, sn)][(k, slot, me)] for vo in ('v1', 'v2') for sn in snrs]) for L in langs])

# text-input reference (same languages, same model family) from the text study
TXT = {json.load(open(f))['lang']: json.load(open(f))['acc'] for f in glob.glob(TEXT_DIR + '/results/fold_*.json')}

# ---- Table: synthetic speech, clean
with open(PAPER + 'tab_speech_syn.tex', 'w') as f:
    cols = [(0, 0), (0, 1), (1, 0), (1, 1)]
    vals = {k: [mean_acc(SYN_T, k, s, e) for s, e in cols] for k, _ in METH}
    best = [max(vals[k][j] for k, _ in METH) for j in range(4)]
    for i, (k, n) in enumerate(METH):
        if i == 3: f.write('\\midrule\n')
        cells = [f'\\textbf{{{x:.1f}}}' if abs(x - b) < 1e-9 else f'{x:.1f}' for x, b in zip(vals[k], best)]
        f.write(n + ' & ' + ' & '.join(cells) + ' \\\\\n')
    f.write('\\midrule\n')
    f.write('Text input (PolyNET, Sec.~\\ref{sec:exp}) & ' + f"{100*np.mean([TXT[l]['polynet'] for l in SYN_T]):.1f} & "
            f"{100*np.mean([TXT[l]['polynet+ME'] for l in SYN_T]):.1f} & -- & -- \\\\\n")

# significance: hyb vs best baseline (slot+ME, clean), and hyb vs text memory
st = {}
bb = max(['base_ngram_t', 'base_edit_t', 'base_awed_t'], key=lambda k: mean_acc(SYN_T, k, 1, 1))
a = per_lang(SYN_T, 'polys', 1, 1); b = per_lang(SYN_T, bb, 1, 1); c = per_lang(SYN_T, 'text', 1, 1)
st['syn_best_base'] = bb
st['p_syn_hyb_base'] = wilcoxon(a, b, alternative='greater').pvalue
st['p_syn_hyb_text'] = wilcoxon(a, c, alternative='greater').pvalue
st['syn_wins'] = int((a > b).sum()); st['syn_losses'] = int((a < b).sum())
st['n_syn'] = len(SYN_T)

# ---- Figure: accuracy vs SNR (slot+ME) and per-category bars
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.3), gridspec_kw={'wspace': .28})
xs = ['clean', '20', '10', '5']; sn = [-1, 20, 10, 5]
sty = {'base_ngram_t': (YELLOW, 'v', ':'), 'base_edit_t': (AQUA, '^', '--'), 'base_awed_t': (ORANGE, 's', '--'),
       'text': (GRAY, 'D', '-.'), 'hyb': (MAGENTA, 'P', '-.'), 'polys': (BLUE, 'o', '-')}
for k, n in METH:
    c, mk, ls = sty[k]
    axs[0].plot(range(4), [mean_acc(SYN_T, k, 1, 1, (s,)) for s in sn], color=c, marker=mk, ls=ls, mec='white', label=n)
    st.setdefault('snr_curve', {})[k] = [mean_acc(SYN_T, k, 1, 1, (s,)) for s in sn]
axs[0].set_xticks(range(4), xs); axs[0].set_xlabel('SNR (dB)'); axs[0].set_ylabel('Top-1 accuracy (%)')
axs[0].set_title('(a) Synthetic speech vs. noise (slot + ME)')
h_, l_ = axs[0].get_legend_handles_labels()
fig.legend(h_, l_, frameon=False, fontsize=6, ncol=3, loc='upper center', bbox_to_anchor=(.5, 1.13))
catacc = {}
for k in ('base_awed_t', 'text', 'polys'):
    for cat in CATS:
        h = []
        for L in SYN_T:
            Pk, m = fold(L); y = np.array(m['y']); s = np.array(m['snr'])
            idx = np.where(s == -1)[0]
            pr = decode(Pk[k][idx], y[idx], 1, 1); sel = np.array([CAT[CONCEPTS[t]] == cat for t in y[idx]])
            h += list(pr[sel] == y[idx][sel])
        catacc[(k, cat)] = 100 * np.mean(h)
x = np.arange(4); wd = .26
for i, (k, c) in enumerate((('base_awed_t', ORANGE), ('text', GRAY), ('polys', BLUE))):
    axs[1].bar(x + (i - 1) * wd, [catacc[(k, cat)] for cat in CATS], wd * .92, color=c,
               label=dict(METH)[k])
axs[1].set_xticks(x, CATS); axs[1].set_ylim(0, 100); axs[1].set_title('(b) By concept category (clean)')
axs[1].grid(axis='x', visible=False)
fig.savefig(PAPER + 'fig_speech_syn.pdf'); plt.close()
st['catacc'] = {f'{k}|{c}': v for (k, c), v in catacc.items()}

# ---- top-9 languages: text vs synthetic speech
TOP = [('en', 'English'), ('hi', 'Hindi'), ('es', 'Spanish'), ('ar', 'Arabic (MSA)'), ('fr', 'French'),
       ('bn', 'Bengali'), ('pt', 'Portuguese'), ('ru', 'Russian'), ('ur', 'Urdu')]
with open(PAPER + 'tab_speech_top9.tex', 'w') as f:
    for l, n in TOP:
        sp = [100 * np.mean([acc[(l, vo, s)][('polys', 1, 1)] for vo in ('v1', 'v2')]) for s in (-1, 10)]
        tx = [100 * np.mean([acc[(l, vo, -1)][(k, 1, 1)] for vo in ('v1', 'v2')]) for k in ('base_awed_t', 'text')]
        f.write(f"{n}{'$^*$' if l in DEV else ''} & {100*TXT[l]['polynet+ME']:.1f} & {tx[0]:.1f} & {tx[1]:.1f} & "
                f"\\textbf{{{sp[0]:.1f}}} & {sp[1]:.1f} \\\\\n")

# ======================================================= real voices (English held out)
P, m = fold('en_real'); y = np.array(m['y']); ds = np.array(m['dataset']); spk = np.array(m['speaker'])
META = json.load(open('data/amnist/data/audioMNIST_meta.txt'))
def grp(d, s):
    if d == 'fsdd': return 'FSDD'
    a = META[s]['accent'].strip().lower(); nat = META[s]['native speaker'] == 'yes'
    return 'native English' if nat or a in ('english', 'south african') else ('German accent' if a.startswith('german') else 'other accents')
G = np.array([grp(d, s) for d, s in zip(ds, spk)])
st['real_n_utt'] = int(len(y)); st['real_n_spk'] = int(len({(d, s) for d, s in zip(ds, spk)}))
st['real_groups'] = {g: int(len({s for s, gg in zip(spk, G) if gg == g})) for g in set(G)}

def session_me(Pk, idx_all, rng, draws=20):
    """Each speaker says the digits 1..9 once (random repetition); joint ME over the number slot."""
    out = []
    by = defaultdict(lambda: defaultdict(list))
    for i in idx_all: by[(ds[i], spk[i])][y[i]].append(i)
    for key, dd in by.items():
        for _ in range(draws):
            idx = np.array([rng.choice(dd[c]) for c in sorted(dd)])
            out.append(float((decode(Pk[idx], y[idx], 1, 1) == y[idx]).mean()))
    return 100 * np.mean(out)

REAL = METH + [('invocab_base_awed_t', 'AWED NN, English in memory'), ('invocab_polys', 'PolyNET-S, English in memory')]
rng = np.random.default_rng(0); real = {}
for k, n in REAL:
    for d in ('amnist', 'fsdd'):
        idx = np.where(ds == d)[0]
        real[(k, d)] = (100 * (decode(P[k][idx], y[idx], 0, 0) == y[idx]).mean(),
                        100 * (decode(P[k][idx], y[idx], 1, 0) == y[idx]).mean(),
                        session_me(P[k], idx, rng))
# synthetic English digits 1-9 (same model, same decoding) to measure the synthetic-real gap
Pe, me_ = fold('en'); ye = np.array(me_['y']); se = np.array(me_['snr'])
dig = np.array([CONCEPTS[t] in [f'num_{i}' for i in range(1, 10)] for t in ye]) & (se == -1)
syn_en = {k: (100 * (decode(Pe[k][dig], ye[dig], 0, 0) == ye[dig]).mean(),
              100 * (decode(Pe[k][dig], ye[dig], 1, 0) == ye[dig]).mean(),
              100 * np.mean([(decode(Pe[k][np.where(dig & (np.array(me_['voice']) == v))[0]],
                                     ye[np.where(dig & (np.array(me_['voice']) == v))[0]], 1, 1)
                              == ye[np.where(dig & (np.array(me_['voice']) == v))[0]]).mean() for v in ('v1', 'v2')]))
          for k, _ in METH}
with open(PAPER + 'tab_speech_real.tex', 'w') as f:
    for i, (k, n) in enumerate(REAL):
        if i in (3, 6): f.write('\\midrule\n')
        a, b = real[(k, 'amnist')], real[(k, 'fsdd')]
        se_ = syn_en.get(k)
        f.write(n + ' & ' + ' & '.join(f'{v:.1f}' for v in a + b) + ' & ' +
                (' & '.join(f'{v:.1f}' for v in se_) if se_ else '-- & -- & --') + ' \\\\\n')
st['real'] = {f'{k}|{d}': v for (k, d), v in real.items()}; st['syn_en'] = syn_en
for d in ('amnist', 'fsdd'):
    idx = np.where(ds == d)[0]
    pa = [];  pb = []
    for s in sorted(set(spk[idx])):
        j = idx[spk[idx] == s]
        pa.append((decode(P['polys'][j], y[j], 1, 0) == y[j]).mean()); pb.append((decode(P['base_awed_t'][j], y[j], 1, 0) == y[j]).mean())
    st[f'p_real_{d}'] = wilcoxon(pa, pb, alternative='greater').pvalue if len(pa) > 5 else None
    st[f'real_wins_{d}'] = (int(sum(u > v for u, v in zip(pa, pb))), int(sum(u < v for u, v in zip(pa, pb))))

# ---- Figure: real voices by speaker group + confusion of PolyNET-S (slot)
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.2), gridspec_kw={'width_ratios': [1.2, 1], 'wspace': .3})
groups = ['native English', 'German accent', 'other accents', 'FSDD']
for i, (k, c) in enumerate((('base_awed_t', ORANGE), ('text', GRAY), ('polys', BLUE), ('invocab_polys', GREEN))):
    v = []
    for g in groups:
        idx = np.where(G == g)[0]; v.append(100 * (decode(P[k][idx], y[idx], 1, 0) == y[idx]).mean())
    axs[0].bar(np.arange(4) + (i - 1.5) * .2, v, .18, color=c, label=dict(REAL)[k])
    st.setdefault('groups', {})[k] = v
axs[0].set_xticks(range(4), [f'{g.replace(" ", chr(10), 1)}\n({st["real_groups"].get(g, 0)} spk.)' for g in groups], fontsize=6)
axs[0].set_ylabel('Top-1 accuracy, number slot (%)'); axs[0].set_ylim(0, 78); axs[0].set_yticks(range(0, 51, 10)); axs[0].grid(axis='x', visible=False)
axs[0].axhline(10, color=INK, lw=.6, ls=':'); axs[0].text(-.45, 11, 'chance', fontsize=5.5, ha='left')
axs[0].set_title('(a) Real voices, English never seen')
axs[0].legend(frameon=False, fontsize=5.5, loc='upper center', ncol=2)
idx = np.arange(len(y)); pr = decode(P['polys'], y, 1, 0)
M = np.zeros((9, 10))
for t, p in zip(y, pr):
    M[int(CONCEPTS[t][4:]) - 1, int(CONCEPTS[p][4:]) - 1] += 1
M = 100 * M / M.sum(1, keepdims=True)
im = axs[1].imshow(M, cmap='Blues', vmin=0, vmax=100, aspect='auto'); axs[1].grid(False)
for i in range(9):
    for j in range(10):
        if M[i, j] >= 5: axs[1].text(j, i, f'{M[i, j]:.0f}', ha='center', va='center', fontsize=5,
                                     color='white' if M[i, j] > 55 else INK)
axs[1].set_xticks(range(10), range(1, 11)); axs[1].set_yticks(range(9), range(1, 10))
axs[1].set_xlabel('Grounded number'); axs[1].set_ylabel('Spoken digit'); axs[1].set_title('(b) PolyNET-S confusions (%)')
fig.savefig(PAPER + 'fig_speech_real.pdf'); plt.close()

# ======================================================= robot: spoken programs
sys.path.insert(0, TEXT_DIR); os.chdir(TEXT_DIR)
from sim import execute, LEN, TIM, NUM, DAYS, MONTHS
os.chdir(SPEECH_DIR)
rob = defaultdict(list)
for L in SYN_T:
    Pk, mm = fold(L); yy = np.array(mm['y']); vv = np.array(mm['voice']); ss = np.array(mm['snr'])
    have = sorted({CONCEPTS[t] for t in yy})
    nums = [c for c in NUM if c in have]; lens = [c for c in LEN if c in have]; tims = [c for c in TIM if c in have]
    days = [c for c in DAYS if c in have]; mons = [c for c in MONTHS if c in have]
    for snv in (-1, 20, 10, 5):
        for k in ('base_awed_t', 'text', 'polys'):
            for vo in ('v1', 'v2'):
                idx = np.where((vv == vo) & (ss == snv))[0]
                pr = decode(Pk[k][idx], yy[idx], 1, 1)
                g = {CONCEPTS[t]: CONCEPTS[p] for t, p in zip(yy[idx], pr)}
                r2 = np.random.default_rng(1); ok = []
                for _ in range(300):
                    prog = []
                    for s_ in range(6):
                        if r2.random() < .7 and lens: prog.append(('MOVE', r2.choice(nums), r2.choice(lens)))
                        elif tims: prog.append(('WAIT', r2.choice(nums), r2.choice(tims)))
                    hdr = [r2.choice(days), r2.choice(mons)] if days and mons else []
                    ok.append(all(g.get(n) == n and g.get(u) == u for _, n, u in prog) and all(g.get(h) == h for h in hdr))
                rob[(k, snv)].append(np.mean(ok))
st['robot_syn'] = {f'{k}|{s}': 100 * float(np.mean(v)) for (k, s), v in rob.items()}
# real voices: programs of six "move <digit> metre" segments, digits spoken by one real speaker
rr = {}
for k in ('base_awed_t', 'text', 'polys', 'invocab_polys'):
    pr = decode(P[k], y, 1, 0); r3 = np.random.default_rng(2); ok = []; err = []
    by = defaultdict(lambda: defaultdict(list))
    for i in range(len(y)): by[(ds[i], spk[i])][y[i]].append(i)
    for key, dd in by.items():
        for _ in range(50):
            digs = r3.choice(sorted(dd), 6); idx = [r3.choice(dd[c]) for c in digs]
            truth = [('MOVE', CONCEPTS[c], 'meter') for c in digs]
            got = [('MOVE', CONCEPTS[pr[i]], 'meter') for i in idx]
            P0 = execute(truth, {c: c for c in CONCEPTS})[0][-1]
            ident = {c: c for c in CONCEPTS}
            P1 = execute(got, ident)[0][-1]
            ok.append(all(CONCEPTS[pr[i]] == CONCEPTS[c] for i, c in zip(idx, digs))); err.append(np.linalg.norm(P1 - P0))
    rr[k] = (100 * np.mean(ok), float(np.mean(err)), float(np.median(err)))
st['robot_real'] = rr

# ---- confirmation dialogue: robot proposes candidates in order of p, user answers yes/no
def ranks(Pk, yy):
    """1-based rank of the true concept among the slot's candidates."""
    out = []
    for p, t in zip(Pk.astype(float), yy):
        cand = np.where(MASK[CAT[CONCEPTS[t]]])[0]
        order = cand[np.argsort(-p[cand])]
        out.append(int(np.where(order == t)[0][0]) + 1)
    return np.array(out)
RK = {k: ranks(P[k], y) for k in ('base_awed_t', 'text', 'polys', 'invocab_polys')}
st['real_turns'] = {k: float(v.mean()) for k, v in RK.items()}
st['real_top3'] = {k: float(100 * (v <= 3).mean()) for k, v in RK.items()}
SRK = defaultdict(list)
for L in SYN_T:
    Pk, mm = fold(L); yy = np.array(mm['y']); ss = np.array(mm['snr'])
    for k in ('base_awed_t', 'text', 'polys'):
        for snv in (-1, 20, 10, 5):
            i = np.where(ss == snv)[0]; SRK[(k, snv)] += list(ranks(Pk[k][i], yy[i]))
st['syn_turns'] = {f'{k}|{s}': float(np.mean(v)) for (k, s), v in SRK.items()}
st['syn_top3_clean'] = {k: float(100 * (np.array(SRK[(k, -1)]) <= 3).mean()) for k in ('base_awed_t', 'text', 'polys')}
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.0), gridspec_kw={'wspace': .32})
ks = [('base_awed_t', ORANGE, 's'), ('text', GRAY, 'D'), ('polys', BLUE, 'o'), ('invocab_polys', GREEN, '^')]
kk = np.arange(1, 11)
for k, c, mk in ks:
    axs[0].plot(kk, [100 * (RK[k] <= j).mean() for j in kk], color=c, marker=mk, ms=3.5, mec='white', label=dict(REAL)[k])
axs[0].plot(kk, kk * 10, color=INK, lw=.7, ls=':', label='chance')
axs[0].set_xlabel('Candidates offered, $k$'); axs[0].set_ylabel('Correct number among top $k$ (%)')
axs[0].set_title('(a) Real voices, English unseen'); axs[0].legend(frameon=False, fontsize=5.5, loc='lower right')
axs[0].set_xticks(kk)
for k, c, mk in ks[:3]:
    axs[1].plot(range(4), [st['syn_turns'][f'{k}|{s}'] for s in (-1, 20, 10, 5)], color=c, marker=mk, mec='white',
                label=dict(METH)[k])
axs[1].set_xticks(range(4), xs); axs[1].set_xlabel('SNR (dB)'); axs[1].set_ylabel('Mean confirmation turns per word')
axs[1].set_title(f'(b) Synthetic speech, {len(SYN_T)} languages'); axs[1].legend(frameon=False, fontsize=5.5)
fig.savefig(PAPER + 'fig_speech_robot.pdf'); plt.close()

json.dump(st, open('results_speech.json', 'w'), indent=1, default=float)
print(json.dumps(st, indent=1, default=float)[:6000])
