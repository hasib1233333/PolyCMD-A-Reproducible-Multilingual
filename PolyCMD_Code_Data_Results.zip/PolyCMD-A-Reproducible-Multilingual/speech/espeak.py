"""Minimal ctypes binding to the eSpeak-NG library bundled by espeakng-loader:
text-to-speech (16-bit PCM, 22.05 kHz) and text-to-IPA (grapheme-to-phoneme)."""
import ctypes, numpy as np, espeakng_loader

_lib = ctypes.cdll.LoadLibrary(espeakng_loader.get_library_path())
_CB = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_short), ctypes.c_int, ctypes.c_void_p)
_buf = []

@_CB
def _callback(wav, n, events):
    if n > 0:
        _buf.append(np.ctypeslib.as_array(wav, shape=(n,)).copy())
    return 0

AUDIO_OUTPUT_SYNCHRONOUS = 2
_lib.espeak_Initialize.restype = ctypes.c_int
SR = _lib.espeak_Initialize(AUDIO_OUTPUT_SYNCHRONOUS, 0,
                            espeakng_loader.get_data_path().encode(), 0)
_lib.espeak_SetSynthCallback(_callback)
_lib.espeak_SetVoiceByName.argtypes = [ctypes.c_char_p]
_lib.espeak_Synth.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_uint, ctypes.c_int,
                              ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p]
_lib.espeak_SetParameter.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int]
_lib.espeak_TextToPhonemes.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_int, ctypes.c_int]
_lib.espeak_TextToPhonemes.restype = ctypes.c_char_p
espeakCHARS_UTF8, espeakRATE, espeakPITCH = 1, 1, 3

def set_voice(name):
    return _lib.espeak_SetVoiceByName(name.encode()) == 0

def synth(text, voice, rate=170, pitch=50):
    """Return int16 waveform at SR Hz."""
    if not set_voice(voice):
        raise ValueError(f'no espeak voice {voice}')
    _lib.espeak_SetParameter(espeakRATE, rate, 0)
    _lib.espeak_SetParameter(espeakPITCH, pitch, 0)
    _buf.clear()
    b = text.encode('utf-8') + b'\0'
    _lib.espeak_Synth(b, len(b), 0, 0, 0, espeakCHARS_UTF8, None, None)
    return np.concatenate(_buf) if _buf else np.zeros(1, np.int16)

def g2p(text, voice):
    """Grapheme-to-phoneme in IPA (espeak's own transcription)."""
    if not set_voice(voice):
        raise ValueError(f'no espeak voice {voice}')
    b = ctypes.c_char_p(text.encode('utf-8'))
    p = ctypes.cast(ctypes.pointer(b), ctypes.POINTER(ctypes.c_void_p))
    out = []
    while True:
        r = _lib.espeak_TextToPhonemes(p, espeakCHARS_UTF8, 0x02)   # 0x02 = IPA
        if r: out.append(r.decode('utf-8'))
        if not ctypes.cast(p, ctypes.POINTER(ctypes.c_char_p)).contents.value:
            break
    return ' '.join(out)
