"""Session-level decoding with clarification, on realistic command sessions, plus a
closed-loop simulated execution with obstacle-aware planning and error recovery.

Reads rev/fold_*.npz (PolyNET view scores for each held-out language; 'dup' rows are one
corrupted spelling variant of every test word, used to model recognition variants).

Session = schedule header <weekday> <month> + 4 segments, each
  MOVE <number> <length unit>  or  WAIT <number> <time unit>.
Each word occurrence is replaced by its spelling variant with probability p_var, so the
same concept can appear under two surface forms (violating hard mutual exclusivity).
Decisions are made per distinct surface form.

Decoders: independent argmax, hard ME, soft ME (gamma from the earlier dev selection),
each optionally with slot masks (the parser knows which slot a word fills).
Clarification: while the least-confident unconfirmed word has confidence below tau, the
robot asks about it; the user's answer fixes that word and the session is re-decoded,
so under (soft) ME one answer can also correct other words.
Confidence: max posterior (independent) or the assignment min-marginal margin
  m_i = cost(best decoding with word i != its current concept) - cost(best decoding),
which is exact for the joint objective. tau is chosen on the development languages.
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import os, json, glob, numpy as np, matplotlib
os.chdir(TEXT_DIR)
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import defaultdict
from scipy.optimize import linear_sum_assignment
from scipy.sparse.csgraph import dijkstra
from scipy.sparse import lil_matrix
exec(open('figures.py').read().split("D = {json")[0])            # IEEE style + palette
from common import R, TEST, DEV, CONCEPTS, CID
WP = (1, 1, .5, 1); TP = .02; SEEDS = (0, 1, 2)
GAMMA = json.load(open('results/revision.json'))['soft_gamma']
CAT = {r['concept']: r['category'] for r in R}
CATV = np.array([CAT[c] for c in CONCEPTS])
F = {}
for f in glob.glob('rev/fold_*.npz'):
    z = np.load(f, allow_pickle=True); m = json.loads(str(z['meta']))
    F[m['lang']] = ({k: z[k].astype(float) for k in z.files if k != 'meta'}, m)
LT = [l for l in TEST if l in F]; LD = [l for l in DEV if l in F]

def sm(L): L = L - L.max(1, keepdims=True); E = np.exp(L); return E / E.sum(1, keepdims=True)
def probs(V, seed):
    return sm(WP[0] * V[f'view0_s{seed}'] + sum(WP[v] * V[f'view{v}'] / TP for v in (1, 2, 3)))

LEN = {'meter': 1.0, 'centimeter': 1e-2, 'millimeter': 1e-3}
TIM = {'second': 1.0, 'minute': 60.0, 'hour': 3600.0}
NUM = {f'num_{n}': n for n in range(1, 11)}
DAYS = [c for c in CONCEPTS if CAT[c] == 'weekday']; MONTHS = [c for c in CONCEPTS if CAT[c] == 'month']

# ------------------------------------------------------------------ decoders
BIG = 1e6
def cost_matrix(Pm, mask, fixed):
    """-log p with slot masks; fixed rows are forced to the confirmed concept."""
    c = -np.log(Pm + 1e-12)
    if mask is not None: c = np.where(mask, c, BIG)
    for i, cc in fixed.items(): c[i] = BIG; c[i, cc] = 0.0
    return c

def solve(c, mode):
    k, C_ = c.shape
    if mode == 'ind': o = c.argmin(1); return o, c[np.arange(k), o].sum()
    big = c if mode == 'hard' else np.concatenate([c] + [c + GAMMA] * (k - 1), 1)
    r, col = linear_sum_assignment(big)
    o = np.empty(k, int); o[r] = col % C_; return o, big[r, col].sum()

def decode(Pm, mode, mask, fixed):
    c = cost_matrix(Pm, mask, fixed); o, v = solve(c, mode)
    if mode == 'ind':                                 # confidence = posterior of the choice (renormalised under mask)
        q = np.exp(-c); q /= q.sum(1, keepdims=True); conf = q[np.arange(len(o)), o]
        return o, np.log(conf / (1 - conf + 1e-12))   # log-odds, comparable scale to a margin
    marg = np.full(len(o), np.inf)
    for i in range(len(o)):
        if i in fixed: continue
        c2 = c.copy(); c2[i, o[i]] = BIG
        marg[i] = solve(c2, mode)[1] - v
    return o, marg

def trace(Pm, y, mode, mask, tau_max):
    """Greedy clarification: ask about the least-confident unconfirmed word. Returns the list of
    states (min confidence of unconfirmed words, decoding, #questions); for any tau the robot
    stops at the first state whose min confidence >= tau."""
    fixed = {}; states = []
    while True:
        o, conf = decode(Pm, mode, mask, fixed)
        cand = [i for i in range(len(o)) if i not in fixed]
        mc = min(conf[j] for j in cand) if cand else np.inf
        states.append((mc, o, len(fixed)))
        if not cand or mc >= tau_max: return states
        i = min(cand, key=lambda j: conf[j]); fixed[i] = y[i]   # the user answers the robot's question
def stop(states, tau):
    for mc, o, nq in states:
        if mc >= tau: return o, nq
    return states[-1][1], states[-1][2]
def run_session(Pm, y, mode, mask, tau):
    o, nq = stop(trace(Pm, y, mode, mask, tau), tau); return o, nq

# ------------------------------------------------------------------ sessions
def make_sessions(l, n, rng):
    m = F[l][1]; yt = np.array(m['y'])
    have = {CONCEPTS[c]: j for j, c in enumerate(yt)}
    nums = [c for c in NUM if c in have]; lens = [c for c in LEN if c in have]; tims = [c for c in TIM if c in have]
    days = [c for c in DAYS if c in have]; mons = [c for c in MONTHS if c in have]
    out = []
    for _ in range(n):
        prog = []
        for s in range(4):
            if not lens and not tims: break
            if (rng.random() < .7 and lens) or not tims: prog.append(('MOVE', rng.choice(nums), rng.choice(lens)))
            else: prog.append(('WAIT', rng.choice(nums), rng.choice(tims)))
        hdr = [rng.choice(days), rng.choice(mons)] if days and mons else []
        out.append((prog, hdr, have))
    return out

def tokens(prog, hdr, have, p_var, rng, kind, q):
    """Surface-form tokens. Returns list of (row index in fold, true concept id, slot), and
    for every program word its token index."""
    ti = np.where(kind == 'test')[0]; di = np.where(kind == 'dup')[0]
    toks, where = {}, []
    words = [(c, 'hdr') for c in hdr] + [(w, s) for seg in prog for s, w in zip(('num', 'unit'), seg[1:])]
    for c, slot in words:
        j = have[c]; row = di[j] if rng.random() < p_var else ti[j]
        key = q[row]
        if key not in toks: toks[key] = (row, CID[c], CAT[c])
        where.append(list(toks).index(key))
    return list(toks.values()), where

def evaluate(langs, p_var, configs, taus, n=60, seed=0):
    """configs: list of (name, mode, use_mask). Returns res[name][tau] = (session success, questions/session, word acc)."""
    res = {nm: {t: [0, 0, 0, 0] for t in taus} for nm, _, _ in configs}
    for l in langs:
        V, m = F[l]; kind = np.array(m['kind'])
        rng = np.random.default_rng(seed + sum(map(ord, l)))
        S = make_sessions(l, n, rng)
        for s_ in SEEDS:
            P = probs(V, s_)
            for prog, hdr, have in S:
                tk, _ = tokens(prog, hdr, have, p_var, rng, kind, m['q'])
                rows = [t[0] for t in tk]; y = np.array([t[1] for t in tk])
                mask = np.array([CATV == t[2] for t in tk])
                Pm = P[rows]
                for nm, mode, um in configs:
                    st = trace(Pm, y, mode, mask if um else None, max(taus))
                    for t in taus:
                        o, nq = stop(st, t)
                        r = res[nm][t]; r[0] += float((o == y).all()); r[1] += nq; r[2] += float((o == y).mean()); r[3] += 1
    return {nm: {t: (100 * r[0] / r[3], r[1] / r[3], 100 * r[2] / r[3]) for t, r in d.items()} for nm, d in res.items()}

CONF = [('independent', 'ind', False), ('hard ME', 'hard', False), ('soft ME', 'soft', False),
        ('independent + slots', 'ind', True), ('hard ME + slots', 'hard', True), ('soft ME + slots', 'soft', True)]
ST = {'gamma': GAMMA}
# 1) no clarification: realistic sessions at three variant rates
ST['noq'] = {}
for pv in (0.0, 0.1, 0.25):
    ST['noq'][pv] = {'dev': evaluate(LD, pv, CONF, [-np.inf], seed=10), 'test': evaluate(LT, pv, CONF, [-np.inf], seed=20)}
    print('p_var', pv, {k: v[-np.inf] for k, v in ST['noq'][pv]['test'].items()}, flush=True)
# 2) clarification curves (p_var = 0.1)
TAUS = [-np.inf, 0, 2, 5, 10, 20, 40, 80, 160, np.inf]
CQ = [('independent + slots', 'ind', True), ('hard ME + slots', 'hard', True), ('soft ME + slots', 'soft', True)]
dev_c = evaluate(LD, 0.1, CQ, TAUS, seed=30); test_c = evaluate(LT, 0.1, CQ, TAUS, seed=40)
ST['clar_dev'] = {k: {str(t): v for t, v in d.items()} for k, d in dev_c.items()}
ST['clar_test'] = {k: {str(t): v for t, v in d.items()} for k, d in test_c.items()}
# operating point: smallest tau whose dev session success >= 95 %, per decoder
op = {}
for nm in dev_c:
    ok = [t for t in TAUS if dev_c[nm][t][0] >= 95]
    t = min(ok) if ok else TAUS[-1]
    op[nm] = dict(tau=float(t), dev=dev_c[nm][t], test=test_c[nm][t])
ST['op'] = op
print(json.dumps(op, indent=1), flush=True)

# ------------------------------------------------------------------ closed-loop execution
RES_M = 0.5; NG = 60                                     # 30 m x 30 m world, 0.5 m cells
def world(rng):
    occ = np.zeros((NG, NG), bool)
    for _ in range(14):
        x, y = rng.integers(0, NG - 6, 2); w, h = rng.integers(2, 7, 2); occ[x:x + w, y:y + h] = True
    occ[NG // 2 - 2:NG // 2 + 3, NG // 2 - 2:NG // 2 + 3] = False      # start area free
    return occ
def graph(occ):
    G = lil_matrix((NG * NG, NG * NG))
    for i in range(NG):
        for j in range(NG):
            if occ[i, j]: continue
            for di_, dj, w in ((1, 0, 1), (0, 1, 1), (1, 1, 2 ** .5), (1, -1, 2 ** .5)):
                a, b = i + di_, j + dj
                if 0 <= a < NG and 0 <= b < NG and not occ[a, b]:
                    G[i * NG + j, a * NG + b] = w * RES_M; G[a * NG + b, i * NG + j] = w * RES_M
    return G.tocsr()
def cell(p): return int(np.clip(round(p[0] / RES_M), 0, NG - 1)), int(np.clip(round(p[1] / RES_M), 0, NG - 1))
def inside(p): return 0 <= p[0] < NG * RES_M and 0 <= p[1] < NG * RES_M

def execute(prog, g, true, occ, G):
    """Executes MOVE/WAIT segments with planning on the occupancy grid.
    g: grounding (concept per program word, updated on correction). Returns metrics."""
    pos = np.array([NG * RES_M / 2, NG * RES_M / 2]); th = 0.0
    q_infeas = corr = 0; waste = 0.0; wrong_wait = 0
    for si, (kind, n, u) in enumerate(prog):
        def target(gr):
            nn = NUM.get(gr[(si, 'num')], None); d = LEN.get(gr[(si, 'unit')], None)
            if nn is None or d is None: return None
            return pos + nn * d * np.array([np.cos(th), np.sin(th)])
        if kind == 'WAIT':
            ok = g[(si, 'num')] == n and g[(si, 'unit')] == u
            if not ok: wrong_wait += 1; corr += 1; g[(si, 'num')], g[(si, 'unit')] = n, u
            th += np.pi / 2; continue
        tt = target(true)
        tg = target(g)
        if tg is None or not inside(tg) or occ[cell(tg)]:           # infeasible -> robot asks before moving
            if (g[(si, 'num')], g[(si, 'unit')]) != (n, u): q_infeas += 1; g[(si, 'num')], g[(si, 'unit')] = n, u; tg = tt
        def path_len(a, b):
            if cell(a) == cell(b): return float(np.linalg.norm(b - a))
            return float(dijkstra(G, indices=cell(a)[0] * NG + cell(a)[1])[cell(b)[0] * NG + cell(b)[1]])
        if (g[(si, 'num')], g[(si, 'unit')]) != (n, u) and tt is not None and inside(tt) and not occ[cell(tt)]:
            # wrong but feasible: robot drives there, user corrects, robot drives to the intended point
            w1 = path_len(pos, tg); w2 = path_len(tg, tt); w0 = path_len(pos, tt)
            if np.isfinite(w1 + w2 + w0): waste += w1 + w2 - w0
            corr += 1; g[(si, 'num')], g[(si, 'unit')] = n, u
        if tt is not None and inside(tt) and not occ[cell(tt)]: pos = tt
        th += np.pi / 2
    return dict(infeasible_q=q_infeas, corrections=corr, waste=waste, wrong_wait=wrong_wait)

def closed_loop(langs, configs, n=40, seed=50):
    out = {nm: defaultdict(list) for nm, *_ in configs}
    for l in langs:
        V, m = F[l]; kind = np.array(m['kind'])
        rng = np.random.default_rng(seed + sum(map(ord, l)))
        S = make_sessions(l, n, rng)
        worlds = []
        for _ in range(4):
            occ = world(rng); worlds.append((occ, graph(occ)))
        for s_ in SEEDS:
            P = probs(V, s_)
            for k, (prog, hdr, have) in enumerate(S):
                tk, where = tokens(prog, hdr, have, 0.1, rng, kind, m['q'])
                rows = [t[0] for t in tk]; y = np.array([t[1] for t in tk])
                mask = np.array([CATV == t[2] for t in tk]); Pm = P[rows]
                occ, G = worlds[k % 4]
                for nm, mode, um, tau in configs:
                    o, nq = run_session(Pm, y, mode, mask if um else None, tau)
                    words = [('hdr', i) for i in range(len(hdr))] + [(si, sl) for si in range(len(prog)) for sl in ('num', 'unit')]
                    g = {w: CONCEPTS[o[where[i]]] for i, w in enumerate(words)}
                    true = {(si, 'num'): seg[1] for si, seg in enumerate(prog)} | {(si, 'unit'): seg[2] for si, seg in enumerate(prog)}
                    hdr_wrong = sum(g[('hdr', i)] != hdr[i] for i in range(len(hdr)))
                    r = execute(prog, g, true, occ, G)
                    q = out[nm]
                    q['questions'].append(nq); q['infeasible_q'].append(r['infeasible_q'])
                    q['corrections'].append(r['corrections'] + hdr_wrong); q['waste'].append(r['waste'])
                    q['clean'].append(float(r['corrections'] + hdr_wrong + r['infeasible_q'] == 0))
    return {nm: {k: float(np.mean(v)) for k, v in d.items()} for nm, d in out.items()}

CL = [('independent + slots, no questions', 'ind', True, -np.inf),
      ('soft ME + slots, no questions', 'soft', True, -np.inf),
      ('independent + slots, clarification', 'ind', True, op['independent + slots']['tau']),
      ('soft ME + slots, clarification', 'soft', True, op['soft ME + slots']['tau'])]
ST['closed_loop'] = closed_loop(LT, CL)
print(json.dumps(ST['closed_loop'], indent=1), flush=True)
json.dump(ST, open('results/clarify.json', 'w'), indent=1, default=float)

# ------------------------------------------------------------------ outputs
P_ = 'paper/'
with open(P_ + 'tab_sessions.tex', 'w') as f:
    for nm, *_ in CONF:
        f.write(nm.replace('ME', 'ME') + ' & ' + ' & '.join(f"{ST['noq'][pv]['test'][nm][-np.inf][0]:.1f} & {ST['noq'][pv]['test'][nm][-np.inf][2]:.1f}" for pv in (0.0, 0.1, 0.25)) + ' \\\\\n')
with open(P_ + 'tab_closed.tex', 'w') as f:
    for nm, *_ in CL:
        d = ST['closed_loop'][nm]
        f.write(f"{nm} & {d['questions'] + d['infeasible_q']:.2f} & {d['corrections']:.2f} & {d['waste']:.2f} & {100 * d['clean']:.1f} \\\\\n")
fig, ax = plt.subplots(figsize=(3.45, 2.3))
for (nm, col, mk) in (('independent + slots', GRAY, 's'), ('hard ME + slots', ORANGE, '^'), ('soft ME + slots', BLUE, 'o')):
    xs = [test_c[nm][t][1] for t in TAUS]; ys = [test_c[nm][t][0] for t in TAUS]
    ax.plot(xs, ys, marker=mk, color=col, label=nm, ms=3.5, lw=1)
    o_ = op[nm]; ax.plot(o_['test'][1], o_['test'][0], marker='*', color=col, ms=9, mec='k', mew=.4)
ax.set_xlabel('questions per session'); ax.set_ylabel('session success (%)'); ax.grid(alpha=.3)
ax.legend(fontsize=6.5, loc='lower right'); fig.tight_layout(); fig.savefig(P_ + 'fig_clarify.pdf'); print('saved')
