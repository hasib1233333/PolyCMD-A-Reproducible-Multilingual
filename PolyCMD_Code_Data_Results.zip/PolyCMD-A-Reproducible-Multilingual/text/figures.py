"""All result figures (vector PDF, IEEE column width) + LaTeX table fragments."""
import json, glob, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon
from common import *

plt.rcParams.update({'font.family': 'serif', 'font.serif': ['DejaVu Serif'], 'font.size': 8,
                     'axes.titlesize': 8, 'axes.labelsize': 8, 'legend.fontsize': 7,
                     'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.spines.top': False,
                     'axes.spines.right': False, 'axes.grid': True, 'grid.color': '#e4e3df',
                     'grid.linewidth': .5, 'axes.axisbelow': True, 'lines.linewidth': 1.4,
                     'pdf.fonttype': 42, 'savefig.bbox': 'tight', 'savefig.pad_inches': .02})
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, GRAY, INK = ('#2a78d6', '#eb6834', '#1baf7a', '#eda100',
                                                         '#e87ba4', '#008300', '#8d8c85', '#2b2b28')
W1, W2 = 3.45, 7.1      # IEEE single / double column (in)
D = {json.load(open(f))['lang']: json.load(open(f)) for f in glob.glob('results/fold_*.json')}
LS = sorted(l for l in D if l in TEST)
from collections import Counter as _Cn
for l in D:   # report each language under its majority script (Serbian mixes Latin numerals from num2words with Cyrillic CLDR names)
    D[l]['script'] = _Cn(r['script'] for r in R if r['lang'] == l).most_common(1)[0][0]
print(len(LS), 'test languages')

NAMES = {'knn_raw': 'Char n-gram kNN (Unicode)', 'edit_raw': 'Edit-distance NN (Unicode)',
         'nettalk_raw': 'NETtalk window MLP (Unicode)', 'knn_rom': 'Char n-gram kNN (romanized)',
         'edit_rom': 'Edit-distance NN (romanized)', 'awed': 'AWED NN (romanized)',
         'net_phon': 'Window net (romanised, articulatory)', 'polynet': 'PolyNET (inductive)'}

def sci(x, d=2):
    if x == 0: return '0'
    e = int(np.floor(np.log10(abs(x)))); m = x / 10 ** e
    return f'{m:.{d}f}\\times10^{{{e}}}' if e != 0 else f'{x:.{d}f}'

def ci(v, B=2000):
    v = np.asarray(v); r = np.random.default_rng(0)
    bs = [r.choice(v, len(v)).mean() for _ in range(B)]; return np.percentile(bs, [2.5, 97.5])

acc = lambda m: np.array([D[l]['acc'][m] for l in LS])

# ------------------------------------------------------------ Table: main results
rows = ['knn_raw', 'edit_raw', 'nettalk_raw', 'knn_rom', 'edit_rom', 'awed', 'net_phon', 'polynet']
best_base = max(rows[:-1], key=lambda m: acc(m + '+ME').mean())
tex = []
for m in rows:
    a, b = acc(m), acc(m + '+ME'); lo, hi = ci(b)
    tex.append((NAMES[m], 100 * a.mean(), 100 * b.mean(), 100 * lo, 100 * hi))
pv = wilcoxon(acc('polynet+ME'), acc(best_base + '+ME'), alternative='greater').pvalue
pv2 = wilcoxon(acc('polynet+ME'), acc('nettalk_raw'), alternative='greater').pvalue
pv3 = wilcoxon(acc('polynet+ME'), acc('polynet'), alternative='greater').pvalue
pv4 = wilcoxon(acc('polynet+ME'), acc('edit_rom+ME'), alternative='greater').pvalue
with open('paper/tab_main.tex', 'w') as f:
    bi = max(range(len(tex)), key=lambda i: tex[i][2]); bj = max(range(len(tex)), key=lambda i: tex[i][1])
    for i, (n, a, b, lo, hi) in enumerate(tex):
        A = f'\\textbf{{{a:.1f}}}' if i == bj else f'{a:.1f}'
        Bv = f'\\textbf{{{b:.1f}}}' if i == bi else f'{b:.1f}'
        if i == 3: f.write('\\midrule\n')
        if i == 7: f.write('\\midrule\n')
        f.write(f'{n} & {A} & {Bv} & [{lo:.1f}, {hi:.1f}] \\\\\n')
seed = {k: np.array([D[l]['seed_acc'][k] for l in LS]) for k in ('nettalk_raw', 'net_phon', 'polynet', 'polynet+ME')}
stats = {'best_base': best_base, 'p_vs_best': pv, 'p_vs_nettalk': pv2, 'p_me': pv3, 'p_vs_edit': pv4,
         'seed_std': {k: float(v.mean(0).std()) for k, v in seed.items()},
         'n_test': len(LS), 'mean': {m: float(acc(m).mean()) for m in D[LS[0]]['acc']}}

# ------------------------------------------------------------ Fig: per-language
order = np.argsort(acc('polynet+ME'))
fig, ax = plt.subplots(figsize=(W2, 2.4))
x = np.arange(len(LS))
for m, c, mk, lab in (('nettalk_raw', GRAY, 's', 'NETtalk MLP (Unicode)'),
                      (best_base + '+ME', ORANGE, '^', NAMES[best_base] + ' + ME'),
                      ('polynet+ME', BLUE, 'o', 'PolyNET + ME (proposed)')):
    ax.plot(x, 100 * acc(m)[order], marker=mk, ms=4, lw=0 if m != 'polynet+ME' else 1.2, color=c, label=lab,
            mec='white', mew=.6)
ax.set_xticks(x, [f"{LS[i]} ({D[LS[i]]['script'][:3]})" for i in order], fontsize=6, rotation=90)
ax.set_ylabel('Top-1 accuracy (%)'); ax.set_ylim(-3, 103); ax.set_xlim(-.7, len(LS) - .3)
ax.legend(loc='lower center', bbox_to_anchor=(.5, 1.0), frameon=False, ncol=3)
fig.savefig('paper/fig_perlang.pdf'); plt.close()

# ------------------------------------------------------------ Fig: by script & category (heatmap)
scripts = sorted({D[l]['script'] for l in LS}, key=lambda s: -sum(D[l]['script'] == s for l in LS))
cats = ['number', 'unit', 'weekday', 'month']
meths = ['nettalk_raw', best_base + '+ME', 'polynet+ME']
fig, axs = plt.subplots(1, 3, figsize=(W2, 2.0), sharey=True)
for ax, m, ttl in zip(axs, meths, ['NETtalk MLP (Unicode)', NAMES[best_base] + ' + ME', 'PolyNET + ME']):
    M = np.full((len(scripts), 4), np.nan)
    for i, s in enumerate(scripts):
        for j, c in enumerate(cats):
            h = [];
            for l in LS:
                if D[l]['script'] != s: continue
                y = np.array(D[l]['y']); p = np.array(D[l]['pred'][m]); k = np.array(D[l]['cats']) == c
                h += list(p[k] == y[k])
            M[i, j] = 100 * np.mean(h) if h else np.nan
    im = ax.imshow(M, cmap='Blues', vmin=0, vmax=100, aspect='auto')
    for i in range(len(scripts)):
        for j in range(4):
            ax.text(j, i, '--' if np.isnan(M[i, j]) else f'{M[i, j]:.0f}', ha='center', va='center', fontsize=6,
                    color='white' if M[i, j] > 60 else INK)
    ax.set_xticks(range(4), cats, rotation=30); ax.set_title(ttl); ax.grid(False)
    ax.set_yticks(range(len(scripts)), [f'{s} ({sum(D[l]["script"] == s for l in LS)})' for s in scripts])
cb = fig.colorbar(im, ax=axs, fraction=.02, pad=.01); cb.set_label('Accuracy (%)')
fig.savefig('paper/fig_script.pdf'); plt.close()

# ------------------------------------------------------------ Fig: session size + few-shot (2 panels)
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.0))
ks = ['1', '2', '4', '8', '16', '32']
sv = np.array([[D[l]['session'][str(min(int(k), D[l]['n']))] for k in ks] + [D[l]['session'][str(D[l]['n'])]] for l in LS]) * 100
xx = [1, 2, 4, 8, 16, 32, 43]  # last point = whole vocabulary of the language (25-43 words)
axs[0].plot(xx, sv.mean(0), marker='o', color=BLUE, mec='white', label='PolyNET + ME')
axs[0].fill_between(xx, *np.percentile(sv, [25, 75], 0), color=BLUE, alpha=.15, lw=0, label='inter-quartile range')
axs[0].axhline(100 * acc('polynet').mean(), ls='--', color=GRAY, lw=1, label='inductive (no ME)')
axs[0].set_xscale('log', base=2); axs[0].set_xticks(xx, [str(v) for v in xx])
axs[0].set_xlabel('Words heard in session, $k$'); axs[0].set_ylabel('Top-1 accuracy (%)')
axs[0].set_title('(a) Mutual-exclusivity decoding'); axs[0].legend(frameon=False, loc='lower left', fontsize=6); axs[0].set_ylim(0, 102)
fk = ['0', '1', '2', '5', '10', '20']
fi = np.array([[D[l]['fewshot'][k][0] for k in fk] for l in LS]) * 100
fm = np.array([[D[l]['fewshot'][k][1] for k in fk] for l in LS]) * 100
xf = [int(k) for k in fk]
axs[1].plot(xf, fi.mean(0), marker='s', color=GRAY, mec='white', label='memory write only')
axs[1].plot(xf, fm.mean(0), marker='o', color=BLUE, mec='white', label='memory write + ME')
axs[1].set_xlabel('Demonstrated words of new language'); axs[1].set_title('(b) Few-shot adaptation')
axs[1].legend(frameon=False, loc='center right')
fig.savefig('paper/fig_session_fewshot.pdf'); plt.close()
stats['session'] = dict(zip([str(v) for v in xx], sv.mean(0).tolist()))
stats['fewshot'] = {k: (a, b) for k, a, b in zip(fk, fi.mean(0), fm.mean(0))}

# ------------------------------------------------------------ Fig: noise + open set (2 panels)
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.0), gridspec_kw={'wspace': 1.05})
ps = ['0.0', '0.05', '0.1', '0.2', '0.3']
for m, c, mk, lab, ls in (('nettalk_raw', GRAY, 's', 'NETtalk MLP (Unicode)', ':'),
                          ('knn_raw', YELLOW, 'v', 'n-gram kNN (Unicode)', ':'),
                          ('edit_rom+ME', ORANGE, '^', 'Edit NN (rom.) + ME', '--'),
                          ('polynet', AQUA, 'D', 'PolyNET', '-.'),
                          ('polynet+ME', BLUE, 'o', 'PolyNET + ME', '-')):
    v = np.array([[D[l]['noise'][p][m] for p in ps] for l in LS]).mean(0) * 100
    axs[0].plot([float(p) * 100 for p in ps], v, marker=mk, color=c, ls=ls, mec='white', label=lab)
    stats.setdefault('noise', {})[m] = v.tolist()
axs[0].set_xlabel('Character corruption rate (%)'); axs[0].set_ylabel('Top-1 accuracy (%)')
axs[0].set_title('(a) Robustness to input noise'); axs[0].legend(frameon=False, fontsize=6, loc='upper left', bbox_to_anchor=(1.0, 1.0))
pos = np.concatenate([D[l]['open_scores']['pos'] for l in LS]); neg = np.concatenate([D[l]['open_scores']['neg'] for l in LS])
th = np.unique(np.r_[pos, neg])[::-1]
tpr = [(pos >= t).mean() for t in th]; fpr = [(neg >= t).mean() for t in th]
import os
def _roc(pos, neg):
    th = np.unique(np.r_[pos, neg])[::-1]
    return [0] + [(neg >= t).mean() for t in th], [0] + [(pos >= t).mean() for t in th]
if all(os.path.exists(f'results/energy_{l}.json') for l in LS):
    E = {l: json.load(open(f'results/energy_{l}.json')) for l in LS}
    ep = np.concatenate([E[l]['pos'] for l in LS]); en = np.concatenate([E[l]['neg'] for l in LS])
    f2, t2 = _roc(ep, en)
    axs[1].plot(f2, t2, color=BLUE, label='PolyNET (fused energy)')
    stats_energy = float(np.mean([((np.array(E[l]['pos'])[:, None] > np.array(E[l]['neg'])[None]).mean()
                                   + .5 * (np.array(E[l]['pos'])[:, None] == np.array(E[l]['neg'])[None]).mean())
                                  for l in LS if E[l]['neg']]))
    pooled = (ep[:, None] > en[None]).mean()
    # false-accept rate at 95% true-accept on pooled scores
    thr = np.percentile(ep, 5); far95 = float((en >= thr).mean())
else:
    stats_energy = None; far95 = None
axs[1].plot([0] + fpr, [0] + tpr, color=ORANGE, ls='--', label='PolyNET (max posterior)')
axs[1].plot([0, 1], [0, 1], ls=':', color=GRAY, lw=1, label='chance')
au = {m: np.mean([D[l]['open'][m] for l in LS if D[l]['open'][m] is not None]) for m in D[LS[0]]['open']}
axs[1].set_xlabel('False-accept rate (distractor words)'); axs[1].set_ylabel('True-accept rate')
axs[1].set_title('(b) Open-set rejection'); axs[1].legend(frameon=False, loc='lower right')
fig.savefig('paper/fig_noise_open.pdf'); plt.close()
stats['auroc'] = au; stats['auroc']['polynet_energy'] = stats_energy; stats['far_at_95'] = far95

# ------------------------------------------------------------ Fig: ablation bars
abl = ['polynet', 'abl -net', 'abl -rom', 'abl -skel', 'abl -awed', 'abl net only', 'abl awed only']
lab = ['Full', '$-$window net', '$-$n-gram (rom.)', '$-$skeleton', '$-$AWED', 'window net only', 'AWED only']
fig, ax = plt.subplots(figsize=(W1, 2.0))
y = np.arange(len(abl))
ai = [100 * acc(m).mean() for m in abl]; am = [100 * acc(m + '+ME').mean() for m in abl]
ax.barh(y + .2, ai, .38, color=GRAY, label='inductive')
ax.barh(y - .2, am, .38, color=BLUE, label='+ ME')
for i in range(len(abl)):
    ax.text(am[i] + .8, y[i] - .2, f'{am[i]:.1f}', va='center', fontsize=6)
ax.set_yticks(y, lab); ax.invert_yaxis(); ax.set_xlabel('Mean top-1 accuracy (%)')
ax.set_xlim(min(ai) - 15, max(am) + 8); ax.legend(frameon=False, loc='upper center', bbox_to_anchor=(.5, -.28), ncol=2); ax.grid(axis='y', visible=False)
fig.savefig('paper/fig_ablation.pdf'); plt.close()
stats['ablation'] = {m: (a, b) for m, a, b in zip(abl, ai, am)}

# ------------------------------------------------------------ Fig: language similarity
S = json.load(open('results/langsim.json'))
fig, axs = plt.subplots(1, 2, figsize=(W2, 3.3))
for ax, key, ttl in zip(axs, ['edit_raw', 'awed_rom'], ['(a) Unicode edit similarity', '(b) Romanized AWED similarity']):
    M = np.array(S[key]); np.fill_diagonal(M, np.nan)
    im = ax.imshow(M, cmap='Blues', vmin=0, vmax=1); ax.grid(False)
    ax.set_xticks(range(len(S['langs'])), S['langs'], rotation=90, fontsize=5)
    ax.set_yticks(range(len(S['langs'])), S['langs'], fontsize=5); ax.set_title(ttl)
    f = S['fam']; b = [i for i in range(1, len(f)) if f[i] != f[i - 1]]
    for v in b:
        ax.axhline(v - .5, color='white', lw=.6); ax.axvline(v - .5, color='white', lw=.6)
cb = fig.colorbar(im, ax=axs, fraction=.02, pad=.01); cb.set_label('Mean similarity of translation pairs')
fig.savefig('paper/fig_langsim.pdf'); plt.close()

json.dump(stats, open('results/stats.json', 'w'), indent=1, default=float)
print(json.dumps({k: stats[k] for k in ('best_base', 'p_vs_best', 'p_vs_nettalk', 'p_me', 'seed_std')}, default=float))
for n, a, b, lo, hi in tex: print(f'{n:35s} {a:5.1f} {b:5.1f} [{lo:.1f},{hi:.1f}]')
print('auroc', {k: round(v, 4) for k, v in au.items()})
print('session', stats['session']); print('fewshot', stats['fewshot']); print('abl', stats['ablation'])
