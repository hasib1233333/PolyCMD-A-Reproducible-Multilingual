"""Second-review experiments.
  python3 revision2_run.py unc        -> rev2/unc.npz   (PolyCMD-U: 11 languages outside encoder
                                         pretraining; memory = all 44 PolyCMD languages)
  python3 revision2_run.py fam <L>... -> rev2/fam_<L>.npz (family holdout: every language of
                                         L's family is removed from training/memory)
Saved per query: PolyNET views (window net for seeds 0,1,2; memory views), edit (rom),
n-gram kNN (rom) and n-gram logistic regression baselines.
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import sys, os, json, numpy as np
sys.path.insert(0, SPEECH_DIR); sys.path.insert(0, TEXT_DIR)
from ground import PolyNETS, W, TS
os.chdir(TEXT_DIR)
from common import R, CID, C
from models import romanize, NgramKNN, ngrams
from revision_run import edit_scores
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import CountVectorizer
os.makedirs('rev2', exist_ok=True)
FAM = {r['lang']: r['family'] for r in R}

def scores(tr, te):
    Wr = [romanize(r['word']) for r in tr]; y = [CID[r['concept']] for r in tr]
    Qr = [romanize(r['word']) for r in te]; out = {}
    for s in (0, 1, 2):
        V = PolyNETS(W, TS, net_kw=dict(epochs=60), seed=s).fit(Wr, y, C).view_scores(Qr)
        out[f'view0_s{s}'] = V[0].astype(np.float32)
        if s == 0:
            for v in (1, 2, 3): out[f'view{v}'] = V[v].astype(np.float32)
    out['edit_rom'] = edit_scores(Qr, Wr, y).astype(np.float32)
    out['knn_rom'] = NgramKNN(romanize).fit(Wr, y, C).scores(Qr).astype(np.float32)
    vec = CountVectorizer(analyzer=lambda s: ngrams(s, (1, 2, 3))); X = vec.fit_transform(Wr)
    lr = LogisticRegression(C=10.0, max_iter=3000).fit(X, y)
    P = np.full((len(Qr), C), 1e-12); P[:, lr.classes_] = lr.predict_proba(vec.transform(Qr))
    out['logreg'] = np.log(P).astype(np.float32)
    return out

if __name__ == '__main__':
    if sys.argv[1] == 'unc':
        U = json.load(open('lexicon_uncovered.json'))
        out = scores(R, U)
        meta = dict(lang=[r['lang'] for r in U], y=[CID[r['concept']] for r in U], cats=[r['category'] for r in U],
                    word=[r['word'] for r in U])
        np.savez_compressed('rev2/unc.npz', **out, meta=json.dumps(meta, ensure_ascii=False))
        print('unc done', flush=True)
    else:
        for L in sys.argv[2:]:
            tr = [r for r in R if FAM[r['lang']] != FAM[L]]; te = [r for r in R if r['lang'] == L]
            out = scores(tr, te)
            meta = dict(lang=L, y=[CID[r['concept']] for r in te], removed=sorted({r['lang'] for r in R if FAM[r['lang']] == FAM[L]} - {L}))
            np.savez_compressed(f'rev2/fam_{L}.npz', **out, meta=json.dumps(meta))
            print(L, 'removed', meta['removed'], flush=True)
