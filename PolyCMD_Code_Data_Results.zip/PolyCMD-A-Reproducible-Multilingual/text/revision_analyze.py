"""Analyses requested in review (Section 'Controlled analyses'). Reads rev/fold_*.npz."""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import os, json, glob, numpy as np, matplotlib
os.chdir(TEXT_DIR)
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import Counter, defaultdict
from scipy.stats import wilcoxon
from scipy.optimize import linear_sum_assignment
exec(open('figures.py').read().split("D = {json")[0])            # IEEE style + palette
from common import R, TEST, DEV, CONCEPTS
P = 'paper/'
WP = (1, 1, .5, 1); TP = .02                                   # paper's fusion (selected on dev languages)
CAT = {r['concept']: r['category'] for r in R}
F = {}
for f in glob.glob('rev/fold_*.npz'):
    z = np.load(f, allow_pickle=True); m = json.loads(str(z['meta']))
    F[m['lang']] = ({k: z[k].astype(float) for k in z.files if k != 'meta'}, m)
LT = [l for l in TEST if l in F]; LD = [l for l in DEV if l in F]
print(len(LT), 'test', len(LD), 'dev')

def sm(L):
    L = L - L.max(1, keepdims=True); E = np.exp(L); return E / E.sum(1, keepdims=True)
def fuse(V, w=WP, T=TP, seed=0, pre='', sl=slice(None)):
    L = w[0] * V[f'{pre}view0_s{seed}' if not pre else f'{pre}view0'][sl] if w[0] else 0
    for v in (1, 2, 3):
        if w[v]: L = L + w[v] * V[f'{pre}view{v}'][sl] / T
    return sm(L)
def me(Pm):
    r, c = linear_sum_assignment(-np.log(Pm + 1e-12)); o = Pm.argmax(1).copy(); o[r] = c; return o   # same floor as main study
def test_idx(m): return np.array([k == 'test' for k in m['kind']])

def method_probs(V, m, name, seed=0, T=TP):
    t = test_idx(m)
    if name == 'polynet': return fuse(V, seed=seed, T=T, sl=t)
    if name == 'nonet':   return fuse(V, (0,) + WP[1:], T=T, sl=t)
    if name == 'netonly': return fuse(V, (1, 0, 0, 0), seed=seed, sl=t)
    if name == 'awed':    return sm(V['view3'][t] / T)
    if name == 'knn_rom': return sm(V['view1'][t] / T)
    if name in ('knn_raw', 'edit_raw', 'edit_rom'): return sm(V[name][t] / T)
    if name == 'logreg':  return sm(V['logreg'][t])
def acc(Pm, y, use_me): return float(((me(Pm) if use_me else Pm.argmax(1)) == y).mean())

def per_lang(name, use_me, langs=LT, seeds=(0,), T=TP):
    return np.array([np.mean([acc(method_probs(*F[l], name, s, T), np.array(F[l][1]['y']), use_me) for s in seeds])
                     for l in langs])
def boot_ci(d, B=10000):
    r = np.random.default_rng(0); b = [r.choice(d, len(d)).mean() for _ in range(B)]
    return np.percentile(b, [2.5, 97.5])
def holm(ps):
    o = np.argsort(ps); adj = np.empty(len(ps)); run = 0
    for i, j in enumerate(o):
        run = max(run, min(1, (len(ps) - i) * ps[j])); adj[j] = run
    return adj
def sci(x, d=2):
    if x is None: return '--'
    if x == 0: return '$0$'
    e = int(np.floor(np.log10(abs(x)))); return f'${x / 10 ** e:.{d}f}\\times10^{{{e}}}$' if e else f'${x:.{d}f}$'

ST = {}
# ---------------------------------------------------------------- A. main comparison, seed-averaged
SEEDS = (0, 1, 2)
poly = per_lang('polynet', True, seeds=SEEDS); poly_i = per_lang('polynet', False, seeds=SEEDS)
ST['poly_seed0_me'] = float(per_lang('polynet', True).mean() * 100)
ST['poly_me'] = float(poly.mean() * 100); ST['poly_ind'] = float(poly_i.mean() * 100)
BASE = [('awed', 'AWED NN (romanised)'), ('edit_rom', 'Edit-distance NN (romanised)'),
        ('knn_rom', 'Char n-gram kNN (romanised)'), ('logreg', 'Char n-gram logistic regression (romanised)'),
        ('edit_raw', 'Edit-distance NN (Unicode)'), ('knn_raw', 'Char n-gram kNN (Unicode)'),
        ('nonet', 'PolyNET without window network'), ('netonly', 'Window network only')]
rows = []
for k, n in BASE:
    seeds = SEEDS if k == 'netonly' else (0,)
    b = per_lang(k, True, seeds=seeds); d = np.round(poly - b, 10)            # remove float noise from seed averaging
    p = wilcoxon(poly, b, zero_method='zsplit').pvalue if np.any(d != 0) else 1.0
    rows.append([k, n, 100 * b.mean(), 100 * d.mean(), *(100 * boot_ci(d)), p, int((d > 0).sum()), int((d < 0).sum())])
padj = holm([r[6] for r in rows])
# fix: rows layout = [k, n, acc, diff, lo, hi, p, win, loss]
ST['main_rows'] = [dict(k=r[0], acc=r[2], diff=r[3], lo=r[4], hi=r[5], p=r[6], padj=float(pa), win=r[7], loss=r[8])
                   for r, pa in zip(rows, padj)]
with open(P + 'tab_rev_main.tex', 'w') as f:
    f.write(f"PolyNET (mean of 3 seeds) & {ST['poly_me']:.1f} & -- & -- & -- & -- \\\\\n\\midrule\n")
    for d in ST['main_rows']:
        f.write(f"{dict(BASE)[d['k']]} & {d['acc']:.1f} & {d['diff']:+.1f} & [{d['lo']:+.1f}, {d['hi']:+.1f}] & "
                f"{d['win']}/{d['loss']} & {sci(d['padj'])} \\\\\n")

# ---------------------------------------------------------------- B. where does the network help?
SC = {l: F[l][1]['script'] for l in LT}
dnet = np.round(poly - per_lang('nonet', True), 10)
ST['net_by_script'] = {s: (float(100 * dnet[[SC[l] == s for l in LT]].mean()), int(sum(SC[l] == s for l in LT)))
                       for s in sorted(set(SC.values()))}
catd = defaultdict(list)
for l in LT:
    V, m = F[l]; y = np.array(m['y']); c = np.array(m['cats'])
    a = np.mean([(me(method_probs(V, m, 'polynet', s)) == y) for s in SEEDS], 0)
    b = (me(method_probs(V, m, 'nonet')) == y).astype(float)
    for cat in ('number', 'unit', 'weekday', 'month'):
        catd[cat] += list((a - b)[c == cat])
ST['net_by_cat'] = {k: float(100 * np.mean(v)) for k, v in catd.items()}

# ---------------------------------------------------------------- C. lexical-support strata (Setting C)
BINS = [(0, .5), (.5, .7), (.7, .85), (.85, 1.01)]
strata = defaultdict(lambda: defaultdict(list)); nb = Counter()
for l in LT:
    V, m = F[l]; y = np.array(m['y']); t = test_idx(m)
    sup = V['view3'][t][np.arange(len(y)), y]                    # best AWED match among same-concept training words
    preds = {'polynet': np.mean([(me(method_probs(V, m, 'polynet', s)) == y) for s in SEEDS], 0),
             'awed': (me(method_probs(V, m, 'awed')) == y).astype(float),
             'logreg': (me(method_probs(V, m, 'logreg')) == y).astype(float),
             'netonly': np.mean([(me(method_probs(V, m, 'netonly', s)) == y) for s in SEEDS], 0),
             'nonet': (me(method_probs(V, m, 'nonet')) == y).astype(float)}
    for i, s_ in enumerate(sup):
        b = next(j for j, (lo, hi) in enumerate(BINS) if lo <= s_ < hi); nb[b] += 1
        for k, v in preds.items(): strata[k][b].append(v[i])
ST['strata'] = {k: [float(100 * np.mean(v[b])) if v[b] else None for b in range(4)] for k, v in strata.items()}
ST['strata_n'] = [nb[b] for b in range(4)]

# ---------------------------------------------------------------- D. script holdout (Setting B)
sh = defaultdict(list)
for l in LT:
    V, m = F[l]
    if not m['sh_removed']: continue
    y = np.array(m['y']); t = test_idx(m)
    std = acc(fuse(V, sl=t), y, True)
    Vs = {f'view{v}': V[f'sh_view{v}'] for v in range(4)}
    L_ = WP[0] * Vs['view0'] + sum(WP[v] * Vs[f'view{v}'] / TP for v in (1, 2, 3))
    shp = acc(sm(L_), y, True); sha = acc(sm(Vs['view3'] / TP), y, True); sta = acc(sm(V['view3'][t] / TP), y, True)
    sh[m['script']].append((std, shp, sta, sha, len(m['sh_removed'])))
ST['script_holdout'] = {s: dict(n=len(v), removed=int(np.mean([x[4] for x in v])),
                                std=float(100 * np.mean([x[0] for x in v])), sh=float(100 * np.mean([x[1] for x in v])),
                                awed_std=float(100 * np.mean([x[2] for x in v])), awed_sh=float(100 * np.mean([x[3] for x in v])))
                        for s, v in sh.items()}
with open(P + 'tab_rev_script.tex', 'w') as f:
    for s, d in sorted(ST['script_holdout'].items(), key=lambda x: -x[1]['n']):
        f.write(f"{s} & {d['n']} & {d['removed']} & {d['std']:.1f} & {d['sh']:.1f} & {d['awed_std']:.1f} & {d['awed_sh']:.1f} \\\\\n")

# ---------------------------------------------------------------- E. hard vs soft exclusivity
def soft_me(Pm, gamma, kmax):
    """min sum -log p + gamma * (number of extra uses of an already-used concept)."""
    k, C_ = Pm.shape; cost = -np.log(Pm + 1e-12)
    big = np.concatenate([cost] + [cost + gamma] * (kmax - 1), 1)
    r, c = linear_sum_assignment(big); o = np.empty(k, int); o[r] = c % C_; return o
def sessions(langs, d, gamma_list, n=150, k=8, seed=0):
    rng = np.random.default_rng(seed); res = defaultdict(list)
    for l in langs:
        V, m = F[l]; y = np.array(m['y']); kind = np.array(m['kind'])
        Pall = np.mean([fuse(V, seed=s) for s in SEEDS], 0)
        ti = np.where(kind == 'test')[0]; di = np.where(kind == 'dup')[0]
        for _ in range(n):
            pick = rng.choice(len(ti), min(k, len(ti)), replace=False)
            dup = rng.choice(pick, min(d, len(pick)), replace=False) if d else np.array([], int)
            idx = np.r_[ti[pick], di[dup]]; yy = np.r_[y[pick], y[dup]]
            Pm = Pall[idx]
            res['independent'].append((Pm.argmax(1) == yy).mean())
            res['hard'].append((me(Pm) == yy).mean())
            for g in gamma_list: res[f'soft{g}'].append((soft_me(Pm, g, d + 1) == yy).mean())
    return {k_: float(100 * np.mean(v)) for k_, v in res.items()}
G = [0.5, 1, 2, 4, 8, 16]
dev_s = {d: sessions(LD, d, G) for d in (0, 1, 2, 4)}
gbest = max(G, key=lambda g: np.mean([dev_s[d][f'soft{g}'] for d in dev_s]))
ST['soft_gamma'] = gbest; ST['soft_dev'] = dev_s
test_s = {d: sessions(LT, d, [gbest], seed=1) for d in (0, 1, 2, 4)}
ST['soft_test'] = test_s
# whole-vocabulary session (the main-study setting): does soft ME keep the ME gain?
fv = defaultdict(list)
for l in LT:
    V, m = F[l]; y = np.array(m['y'])
    for s_ in SEEDS:
        Pm = method_probs(V, m, 'polynet', s_)
        fv['independent'].append((Pm.argmax(1) == y).mean()); fv['hard'].append((me(Pm) == y).mean())
        fv['soft'].append((soft_me(Pm, gbest, 2) == y).mean())
ST['soft_fullvocab'] = {k: float(100 * np.mean(v)) for k, v in fv.items()}
# trade-off over gamma on the TEST languages (reported, not used for selection)
trade = {}
for g in G:
    fa = np.mean([np.mean([(soft_me(method_probs(*F[l], 'polynet', s_), g, 2) == np.array(F[l][1]['y'])).mean() for s_ in SEEDS]) for l in LT])
    ds4 = sessions(LT, 4, [g], n=60, seed=2)[f'soft{g}']
    trade[g] = (float(100 * fa), ds4)
ST['soft_trade'] = trade
# example where hard ME errs on a duplicate
ex = None
for l in LT:
    V, m = F[l]; y = np.array(m['y']); kind = np.array(m['kind']); q = m['q']
    Pall = np.mean([fuse(V, seed=s) for s in SEEDS], 0)
    ti = np.where(kind == 'test')[0]; di = np.where(kind == 'dup')[0]
    for j in range(len(ti)):
        if Pall[di[j]].argmax() == y[j] and Pall[ti[j]].argmax() == y[j] and q[ti[j]] != q[di[j]]:
            idx = np.r_[ti, di[j]]; o = me(Pall[idx])
            if o[-1] != y[j] or o[j] != y[j]:
                ex = dict(lang=l, word=q[ti[j]], variant=q[di[j]], concept=CONCEPTS[y[j]],
                          hard=[CONCEPTS[o[j]], CONCEPTS[o[-1]]], soft=[CONCEPTS[x] for x in soft_me(Pall[idx], gbest, 2)[[j, -1]]])
                break
    if ex: break
ST['me_example'] = ex

# ---------------------------------------------------------------- F. temperature, calibration, open set
def ece(conf, corr, nb=15):
    e = 0; edges = np.linspace(0, 1, nb + 1)
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.any(): e += m.mean() * abs(conf[m].mean() - corr[m].mean())
    return float(e)
def auroc(pos, neg):
    pos, neg = np.asarray(pos), np.asarray(neg)
    return float((pos[:, None] > neg[None]).mean() + .5 * (pos[:, None] == neg[None]).mean())
def pooled(langs, fn):
    conf, corr, br = [], [], []
    for l in langs:
        V, m = F[l]; y = np.array(m['y']); Pm = fn(V, m)
        conf += list(Pm.max(1)); corr += list(Pm.argmax(1) == y)
        oh = np.zeros_like(Pm); oh[np.arange(len(y)), y] = 1; br += list(((Pm - oh) ** 2).sum(1))
    return np.array(conf), np.array(corr, float), float(np.mean(br))
TS_ = [.005, .01, .02, .05, .1, .2, .5, 1.0]
temp = {}
for T in TS_:
    c, k, b = pooled(LT, lambda V, m: method_probs(V, m, 'polynet', 0, T))
    a_me = 100 * per_lang('polynet', True, T=T).mean(); a_in = 100 * per_lang('polynet', False, T=T).mean()
    au = {}
    for kd in ('dis_country', 'dis_unit'):
        vals = []
        for l in LT:
            V, m = F[l]; kind = np.array(m['kind'])
            if not (kind == kd).any(): continue
            Pf = fuse(V, T=T)
            vals.append(auroc(Pf[kind == 'test'].max(1), Pf[kind == kd].max(1)))
        au[kd] = float(np.mean(vals))
    temp[T] = dict(acc=a_in, acc_me=a_me, ece=ece(c, k), brier=b, au_country=au['dis_country'], au_unit=au['dis_unit'])
ST['temperature'] = temp
# temperature for calibration chosen on dev languages by NLL
def nll(langs, T):
    s = 0; n = 0
    for l in langs:
        V, m = F[l]; y = np.array(m['y']); Pm = method_probs(V, m, 'polynet', 0, T)
        s -= np.log(Pm[np.arange(len(y)), y] + 1e-300).sum(); n += len(y)
    return s / n
Tcal = min(TS_, key=lambda T: nll(LD, T)); ST['T_cal'] = Tcal
with open(P + 'tab_rev_temp.tex', 'w') as f:
    for T in TS_:
        d = temp[T]; mark = ' (paper)' if T == TP else (' (calib.)' if T == Tcal else '')
        f.write(f"{T:g}{mark} & {d['acc']:.1f} & {d['acc_me']:.1f} & {d['ece']:.3f} & {d['brier']:.3f} & "
                f"{d['au_country']:.3f} & {d['au_unit']:.3f} \\\\\n")
# risk-coverage / selective accuracy
def risk_cov(fn, langs=LT):
    c, k, _ = pooled(langs, fn); o = np.argsort(-c); acc_ = np.cumsum(k[o]) / np.arange(1, len(k) + 1)
    cov = np.arange(1, len(k) + 1) / len(k); return cov, acc_, float(np.mean(1 - acc_))
RC = {'polynet T=0.02': risk_cov(lambda V, m: method_probs(V, m, 'polynet', 0, TP)),
      f'polynet T={Tcal:g}': risk_cov(lambda V, m: method_probs(V, m, 'polynet', 0, Tcal)),
      'awed': risk_cov(lambda V, m: method_probs(V, m, 'awed')),
      'logreg': risk_cov(lambda V, m: method_probs(V, m, 'logreg'))}
ST['aurc'] = {k: v[2] for k, v in RC.items()}
ST['sel_acc_at_50'] = {k: float(v[1][int(.5 * len(v[1])) - 1] * 100) for k, v in RC.items()}
ST['sel_acc_at_80'] = {k: float(v[1][int(.8 * len(v[1])) - 1] * 100) for k, v in RC.items()}
# open-set: country vs unit distractors, PolyNET vs AWED (max posterior and energy)
def energy(V, m, sl):
    L = WP[0] * V['view0_s0'][sl] + sum(WP[v] * V[f'view{v}'][sl] / TP for v in (1, 2, 3))
    mx = L.max(1); return mx + np.log(np.exp(L - mx[:, None]).sum(1))
op = defaultdict(list)
for l in LT:
    V, m = F[l]; kind = np.array(m['kind'])
    for kd in ('dis_country', 'dis_unit'):
        if not (kind == kd).any(): continue
        op[f'poly_energy|{kd}'].append(auroc(energy(V, m, kind == 'test'), energy(V, m, kind == kd)))
        op[f'awed|{kd}'].append(auroc(V['view3'][kind == 'test'].max(1), V['view3'][kind == kd].max(1)))
        op[f'logreg|{kd}'].append(auroc(V['logreg'][kind == 'test'].max(1), V['logreg'][kind == kd].max(1)))
ST['open'] = {k: float(np.mean(v)) for k, v in op.items()}

# ---------------------------------------------------------------- G. speech: recogniser vs grounding error
import sys; sys.path.insert(0, SPEECH_DIR)
if os.path.exists(SPEECH_DIR + '/out2/fold_en_real.npz'):
    z = np.load(SPEECH_DIR + '/out2/fold_en_real.npz', allow_pickle=True); sm_ = json.loads(str(z['meta']))
    PHO = json.load(open(SPEECH_DIR + '/cache/g2p.json'))
    from rapidfuzz.distance import Levenshtein as Lev
    yy = np.array(sm_['y']); qq = sm_['q']
    ref = [PHO[f"en|{CONCEPTS[t]}"] for t in yy]
    per = np.array([Lev.distance(a, b) / max(len(b), 1) for a, b in zip(qq, ref)])
    num = np.array([c.startswith('num_') for c in CONCEPTS])
    def slot_acc(key, sel):
        Pm = z[key].astype(float)[sel].copy(); Pm[:, ~num] = 0; return float(100 * (Pm.argmax(1) == yy[sel]).mean())
    PB = [(0, .01), (.01, .34), (.34, .67), (.67, 9)]
    ST['speech_per'] = dict(mean=float(per.mean()), exact=float(100 * (per == 0).mean()),
                            bins=[dict(lo=lo, hi=hi, n=int(((per >= lo) & (per < hi)).sum()),
                                       polys=slot_acc('polys', (per >= lo) & (per < hi)),
                                       invocab=slot_acc('invocab_polys', (per >= lo) & (per < hi)),
                                       awed=slot_acc('base_awed_t', (per >= lo) & (per < hi))) for lo, hi in PB])
else:  # speech scores not present: keep the stored speech numbers
    ST['speech_per'] = json.load(open('results/revision.json'))['speech_per']

# ---------------------------------------------------------------- figures
fig, axs = plt.subplots(1, 3, figsize=(W2, 2.15), gridspec_kw={'wspace': .38, 'width_ratios': [1.15, 1, 1]})
o = np.argsort(dnet); axs[0].bar(range(len(LT)), 100 * dnet[o], color=[BLUE if v > 0 else ORANGE for v in dnet[o]])
axs[0].axhline(0, color=INK, lw=.6); axs[0].set_xticks(range(len(LT)), [LT[i] if abs(dnet[i]) > 1e-9 else '' for i in o], rotation=90, fontsize=5.5)
axs[0].text(len(LT) / 2, -3.2, f'{int((np.abs(dnet) < 1e-9).sum())} languages:\nno change', ha='center', fontsize=6)
axs[0].set_ylabel('Accuracy change (pp)'); axs[0].set_title('(a) Full $-$ no window network'); axs[0].grid(axis='x', visible=False)
xb = np.arange(4); wb = .2
for i, (k, c, lab) in enumerate((('awed', ORANGE, 'AWED NN'), ('logreg', YELLOW, 'n-gram log. reg.'),
                                 ('netonly', GRAY, 'window net only'), ('polynet', BLUE, 'PolyNET'))):
    axs[1].bar(xb + (i - 1.5) * wb, [ST['strata'][k][b] or 0 for b in range(4)], wb * .92, color=c, label=lab)
axs[1].set_xticks(xb, [f'<0.5\n({nb[0]})', f'0.5-0.7\n({nb[1]})', f'0.7-0.85\n({nb[2]})', f'$\\geq$0.85\n({nb[3]})'], fontsize=6)
axs[1].set_xlabel('Lexical support'); axs[1].set_ylabel('Accuracy + ME (%)')
axs[1].set_title('(b) Cognate strata'); axs[1].legend(frameon=False, fontsize=5, loc='upper left', ncol=2); axs[1].grid(axis='x', visible=False)
axs[1].set_ylim(0, 132); axs[1].set_yticks(range(0, 101, 20))
ds_ = [0, 1, 2, 4]
for k, c, mk, lab in (('independent', GRAY, 's', 'independent'), ('hard', ORANGE, '^', 'hard ME'),
                      (f'soft{gbest}', BLUE, 'o', f'soft ME ($\\gamma$={gbest:g})')):
    axs[2].plot(ds_, [test_s[d][k] for d in ds_], color=c, marker=mk, mec='white', label=lab)
axs[2].set_xticks(ds_); axs[2].set_xlabel('Repeated concepts in 8-word session'); axs[2].set_ylabel('Accuracy (%)')
axs[2].set_title('(c) Exclusivity violated'); axs[2].legend(frameon=False, fontsize=5.5)
fig.savefig(P + 'fig_rev.pdf'); plt.close()

fig, axs = plt.subplots(1, 2, figsize=(W2, 2.0), gridspec_kw={'wspace': .3})
for (k, (cov, a, _)), c in zip(RC.items(), (BLUE, AQUA, ORANGE, YELLOW)):
    axs[0].plot(cov * 100, a * 100, color=c, label=k.replace('polynet', 'PolyNET').replace('awed', 'AWED NN').replace('logreg', 'n-gram log. reg.'))
axs[0].set_xlabel('Coverage (% of words answered)'); axs[0].set_ylabel('Accuracy on answered words (%)')
axs[0].set_title('(a) Selective grounding'); axs[0].legend(frameon=False, fontsize=5.5, loc='lower left')
for T, c, lab in ((TP, BLUE, f'T={TP:g} (paper)'), (Tcal, AQUA, f'T={Tcal:g} (dev NLL)')):
    cf, k, _ = pooled(LT, lambda V, m: method_probs(V, m, 'polynet', 0, T))
    edges = np.linspace(0, 1, 11); xs, ys = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        mm = (cf > lo) & (cf <= hi)
        if mm.sum() >= 5: xs.append(cf[mm].mean()); ys.append(k[mm].mean())
    axs[1].plot(xs, ys, color=c, marker='o', ms=3, mec='white', label=lab)
axs[1].plot([0, 1], [0, 1], ls=':', color=INK, lw=.7)
axs[1].set_xlabel('Confidence'); axs[1].set_ylabel('Observed accuracy'); axs[1].set_title('(b) Reliability')
axs[1].legend(frameon=False, fontsize=5.5, loc='upper left')
fig.savefig(P + 'fig_rev_cal.pdf'); plt.close()

json.dump(ST, open('results/revision.json', 'w'), indent=1, default=float)
print(json.dumps({k: v for k, v in ST.items() if k not in ('soft_dev',)}, indent=1, default=float)[:9000])
