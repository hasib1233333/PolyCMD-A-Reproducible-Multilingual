"""Benchmark audit for PolyCMD (review request: document locale fallbacks, romanisation
failures, ambiguous forms and the effect of related languages).

Re-derives every candidate entry exactly as build_lexicon.py does, but records WHY a
candidate was dropped, and checks that the kept set is identical to lexicon.json.
Output: results/audit.json, paper/tab_audit.tex
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import os, re, json, sys, subprocess, importlib.util
from collections import Counter, defaultdict
os.chdir(TEXT_DIR)
src = open('build_lexicon.py').read().split('rows = []')[0]          # definitions only, no side effects
ns = {}; exec(src, ns)
LANGS, UNITS, DAYS, MONTHS, clean, number_word = ns['LANGS'], ns['UNITS'], ns['DAYS'], ns['MONTHS'], ns['clean'], ns['number_word']
from babel.units import format_unit
from models import romanize
R = json.load(open('lexicon.json'))

drop = defaultdict(Counter); cand = []
for code, (loc, fam) in LANGS.items():
    ent = [(f'num_{n}', 'number', number_word(code, n)) for n in range(1, 11)]
    for c, key in UNITS.items():
        p = format_unit(1, key, length='long', locale=loc)
        if key in p:
            drop['long form missing, short used'][code] += 1
            p = format_unit(1, key, length='short', locale=loc)
        w = clean(p)
        if re.fullmatch(r'[a-z]{1,3}', w): drop['abbreviation only (dropped)'][code] += 1; continue
        ent.append((c, 'unit', w))
    cal = json.loads(subprocess.check_output([sys.executable, '-c',
        "import json;from babel.dates import get_month_names as M,get_day_names as D;"
        f"print(json.dumps([D('wide','stand-alone',locale='{loc}')[i] for i in range(7)]+"
        f"[M('wide','stand-alone',locale='{loc}')[i] for i in range(1,13)]))"]))
    for i, d in enumerate(DAYS + MONTHS): ent.append((d, 'weekday' if i < 7 else 'month', cal[i]))
    for concept, cat, w in ent:
        if cat in ('month', 'weekday') and re.search(r'\d', w): drop['numeric calendar form (dropped)'][code] += 1; continue
        w = clean(w)
        if not w or not any(ch.isalpha() for ch in w) or re.search(r'length|duration|angle|mass|volume', w):
            drop['no localized form / CLDR key fallback (dropped)'][code] += 1; continue
        cand.append((code, concept, w))
dup = Counter((l, w) for l, _, w in cand)
for l, c, w in cand:
    if dup[(l, w)] > 1: drop['homograph within language (dropped)'][l] += 1
kept = sorted((l, c, w) for l, c, w in cand if dup[(l, w)] == 1)
same = kept == sorted((r['lang'], r['concept'], r['word']) for r in R)
print('re-derived set identical to lexicon.json:', same)

# romanisation checks
rom = [romanize(r['word']) for r in R]
fail = [(r['lang'], r['word']) for r, s in zip(R, rom) if s == '?']
short = [(r['lang'], r['word'], s) for r, s in zip(R, rom) if len(s) <= 2 and s != '?']
coll = Counter((r['lang'], s) for r, s in zip(R, rom))
collide = sorted({(r['lang'], s) for r, s in zip(R, rom) if coll[(r['lang'], s)] > 1})
# cross-language false friends: identical romanised form, different concept, other language
by_form = defaultdict(set)
for r, s in zip(R, rom): by_form[s].add((r['lang'], r['concept']))
ff = sum(any(l2 != r['lang'] and c2 != r['concept'] for l2, c2 in by_form[s]) for r, s in zip(R, rom))
exact = sum(any(l2 != r['lang'] and c2 == r['concept'] for l2, c2 in by_form[s]) for r, s in zip(R, rom))
A = dict(identical=same, n=len(R), drops={k: dict(v) for k, v in drop.items()},
         drop_totals={k: sum(v.values()) for k, v in drop.items()},
         rom_fail=fail, rom_short=len(short), rom_short_examples=short[:12],
         rom_collisions=[list(x) for x in collide], false_friend_words=ff, exact_cognate_words=exact,
         missing_per_lang={l: 43 - sum(r['lang'] == l for r in R) for l in LANGS})
os.makedirs('results', exist_ok=True); json.dump(A, open('results/audit.json', 'w'), ensure_ascii=False, indent=1)
print(json.dumps({k: v for k, v in A.items() if k not in ('rom_collisions', 'missing_per_lang', 'drops')}, ensure_ascii=False, indent=1))
print('collisions', len(collide), collide[:10])
with open('paper/tab_audit.tex', 'w') as f:
    for k, v in A['drop_totals'].items():
        langs = ', '.join(f'{l}\\,({n})' for l, n in sorted(A['drops'][k].items(), key=lambda x: -x[1])[:6])
        f.write(f"{k} & {v} & {langs} \\\\\n")
