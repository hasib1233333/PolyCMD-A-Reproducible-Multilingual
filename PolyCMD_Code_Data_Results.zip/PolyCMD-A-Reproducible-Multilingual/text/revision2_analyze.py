"""Analysis of the second-review experiments (rev2/*.npz) and, when present, the pretrained
encoder embeddings (pretrained/emb_*.npz from pretrained_embed.py).
  A. family holdout: PolyNET vs baselines (and encoders) when the whole family is removed
  B. PolyCMD-U: 11 languages outside the encoders' pretraining data
Output: results/revision2.json, paper/tab_family.tex, paper/tab_uncovered.tex, paper/fig_uncovered.pdf
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import os, json, glob, numpy as np, matplotlib
os.chdir(TEXT_DIR)
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon
from scipy.optimize import linear_sum_assignment
exec(open('figures.py').read().split("D = {json")[0])
from common import R, TEST, CONCEPTS, CID
WP = (1, 1, .5, 1); TP = .02; SEEDS = (0, 1, 2)
FAM = {r['lang']: r['family'] for r in R}
U = json.load(open('lexicon_uncovered.json')); UA = json.load(open('uncovered_audit.json'))
def sm(L): L = L - L.max(1, keepdims=True); E = np.exp(L); return E / E.sum(1, keepdims=True)
def me(P): r, c = linear_sum_assignment(-np.log(P + 1e-12)); o = P.argmax(1).copy(); o[r] = c; return o
def acc(P, y): return float((me(P) == y).mean())
def poly(V, s): return sm(WP[0] * V[f'view0_s{s}'] + sum(WP[v] * V[f'view{v}'] / TP for v in (1, 2, 3)))
BASE = {'AWED NN': lambda V: sm(V['view3'] / TP), 'Edit-distance NN': lambda V: sm(V['edit_rom'] / TP),
        'Char n-gram kNN': lambda V: sm(V['knn_rom'] / TP), 'Char n-gram log.\\ reg.': lambda V: sm(V['logreg'])}
def boot(d, B=10000):
    r = np.random.default_rng(0); return np.percentile([r.choice(d, len(d)).mean() for _ in range(B)], [2.5, 97.5])
def holm(ps):
    o = np.argsort(ps); adj = np.empty(len(ps)); run = 0
    for i, j in enumerate(o): run = max(run, min(1, (len(ps) - i) * ps[j])); adj[j] = run
    return adj
def sci(x):
    if x >= 0.1: return f'${x:.2f}$' if x < 1 else '$1.00$'
    e = int(np.floor(np.log10(x))); return f'${x / 10 ** e:.2f}\\times10^{{{e}}}$'
def pval(a, b): return float(wilcoxon(a, b, zero_method='zsplit').pvalue) if np.any(np.round(a - b, 10) != 0) else 1.0

# pretrained embeddings (optional)
EMB = {}
for k, n in [('LaBSE', 'LaBSE'), ('multilingual-e5-base', 'multilingual-E5-base'),
             ('paraphrase-multilingual-mpnet-base-v2', 'multilingual-MPNet-base')]:
    f = f'pretrained/emb_{k}.npz'
    if os.path.exists(f): z = np.load(f); EMB[n] = (z['E'], int(z['n_main']))
yA = np.array([CID[r['concept']] for r in R]); lA = np.array([r['lang'] for r in R])
def enc_scores(E, nm, q_idx, mem_mask):
    S = E[q_idx] @ E[:nm][mem_mask].T; ym = yA[mem_mask]; out = np.full((len(q_idx), len(CONCEPTS)), -1.0)
    for c in range(len(CONCEPTS)):
        m = ym == c
        if m.any(): out[:, c] = S[:, m].max(1)
    return sm(out / TP)

ST = {'encoders_available': list(EMB)}
# ---------------------------------------------------------------- A. family holdout
FF = {}
for f in glob.glob('rev2/fam_*.npz'):
    z = np.load(f, allow_pickle=True); m = json.loads(str(z['meta'])); FF[m['lang']] = ({k: z[k].astype(float) for k in z.files if k != 'meta'}, m)
LF = [l for l in TEST if l in FF]
REV = {}
for l in LF:
    z = np.load(f'rev/fold_{l}.npz', allow_pickle=True); m = json.loads(str(z['meta'])); t = np.array([k == 'test' for k in m['kind']])
    REV[l] = {k: z[k].astype(float)[t] for k in z.files if k != 'meta' and len(z[k]) == len(t)}
fam = {'lang': LF, 'family': [FAM[l] for l in LF], 'removed': {l: FF[l][1]['removed'] for l in LF}}
p_f = np.array([np.mean([acc(poly(FF[l][0], s), np.array(FF[l][1]['y'])) for s in SEEDS]) for l in LF])
p_l = np.array([np.mean([acc(poly(REV[l], s), np.array(FF[l][1]['y'])) for s in SEEDS]) for l in LF])
fam['polynet'] = dict(fam=float(100 * p_f.mean()), lolo=float(100 * p_l.mean()))
rows = []; ps = []
for nm, fn in BASE.items():
    b = np.array([acc(fn(FF[l][0]), np.array(FF[l][1]['y'])) for l in LF])
    bl = np.array([acc(fn(dict(REV[l], knn_rom=REV[l]['view1'])), np.array(FF[l][1]['y'])) for l in LF])
    d = np.round(p_f - b, 10); lo, hi = boot(d); ps.append(pval(p_f, b))
    rows.append(dict(name=nm, lolo=float(100 * bl.mean()), fam=float(100 * b.mean()), diff=float(100 * d.mean()), lo=float(100 * lo), hi=float(100 * hi),
                     win=int((d > 0).sum()), loss=int((d < 0).sum())))
ABL = {'PolyNET without window network': lambda V, s: sm(sum(WP[v] * V[f'view{v}'] / TP for v in (1, 2, 3))),
       'Window network only': lambda V, s: sm(V[f'view0_s{s}'])}
for nm, fn in ABL.items():
    b = np.array([np.mean([acc(fn(FF[l][0], s), np.array(FF[l][1]['y'])) for s in SEEDS]) for l in LF])
    bl = np.array([np.mean([acc(fn(REV[l], s), np.array(FF[l][1]['y'])) for s in SEEDS]) for l in LF])
    d = np.round(p_f - b, 10); lo, hi = boot(d); ps.append(pval(p_f, b))
    rows.append(dict(name=nm, lolo=float(100 * bl.mean()), fam=float(100 * b.mean()), diff=float(100 * d.mean()), lo=float(100 * lo), hi=float(100 * hi),
                     win=int((d > 0).sum()), loss=int((d < 0).sum())))
for nm, (E, nmain) in EMB.items():
    b = np.array([acc(enc_scores(E, nmain, np.where(lA == l)[0], np.array([FAM[x] != FAM[l] for x in lA])),
                      yA[lA == l]) for l in LF])
    d = np.round(p_f - b, 10); lo, hi = boot(d); ps.append(pval(p_f, b))
    rows.append(dict(name=nm + '$^\\ddagger$', lolo=float('nan'), fam=float(100 * b.mean()), diff=float(100 * d.mean()), lo=float(100 * lo), hi=float(100 * hi),
                     win=int((d > 0).sum()), loss=int((d < 0).sum())))
for r_, pa in zip(rows, holm(np.array(ps))): r_['padj'] = float(pa)
fam['rows'] = rows; fam['per_lang'] = {l: (float(100 * a), float(100 * b)) for l, a, b in zip(LF, p_f, p_l)}
ST['family'] = fam
with open('paper/tab_family.tex', 'w') as f:
    f.write(f"PolyNET (3 seeds) & {fam['polynet']['lolo']:.1f} & {fam['polynet']['fam']:.1f} & -- & -- & -- & -- \\\\\n\\midrule\n")
    for r_ in rows:
        f.write(f"{r_['name']} & {('--' if r_['lolo'] != r_['lolo'] else format(r_['lolo'], '.1f'))} & {r_['fam']:.1f} & {r_['diff']:+.1f} & [{r_['lo']:+.1f}, {r_['hi']:+.1f}] & {r_['win']}/{r_['loss']} & {sci(r_['padj'])} \\\\\n")

# ---------------------------------------------------------------- B. PolyCMD-U
z = np.load('rev2/unc.npz', allow_pickle=True); m = json.loads(str(z['meta'])); V = {k: z[k].astype(float) for k in z.files if k != 'meta'}
lang = np.array(m['lang']); y = np.array(m['y']); LU = list(dict.fromkeys(lang))
def per(Ps): return np.array([np.mean([acc(P[lang == l], y[lang == l]) for P in Ps]) for l in LU])
meth = {'PolyNET (3 seeds)': per([poly(V, s) for s in SEEDS])}
for nm, fn in BASE.items(): meth[nm] = per([fn(V)])
for nm, (E, nmain) in EMB.items():
    P = enc_scores(E, nmain, np.arange(nmain, nmain + len(U)), np.ones(nmain, bool)); meth[nm + '$^\\ddagger$'] = per([P])
unc = {'langs': LU, 'n': {l: int((lang == l).sum()) for l in LU}, 'acc': {k: dict(zip(LU, map(float, 100 * v))) for k, v in meth.items()},
       'mean': {k: float(100 * v.mean()) for k, v in meth.items()}}
pn = meth['PolyNET (3 seeds)']; cmp_ = {}
for k, v in meth.items():
    if k.startswith('PolyNET'): continue
    d = np.round(pn - v, 10); lo, hi = boot(d)
    cmp_[k] = dict(diff=float(100 * d.mean()), lo=float(100 * lo), hi=float(100 * hi), win=int((d > 0).sum()), loss=int((d < 0).sum()), p=pval(pn, v))
unc['cmp'] = cmp_
# support: best AWED similarity to a same-concept PolyCMD word
sup = V['view3'][np.arange(len(y)), y]
unc['low_support_frac'] = float((sup < .5).mean())
ST['uncovered'] = unc
json.dump(ST, open('results/revision2.json', 'w'), indent=1)
NAME = {'fo': 'Faroese', 'se': 'N.\\ Sami', 'kl': 'Kalaallisut', 'qu': 'Quechua', 'vec': 'Venetian', 'ak': 'Akan', 'ee': 'Ewe',
        'ff': 'Fula', 'chr': 'Cherokee', 'ccp': 'Chakma', 'lrc': 'N.\\ Luri'}
cols = ['PolyNET (3 seeds)', 'AWED NN'] + [k for k in meth if k.endswith('$^\\ddagger$')]
with open('paper/tab_uncovered.tex', 'w') as f:
    for l in LU:
        best = max(unc['acc'][c][l] for c in cols)
        cells = [(f"\\textbf{{{unc['acc'][c][l]:.0f}}}" if unc['acc'][c][l] == best else f"{unc['acc'][c][l]:.0f}") for c in cols]
        f.write(f"{NAME[l]} & {UA[l]['script']} & {next(r['family'] for r in U if r['lang'] == l)} & {unc['n'][l]} & " + ' & '.join(cells) + ' \\\\\n')
    f.write('\\midrule\nMean & & & ' + f"{sum(unc['n'].values())} & " + ' & '.join(f"{unc['mean'][c]:.1f}" for c in cols) + ' \\\\\n')
open('paper/tab_uncovered_spec.tex', 'w').write('\\def\\NUNC{%d}\n' % len(cols))
with open('paper/tab_uncovered_cols.tex', 'w') as f:
    f.write(' & '.join(['PolyNET', 'AWED'] + [k.replace('multilingual-', 'm').replace('-base', '').replace('$^\\ddagger$', '') for k in cols[2:]]))
print(json.dumps({'family': {k: v for k, v in fam.items() if k not in ('per_lang', 'removed')}, 'unc_mean': unc['mean'], 'cmp': cmp_}, indent=1))
