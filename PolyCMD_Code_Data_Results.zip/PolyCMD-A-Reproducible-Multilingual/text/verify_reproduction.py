"""End-to-end reproduction check for the PolyCMD release.

Run from inside text/:   python verify_reproduction.py

1. MD5 checksums of the released lexicons.
2. Rebuild of PolyCMD and PolyCMD-U from CLDR, compared with the released files.
3. Retraining of one held-out language (Bengali) from scratch, compared with rev/fold_bn.npz.
4. Regeneration of the text-study tables from the stored scores, compared byte by byte
   with paper/tab_*.tex.

All work is done in a temporary copy, so the released files are never changed.
"""
import hashlib, json, os, shutil, subprocess, sys, tempfile
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
MD5 = {'lexicon.json': 'c7e3034679b6e992fd6c003c8f12a11d',
       'lexicon_uncovered.json': '56d6472863e5dd443261924c61f36ad9',
       'distractors.json': '2ed25763790f2d522f92d2d98df34907'}
ANALYSES = ['revision_analyze.py', 'pretrained_analyze.py', 'revision2_analyze.py',
            'clarify_analyze.py', 'threshold_analyze.py', 'audit_lexicon.py']
failed = []


def md5(p):
    return hashlib.md5(open(p, 'rb').read()).hexdigest()


def report(name, ok, detail=''):
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f'  ({detail})' if detail else ''), flush=True)
    if not ok:
        failed.append(name)


def run(script, *args, cwd):
    r = subprocess.run([sys.executable, script, *args], cwd=cwd, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-2000:], r.stderr[-2000:])
    return r.returncode == 0


tmp = tempfile.mkdtemp(prefix='polycmd_verify_')
shutil.copytree(os.path.join(ROOT, 'text'), os.path.join(tmp, 'text'))
shutil.copytree(os.path.join(ROOT, 'speech'), os.path.join(tmp, 'speech'))
T = os.path.join(tmp, 'text')

# 1. checksums
for f, h in MD5.items():
    report(f'MD5 {f}', md5(os.path.join(HERE, f)) == h)

# 2. rebuild from CLDR
ok = run('build_lexicon.py', cwd=T) and run('build_uncovered.py', cwd=T)
for f in ('lexicon.json', 'lexicon_uncovered.json', 'distractors.json'):
    report(f'rebuild {f}', ok and md5(os.path.join(T, f)) == MD5[f])

# 3. retrain Bengali
ref = np.load(os.path.join(HERE, 'rev', 'fold_bn.npz'), allow_pickle=True)
os.remove(os.path.join(T, 'rev', 'fold_bn.npz'))
ok = run('revision_run.py', 'bn', cwd=T)
if ok:
    new = np.load(os.path.join(T, 'rev', 'fold_bn.npz'), allow_pickle=True)
    keys = [k for k in ref.files if k != 'meta']
    worst = max(float(np.max(np.abs(ref[k].astype(float) - new[k].astype(float)))) for k in keys)
    report('retrain bn', worst < 1e-6 and str(ref['meta']) == str(new['meta']), f'max abs difference {worst:.2e}')
else:
    report('retrain bn', False, 'revision_run.py failed')

# 4. regenerate tables
ref_tabs = {f: open(os.path.join(HERE, 'paper', f), 'rb').read()
            for f in os.listdir(os.path.join(HERE, 'paper')) if f.startswith('tab_')}
shutil.copy(os.path.join(HERE, 'rev', 'fold_bn.npz'), os.path.join(T, 'rev', 'fold_bn.npz'))
for f in os.listdir(os.path.join(T, 'paper')):
    if f.startswith('tab_'):
        os.remove(os.path.join(T, 'paper', f))
for s in ANALYSES:
    report(f'run {s}', run(s, cwd=T))
for f, b in sorted(ref_tabs.items()):
    p = os.path.join(T, 'paper', f)
    if os.path.exists(p):
        report(f'table {f}', open(p, 'rb').read() == b)

shutil.rmtree(tmp, ignore_errors=True)
print('ALL CHECKS PASSED' if not failed else f'{len(failed)} CHECK(S) FAILED: ' + ', '.join(failed))
sys.exit(1 if failed else 0)
