import json, numpy as np, matplotlib
from common import R, TEST
matplotlib.use('Agg')
import matplotlib.pyplot as plt
exec(open('figures.py').read().split("D = {json")[0])   # shared style constants
S = json.load(open('results/sim.json')); PL = S['per_lang']; LS = sorted(l for l in PL if l in TEST)
M = [('nettalk_raw', 'NETtalk MLP (Unicode)', GRAY), ('knn_raw', 'n-gram kNN (Unicode)', YELLOW),
     ('edit_rom', 'Edit NN (romanized)', AQUA), ('edit_rom+ME', 'Edit NN (rom.) + ME', ORANGE), ('awed+ME', 'AWED NN (rom.) + ME', GREEN),
     ('polynet', 'PolyNET', MAGENTA), ('polynet+ME', 'PolyNET + ME', BLUE)]

fig, axs = plt.subplots(1, 2, figsize=(W2, 2.1), gridspec_kw={'width_ratios': [1.25, 1]})
succ = {m: np.array([PL[l][m]['success'] for l in LS]) * 100 for m, _, _ in M}
y = np.arange(len(M))
axs[0].barh(y, [succ[m].mean() for m, _, _ in M], .6, color=[c for *_, c in M])
for i, (m, _, _) in enumerate(M):
    axs[0].text(succ[m].mean() + 1, i, f'{succ[m].mean():.1f}', va='center', fontsize=6)
axs[0].set_yticks(y, [n for _, n, _ in M]); axs[0].invert_yaxis(); axs[0].grid(axis='y', visible=False)
axs[0].set_xlabel('Program success rate (%)'); axs[0].set_xlim(0, max(succ[m].mean() for m, _, _ in M) * 1.15); axs[0].set_title(f'(a) Full-program success, {len(LS)} unseen languages')
data = [succ[m] for m in ('nettalk_raw', 'awed+ME', 'polynet+ME')]
bp = axs[1].boxplot(data, widths=.5, patch_artist=True, medianprops=dict(color=INK))
for b, c in zip(bp['boxes'], (GRAY, GREEN, BLUE)): b.set_facecolor(c); b.set_alpha(.5)
axs[1].set_xticks([1, 2, 3], ['NETtalk', 'AWED+ME', 'PolyNET+ME'])
axs[1].set_ylabel('Success per language (%)'); axs[1].set_title('(b) Spread over languages')
fig.savefig('paper/fig_sim_success.pdf'); plt.close()

show = [l for l in ['ru', 'ar', 'bn', 'ko', 'am', 'kn'] if l in S['traj']][:4]
fig, axs = plt.subplots(1, len(show), figsize=(W2, 1.9))
for ax, l in zip(axs, show):
    T = S['traj'][l]; t = np.array(T['truth'])
    ax.plot(t[:, 0], t[:, 1], color=INK, lw=2.4, alpha=.25, label='commanded')
    for m, c, ls, mk in (('nettalk_raw', GRAY, ':', 's'), ('edit_rom+ME', ORANGE, '--', '^'), ('polynet+ME', BLUE, '-', 'o')):
        p = np.array(T[m]); ax.plot(p[:, 0], p[:, 1], color=c, ls=ls, marker=mk, ms=3, lw=1, label=m)
    ax.plot(0, 0, marker='*', color=INK, ms=7, lw=0)
    ax.set_title(f'{l} ({__import__("collections").Counter(r["script"] for r in R if r["lang"] == l).most_common(1)[0][0]})'); ax.set_aspect('equal', 'datalim')
    ax.set_xlabel('$x$ (m)')
axs[0].set_ylabel('$y$ (m)')
h, lb = axs[0].get_legend_handles_labels()
fig.legend(h, ['commanded', 'NETtalk MLP (Unicode)', 'Edit NN (rom.) + ME', 'PolyNET + ME'],
           loc='upper center', ncol=4, frameon=False, bbox_to_anchor=(.5, 1.1))
fig.savefig('paper/fig_sim_traj.pdf'); plt.close()
st = {m: {'success': float(succ[m].mean()),
          'pos_err_median': float(np.median([PL[l][m]['pos_err_median'] for l in LS])),
          'pos_err_mean': float(np.mean([PL[l][m]['pos_err_mean'] for l in LS])),
          'time_err_median': float(np.median([PL[l][m]['time_err_median'] for l in LS]))} for m, _, _ in M}
json.dump(st, open('results/sim_stats.json', 'w'), indent=1); print(json.dumps(st, indent=1))
