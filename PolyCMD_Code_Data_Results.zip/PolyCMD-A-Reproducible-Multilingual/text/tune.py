import itertools, json, numpy as np
from common import *; from models import *
cache = {}
for L in DEV:
    Wtr, ytr, Wte, yte, _ = split(L)
    m = PolyNET2(net_kw=dict(epochs=60)).fit(Wtr, ytr, C)
    cache[L] = (m.view_scores(Wte), yte); print('done', L, flush=True)
best = []
for wn, wr, ws, wa, T in itertools.product([0, .5, 1], [0, .5, 1], [0, .25, .5], [0, .5, 1], [.02, .05, .1]):
    if wr + ws + wa == 0: continue
    w = (wn, wr, ws, wa); Ts = (1, T, T, T); ai, am = [], []
    for L, (S, y) in cache.items():
        P = PolyNET2.fuse(None, S, w, Ts)
        ai.append((P.argmax(1) == y).mean()); am.append((mutual_exclusivity(P) == y).mean())
    best.append((np.mean(am), np.mean(ai), w, T))
best.sort(key=lambda x: -x[0])
for b in best[:8]: print(b)
json.dump({'weights': best[0][2], 'T': best[0][3], 'dev_ME': best[0][0], 'dev_ind': best[0][1]}, open('results/tuned.json', 'w'))
