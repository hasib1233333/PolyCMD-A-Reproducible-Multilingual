"""Nine of the world's ten most-spoken languages (Mandarin excluded by design): per-language results (figure + table)."""
import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import Counter
exec(open('figures.py').read().split("D = {json")[0])      # shared style
from common import R, DEV
# approximate total speakers (L1+L2, millions), Ethnologue-based figures as listed by the author
TOP = [('en', 'English', 1490), ('hi', 'Hindi', 611), ('es', 'Spanish', 561),
       ('ar', 'Arabic (MSA)', 335), ('fr', 'French', 334), ('bn', 'Bengali', 274),
       ('pt', 'Portuguese', 269), ('ru', 'Russian', 255), ('ur', 'Urdu', 232)]
SIM = json.load(open('results/sim.json'))['per_lang']
F = {c: json.load(open(f'results/fold_{c}.json')) for c, _, _ in TOP}
script = {c: Counter(r['script'] for r in R if r['lang'] == c).most_common(1)[0][0] for c, _, _ in TOP}
meths = [('nettalk_raw', 'NETtalk MLP (Unicode)', GRAY, 's'), ('awed+ME', 'AWED NN (rom.) + ME', ORANGE, '^'),
         ('polynet+ME', 'PolyNET + ME (proposed)', BLUE, 'o')]
fig, ax = plt.subplots(figsize=(W2, 2.3))
x = np.arange(len(TOP)); w = .26
for i, (m, lab, c, _) in enumerate(meths):
    v = [100 * F[k]['acc'][m] for k, _, _ in TOP]
    ax.bar(x + (i - 1) * w, v, w * .92, color=c, label=lab)
    if m == 'polynet+ME':
        for xi, vi in zip(x, v): ax.text(xi + w, vi + 1.5, f'{vi:.0f}', ha='center', fontsize=6)
ax.set_xticks(x, [f"{n}{'*' if k in DEV else ''}\n{script[k]}\n" + (f"{s/1000:.2f} B" if s >= 1000 else f"{s} M")
                  for k, n, s in TOP], fontsize=6)
ax.set_ylabel('LOLO top-1 accuracy (%)'); ax.set_ylim(0, 110); ax.grid(axis='x', visible=False)
ax.legend(frameon=False, ncol=3, loc='upper center', bbox_to_anchor=(.5, 1.18))
fig.savefig('paper/fig_top10.pdf'); plt.close()
tot = sum(s for _, _, s in TOP)
def _row(vals_acc, vals_sim):
    def b(vs):
        m = max(vs); return [f'\\textbf{{{v:.1f}}}' if abs(v - m) < 1e-9 else f'{v:.1f}' for v in vs]
    return ' & '.join(b(vals_acc) + b(vals_sim))
wavg = lambda g: sum(g(k) * s for k, _, s in TOP) / tot
with open('paper/tab_top10.tex', 'w') as f:
    for k, n, s in TOP:
        a = F[k]['acc']
        acc = [100 * a['nettalk_raw'], 100 * a['awed+ME'], 100 * a['polynet+ME']]
        sim = [100 * SIM[k]['nettalk_raw']['success'], 100 * SIM[k]['polynet+ME']['success']]
        f.write(f"{n}{'$^*$' if k in DEV else ''} & {script[k]} & {s:,}".replace(',', '{,}') + ' & ' + _row(acc, sim) + ' \\\\\n')
    f.write('\\midrule\n')
    acc = [wavg(lambda k, m=m: 100 * F[k]['acc'][m]) for m in ('nettalk_raw', 'awed+ME', 'polynet+ME')]
    sim = [wavg(lambda k, m=m: 100 * SIM[k][m]['success']) for m in ('nettalk_raw', 'polynet+ME')]
    f.write(f'Speaker-weighted mean & & {tot:,}'.replace(',', '{,}') + ' & ' + _row(acc, sim) + ' \\\\\n')
print(open('paper/tab_top10.tex').read())
st = {k: {m: F[k]['acc'][m] for m, *_ in meths} for k, _, _ in TOP}
json.dump(st, open('results/top10.json', 'w'), indent=1)
