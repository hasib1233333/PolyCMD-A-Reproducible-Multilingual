"""Write paper/numbers.tex: every number quoted in the text comes from results/."""
import json, numpy as np
from common import *
st = json.load(open('results/stats.json')); sm = json.load(open('results/sim_stats.json'))
def sci(x, d=2):
    e = int(np.floor(np.log10(abs(x)))); m = x / 10 ** e
    if e == 0: return f'{x:.{d}f}'
    return f'\\ensuremath{{{m:.{d}f}\\times10^{{{e}}}}}'
M = st['mean']; pct = lambda m: f'{100 * M[m]:.1f}'
mac = {
 'NLex': len(R), 'NDis': len(DIS), 'NLang': len(LANGS), 'NTest': st['n_test'],
 'NScript': len({r['script'] for r in R}), 'NFam': len({r['family'] for r in R}),
 'MeanLen': f"{np.mean([len(r['word']) for r in R]):.1f}",
 'NLatin': sum(r['script'] == 'Latin' for r in R), 'NCyr': sum(r['script'] == 'Cyrillic' for r in R),
 'NOther': sum(r['script'] not in ('Latin', 'Cyrillic') for r in R),
 'NParams': f'{(7 * 45 + 1) * 96 + 97 * 43:,}'.replace(',', '{,}'),
 'NParamsKB': f'{((7 * 45 + 1) * 96 + 97 * 43) * 4 / 1024:.0f}',
 'AccPolyME': pct('polynet+ME'), 'AccPoly': pct('polynet'), 'AccNettalk': pct('nettalk_raw'),
 'AccNettalkME': pct('nettalk_raw+ME'), 'AccNetPhon': pct('net_phon'),
 'AccKnnRaw': pct('knn_raw'), 'AccKnnRom': pct('knn_rom'), 'AccEditRaw': pct('edit_raw'),
 'AccEditRom': pct('edit_rom'), 'AccAwed': pct('awed'),
 'AccBestBaseME': pct(st['best_base'] + '+ME'), 'AccBestBase': pct(st['best_base']),
 'PvsBest': sci(st['p_vs_best']), 'PvsNettalk': sci(st['p_vs_nettalk']), 'PME': sci(st['p_me']),
 'AurocPoly': sci(st['auroc'].get('polynet_energy') or st['auroc']['polynet']), 'AurocPolyMax': sci(st['auroc']['polynet']), 'AurocKnnRaw': sci(st['auroc']['knn_raw']),
 'AurocEditRom': sci(st['auroc']['edit_rom']), 'AurocAwed': sci(st['auroc']['awed']),
 'SeedStdPolyME': sci(100 * st['seed_std']['polynet+ME'] + 1e-12),
 'SimNettalk': f"{sm['nettalk_raw']['success']:.1f}", 'SimPolyME': f"{sm['polynet+ME']['success']:.1f}",
 'SimPoly': f"{sm['polynet']['success']:.1f}", 'SimEditME': f"{sm['edit_rom+ME']['success']:.1f}",
 'SimKnnRaw': f"{sm['knn_raw']['success']:.1f}", 'SimEdit': f"{sm['edit_rom']['success']:.1f}",
}
fs = st['fewshot']
mac.update({'FSzeroME': f"{fs['0'][1]:.1f}", 'FSfiveME': f"{fs['5'][1]:.1f}", 'FStwentyME': f"{fs['20'][1]:.1f}",
            'FSfive': f"{fs['5'][0]:.1f}", 'FStwenty': f"{fs['20'][0]:.1f}"})
ss = st['session']
mac.update({'SessOne': f"{ss['1']:.1f}", 'SessEight': f"{ss['8']:.1f}", 'SessAll': f"{ss['43']:.1f}"})
nz = st['noise']
mac.update({'NzPolyMEthirty': f"{nz['polynet+ME'][-1]:.1f}", 'NzNettalkThirty': f"{nz['nettalk_raw'][-1]:.1f}",
            'NzEditMEthirty': f"{nz['edit_rom+ME'][-1]:.1f}", 'NzKnnRawThirty': f"{nz['knn_raw'][-1]:.1f}"})
LSm = json.load(open('results/langsim.json'))
for key, name in (('edit_raw', 'LangSimRaw'), ('awed_rom', 'LangSimRom')):
    A = np.array(LSm[key]); mac[name] = sci(A[~np.eye(len(A), dtype=bool)].mean())
if st['auroc'].get('polynet_energy'):
    mac['AurocEnergy'] = sci(st['auroc']['polynet_energy']); mac['FARninetyfive'] = f"{100 * st['far_at_95']:.1f}"
mac['SimErrNettalk'] = sci(sm['nettalk_raw']['pos_err_mean']); mac['SimErrPolyME'] = sci(sm['polynet+ME']['pos_err_mean'])
mac['SimErrEditME'] = sci(sm['edit_rom+ME']['pos_err_mean'])
mac['SimAwedME'] = f"{sm['awed+ME']['success']:.1f}"
from scipy.stats import wilcoxon
_S = json.load(open('results/sim.json'))['per_lang']
_t = [l for l in TEST if l in _S]
mac['PSimAwed'] = sci(wilcoxon([_S[l]['polynet+ME']['success'] for l in _t], [_S[l]['awed+ME']['success'] for l in _t], alternative='greater').pvalue)
mac['PvsEditME'] = sci(st['p_vs_edit'])
T10 = json.load(open('results/top10.json'))
with open('paper/numbers.tex', 'w') as f:
    for k, v in mac.items():
        if v is not None: f.write(f'\\newcommand{{\\{k}}}{{{v}}}\n')
print(open('paper/numbers.tex').read())
