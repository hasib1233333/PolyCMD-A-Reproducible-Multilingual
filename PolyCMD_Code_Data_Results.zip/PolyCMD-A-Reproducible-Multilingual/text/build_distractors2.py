"""Command-like open-set distractors: CLDR names of measurement units the robot does
NOT support (e.g. inch, mile, millisecond, byte). They are realistic near-misses: same
domain, same morphology, sometimes containing a supported unit as a substring.
Output: distractors_units.json [{lang, word, unit}]"""
import json, re, subprocess, sys
from collections import Counter
R = json.load(open('lexicon.json'))
LOC = {'no': 'nb', 'kz': 'kk'}
UNITS = ['length-mile', 'length-foot', 'length-inch', 'length-yard', 'mass-pound', 'mass-ounce',
         'mass-tonne', 'volume-gallon', 'volume-milliliter', 'duration-millisecond', 'duration-month',
         'duration-year', 'digital-byte', 'energy-joule', 'power-watt', 'electric-volt', 'electric-ampere',
         'frequency-hertz', 'area-hectare', 'force-newton', 'pressure-pascal', 'light-lux']
def clean(s):
    s = re.sub(r'\{0\}', ' ', s); s = re.sub(r'[\d  .,;:()\[\]\-–]+', ' ', s)
    return re.sub(r'\s+', ' ', s).strip().lower()
out = []
for L in sorted({r['lang'] for r in R}):
    loc = LOC.get(L, L)
    names = json.loads(subprocess.check_output([sys.executable, '-c',
        "import json;from babel.units import format_unit as f\n"
        f"o=[]\nfor u in {UNITS!r}:\n"
        "  p=f(1,u,length='long',locale='" + loc + "')\n"
        "  p=p if u not in p else f(1,u,length='short',locale='" + loc + "')\n"
        "  o.append(p)\nprint(json.dumps(o))"]))
    own = {r['word'] for r in R if r['lang'] == L}
    for u, p in zip(UNITS, names):
        w = clean(p)
        if not w or u in p or ' ' in w or re.fullmatch(r'[a-z]{1,3}', w) or w in own:
            continue
        if not any(ch.isalpha() for ch in w): continue
        out.append(dict(lang=L, word=w, unit=u))
json.dump(out, open('distractors_units.json', 'w'), ensure_ascii=False, indent=0)
c = Counter(d['lang'] for d in out)
print(len(out), 'unit distractors;', min(c.values()), '-', max(c.values()), 'per language')
print([d['word'] for d in out if d['lang'] in ('en', 'ru', 'hi')])
