"""Closed-loop robot command-execution simulation.

A differential-drive robot receives spoken/typed programs in a language it
was never trained on. Each program has 6 segments; a segment is
    MOVE <number> <length-unit>      (meter | centimeter | millimeter)
    WAIT <number> <time-unit>        (second | minute | hour)
followed by a fixed 90-degree left turn, plus a schedule header
    <weekday> <month>.
Word meanings come from the held-out-language predictions saved by run_all.py
(the robot's grounding of each word type in that language). A program
succeeds if every slot is grounded correctly.
"""
import json, glob, numpy as np
from common import *

LEN = {'meter': 1.0, 'centimeter': 1e-2, 'millimeter': 1e-3}
TIM = {'second': 1.0, 'minute': 60.0, 'hour': 3600.0}
NUM = {f'num_{n}': n for n in range(1, 11)}
DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august',
          'september', 'october', 'november', 'december']
METHODS = ['nettalk_raw', 'knn_raw', 'edit_rom', 'edit_rom+ME', 'awed+ME', 'polynet', 'polynet+ME']

def execute(prog, ground):
    """Integrate the program; returns path (N,2) and total wait time."""
    x, y, th, wait = 0.0, 0.0, 0.0, 0.0; path = [(x, y)]
    for kind, n, u in prog:
        nn = NUM.get(ground[n], 0)                     # a mis-grounded number -> robot uses 0
        if kind == 'MOVE':
            d = nn * LEN.get(ground[u], 0.0)           # wrong unit type -> no motion
            x += d * np.cos(th); y += d * np.sin(th); path.append((x, y))
        else:
            wait += nn * TIM.get(ground[u], 0.0)
        th += np.pi / 2
    return np.array(path), wait

def main():
    out = {}; traj = {}
    for f in sorted(glob.glob('results/fold_*.json')):
        d = json.load(open(f)); L = d['lang']
        te = [r for r in R if r['lang'] == L]
        have = {r['concept']: i for i, r in enumerate(te)}
        rng = np.random.default_rng(1)
        res = {m: {'succ': [], 'perr': [], 'terr': []} for m in METHODS}
        nums = [c for c in NUM if c in have]; lens = [c for c in LEN if c in have]
        tims = [c for c in TIM if c in have]; days = [c for c in DAYS if c in have]
        mons = [c for c in MONTHS if c in have]
        for trial in range(300):
            prog = []
            for s in range(6):
                if rng.random() < .7 and lens: prog.append(('MOVE', rng.choice(nums), rng.choice(lens)))
                elif tims: prog.append(('WAIT', rng.choice(nums), rng.choice(tims)))
            hdr = [rng.choice(days), rng.choice(mons)] if days and mons else []
            truth = {c: c for c in have}
            P0, W0 = execute(prog, truth)
            for m in METHODS:
                g = {c: CONCEPTS[d['pred'][m][i]] for c, i in have.items()}
                P1, W1 = execute(prog, g)
                ok = all(g[n] == n and g[u] == u for _, n, u in prog) and all(g[h] == h for h in hdr)
                res[m]['succ'].append(ok)
                res[m]['perr'].append(float(np.linalg.norm(P1[-1] - P0[-1])))
                res[m]['terr'].append(abs(W1 - W0))
        # demonstration program for the trajectory figure: 7 x (MOVE <n> metre; turn 90 deg)
        if 'meter' in have:
            demo = [('MOVE', c, 'meter') for c in np.random.default_rng(3).choice(nums, 7)]
            truth = {c: c for c in have}; traj[L] = {'truth': execute(demo, truth)[0].tolist(),
                                                      'words': [c for _, c, _ in demo]}
            for m in METHODS:
                g = {c: CONCEPTS[d['pred'][m][i]] for c, i in have.items()}
                traj[L][m] = execute(demo, g)[0].tolist()
        out[L] = {m: {'success': float(np.mean(v['succ'])), 'pos_err_median': float(np.median(v['perr'])),
                      'pos_err_mean': float(np.mean(v['perr'])), 'time_err_median': float(np.median(v['terr']))}
                  for m, v in res.items()}
    json.dump({'per_lang': out, 'traj': traj}, open('results/sim.json', 'w'))
    for m in METHODS:
        print(m, 'success %.3f' % np.mean([out[L][m]['success'] for L in out if L in TEST]),
              'pos_err %.3e' % np.mean([out[L][m]['pos_err_mean'] for L in out if L in TEST]))

if __name__ == '__main__':
    main()
