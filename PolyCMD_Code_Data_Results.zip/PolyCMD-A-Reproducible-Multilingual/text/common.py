import json, numpy as np
R = json.load(open('lexicon.json'))
DIS = json.load(open('distractors.json'))
CONCEPTS = sorted({r['concept'] for r in R}); CID = {c: i for i, c in enumerate(CONCEPTS)}; C = len(CONCEPTS)
LANGS = sorted({r['lang'] for r in R})
DEV = ['en', 'fr', 'pl', 'tr', 'fa', 'te', 'th', 'he']          # hyper-parameter selection only (fixed before zh, hi, ur were added)
TEST = [l for l in LANGS if l not in DEV]
def split(L):
    tr = [r for r in R if r['lang'] != L]; te = [r for r in R if r['lang'] == L]
    return ([r['word'] for r in tr], [CID[r['concept']] for r in tr],
            [r['word'] for r in te], np.array([CID[r['concept']] for r in te]), te)
def softmax_sim(S, T=0.05):
    L = S / T; L = L - L.max(1, keepdims=True); P = np.exp(L); return P / P.sum(1, keepdims=True)
