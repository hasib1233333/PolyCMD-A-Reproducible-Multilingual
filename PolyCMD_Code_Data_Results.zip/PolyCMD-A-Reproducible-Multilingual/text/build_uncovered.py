"""PolyCMD-U: command words in 11 languages that are NOT in the pretraining data of LaBSE
(109 languages, Feng et al. 2022, Table 10), XLM-R (100 languages; basis of multilingual-E5
and multilingual-MPNet) or paraphrase-multilingual-MPNet (50+ languages).

Same sources and filters as build_lexicon.py (CLDR via Babel; numbers from CLDR RBNF via
unicode-rbnf), plus an explicit check against CLDR fallbacks: any form equal to the
CLDR root value (e.g. 'Mon', 'length-meter') is a fallback, not a word of the language.
Output: lexicon_uncovered.json, uncovered_audit.json
"""
import json, re, sys, subprocess, unicodedata
from collections import Counter
from babel.units import format_unit
from unicode_rbnf import RbnfEngine

LANGS = {  # code: (name, family, script)
 'fo': ('Faroese', 'Germanic'), 'se': ('Northern Sami', 'Uralic'), 'kl': ('Kalaallisut', 'Eskimo-Aleut'),
 'qu': ('Quechua', 'Quechuan'), 'vec': ('Venetian', 'Romance'), 'ak': ('Akan', 'Niger-Congo'),
 'ee': ('Ewe', 'Niger-Congo'), 'ff': ('Fula', 'Niger-Congo'), 'chr': ('Cherokee', 'Iroquoian'),
 'ccp': ('Chakma', 'Indo-Aryan'), 'lrc': ('Northern Luri', 'Iranian'),
}
UNITS = {'meter':'length-meter','centimeter':'length-centimeter','millimeter':'length-millimeter',
         'kilometer':'length-kilometer','second':'duration-second','minute':'duration-minute',
         'hour':'duration-hour','day':'duration-day','week':'duration-week',
         'degree':'angle-degree','radian':'angle-radian','kilogram':'mass-kilogram',
         'gram':'mass-gram','liter':'volume-liter'}
DAYS = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday']
MONTHS = ['january','february','march','april','may','june','july','august',
          'september','october','november','december']

def script_of(word):
    names = [unicodedata.name(ch, 'UNKNOWN').split(' ')[0].title() for ch in word if ch.isalpha()]
    return max(set(names), key=names.count) if names else 'Unknown'

def clean(s):
    s = re.sub(r'\{0\}', ' ', s)
    s = re.sub(r'[\d  .,;:()\[\]\-–]+', ' ', s)
    return re.sub(r'\s+', ' ', s).strip().lower()

def calendar(loc):
    return json.loads(subprocess.check_output([sys.executable, '-c',
        "import json;from babel.dates import get_month_names as M,get_day_names as D;"
        f"print(json.dumps([D('wide','stand-alone',locale='{loc}')[i] for i in range(7)]+"
        f"[M('wide','stand-alone',locale='{loc}')[i] for i in range(1,13)]))"]))

ROOT_CAL = [clean(w) for w in calendar('root')]
ROOT_UNIT = {k: clean(format_unit(1, k, length='long', locale='root')) for k in UNITS.values()}
rows, audit = [], {}
for code, (name, fam) in LANGS.items():
    a = dict(name=name, fallback=[], abbreviation=[], numeric=[], homograph=[])
    ent = [(f'num_{n}', 'number', RbnfEngine.for_language(code).format_number(n).text) for n in range(1, 11)]
    for c, key in UNITS.items():
        p = format_unit(1, key, length='long', locale=code)
        if key in p: p = format_unit(1, key, length='short', locale=code)
        w = clean(p)
        if w == ROOT_UNIT[key] or key in p: a['fallback'].append(c); continue
        if re.fullmatch(r'[a-z]{1,3}', w): a['abbreviation'].append(c); continue
        ent.append((c, 'unit', w))
    cal = calendar(code)
    for i, c in enumerate(DAYS + MONTHS):
        cat = 'weekday' if i < 7 else 'month'
        if re.search(r'\d', cal[i]): a['numeric'].append(c); continue
        if clean(cal[i]) == ROOT_CAL[i]: a['fallback'].append(c); continue
        ent.append((c, cat, cal[i]))
    for c, cat, w in ent:
        w = clean(w)
        if not w or not any(ch.isalpha() for ch in w) or re.search(r'length|duration|angle|mass|volume', w):
            a['fallback'].append(c); continue
        rows.append(dict(lang=code, family=fam, concept=c, category=cat, word=w, script=script_of(w)))
    audit[code] = a
dup = Counter((r['lang'], r['word']) for r in rows)
for r in rows:
    if dup[(r['lang'], r['word'])] > 1: audit[r['lang']]['homograph'].append(r['concept'])
rows = [r for r in rows if dup[(r['lang'], r['word'])] == 1]
for code in LANGS:
    audit[code]['n'] = sum(r['lang'] == code for r in rows)
    audit[code]['script'] = Counter(r['script'] for r in rows if r['lang'] == code).most_common(1)[0][0]
json.dump(rows, open('lexicon_uncovered.json', 'w'), ensure_ascii=False, indent=0)
json.dump(audit, open('uncovered_audit.json', 'w'), ensure_ascii=False, indent=1)
print(len(rows), 'entries')
for c, a in audit.items(): print(c, a['n'], a['script'], {k: v for k, v in a.items() if isinstance(v, list) and v})
