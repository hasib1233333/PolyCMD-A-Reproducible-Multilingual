"""Controlled experiments requested in review. For every held-out language L, saves:
  * PolyNET per-view scores (window network for seeds 0,1,2; memory views are deterministic)
    on: the test words, country-name distractors, command-like unit distractors, and one
    noisy variant of every test word (for exclusivity stress tests);
  * baselines on the same queries: n-gram kNN and edit NN on raw Unicode and on romanisation,
    and a trained character n-gram logistic-regression classifier (romanised);
  * a script-holdout model: training languages that share L's script are also removed.
Usage: python3 revision_run.py <lang> ...   -> rev/fold_<lang>.npz
"""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import sys, os, json, numpy as np
sys.path.insert(0, SPEECH_DIR); sys.path.insert(0, TEXT_DIR)
import ground
from ground import PolyNETS, W, TS
os.chdir(TEXT_DIR)
from collections import Counter
from common import R, DIS, CID, C
from models import romanize, raw, NgramKNN, ngrams
from rapidfuzz.process import cdist
from rapidfuzz.distance import Levenshtein
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import CountVectorizer
os.makedirs('rev', exist_ok=True)
DU = json.load(open('distractors_units.json'))
SCRIPT = {l: Counter(r['script'] for r in R if r['lang'] == l).most_common(1)[0][0] for l in {r['lang'] for r in R}}

def corrupt(w, p, rng):
    s = list(w.replace(' ', ''))
    if len(s) < 2: return w
    out = []
    for ch in s:
        r = rng.random()
        if r < p / 3: continue
        if r < 2 * p / 3: out.append(s[rng.integers(len(s))]); continue
        out.append(ch)
        if r < p: out.append(ch)
    return ''.join(out) or w

def edit_scores(q, W_, y):
    S = cdist(q, W_, scorer=Levenshtein.normalized_similarity); y = np.asarray(y)
    out = np.full((len(q), C), -1.0)
    for c in range(C):
        m = y == c
        if m.any(): out[:, c] = S[:, m].max(1)
    return out

def run(L):
    tr = [r for r in R if r['lang'] != L]; te = [r for r in R if r['lang'] == L]
    y = [CID[r['concept']] for r in tr]; yt = [CID[r['concept']] for r in te]
    rng = np.random.default_rng(11)
    Qu = [r['word'] for r in te] + [d['word'] for d in DIS if d['lang'] == L] + \
         [d['word'] for d in DU if d['lang'] == L] + [corrupt(r['word'], .15, rng) for r in te]
    kind = ['test'] * len(te) + ['dis_country'] * sum(d['lang'] == L for d in DIS) + \
           ['dis_unit'] * sum(d['lang'] == L for d in DU) + ['dup'] * len(te)
    Qr = [romanize(w) for w in Qu]
    Wr = [romanize(r['word']) for r in tr]; Wu = [raw(r['word']) for r in tr]
    out = {}
    for s in (0, 1, 2):
        m = PolyNETS(W, TS, net_kw=dict(epochs=60), seed=s).fit(Wr, y, C)
        V = m.view_scores(Qr)
        out[f'view0_s{s}'] = V[0].astype(np.float32)
        if s == 0:
            for v in (1, 2, 3): out[f'view{v}'] = V[v].astype(np.float32)
    out['knn_raw'] = NgramKNN(raw).fit(Wu, y, C).scores([raw(w) for w in Qu]).astype(np.float32)
    out['edit_raw'] = edit_scores([raw(w) for w in Qu], Wu, y).astype(np.float32)
    out['edit_rom'] = edit_scores(Qr, Wr, y).astype(np.float32)
    vec = CountVectorizer(analyzer=lambda s: ngrams(s, (1, 2, 3)))
    X = vec.fit_transform(Wr)
    lr = LogisticRegression(C=10.0, max_iter=3000).fit(X, y)
    P = np.full((len(Qr), C), 1e-12); P[:, lr.classes_] = lr.predict_proba(vec.transform(Qr))
    out['logreg'] = np.log(P).astype(np.float32)
    # script holdout
    trs = [r for r in tr if SCRIPT[r['lang']] != SCRIPT[L]]
    removed = sorted({r['lang'] for r in tr} - {r['lang'] for r in trs})
    if removed:
        ms = PolyNETS(W, TS, net_kw=dict(epochs=60), seed=0).fit([romanize(r['word']) for r in trs],
                                                                  [CID[r['concept']] for r in trs], C)
        Vs = ms.view_scores(Qr[:len(te)])
        for v in range(4): out[f'sh_view{v}'] = Vs[v].astype(np.float32)
    meta = dict(lang=L, y=yt, kind=kind, q=Qu, script=SCRIPT[L], sh_removed=removed,
                cats=[r['category'] for r in te], concept_train_count=Counter(y).most_common(1)[0][1])
    np.savez_compressed(f'rev/fold_{L}.npz', **out, meta=json.dumps(meta, ensure_ascii=False))
    pr = (out['view3'][:len(te)].argmax(1) == np.array(yt)).mean()
    print(L, len(te), 'awed', round(float(pr), 3), 'sh_removed', len(removed), flush=True)

if __name__ == '__main__':
    for L in sys.argv[1:]: run(L)
