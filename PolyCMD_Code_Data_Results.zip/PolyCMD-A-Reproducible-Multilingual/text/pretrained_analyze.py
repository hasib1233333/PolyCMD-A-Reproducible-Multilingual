"""Pretrained multilingual baselines vs PolyNET (scores computed by pretrained_baseline.py
on the author's machine; same LOLO protocol). Paired tests, lexical-support strata,
and a product-of-experts fusion of PolyNET with LaBSE (weights chosen on dev languages)."""
import os as _os
_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
TEXT_DIR = _os.path.join(_ROOT, 'text'); SPEECH_DIR = _os.path.join(_ROOT, 'speech')
import os, json, glob, itertools, numpy as np
os.chdir(TEXT_DIR)
from scipy.stats import wilcoxon
from scipy.optimize import linear_sum_assignment
from common import R, TEST, DEV, CONCEPTS
PRE = TEXT_DIR + '/pretrained/'
MODELS = [('LaBSE', 'LaBSE'), ('multilingual-e5-base', 'multilingual-E5-base'),
          ('paraphrase-multilingual-mpnet-base-v2', 'multilingual-MPNet-base')]
WP = (1, 1, .5, 1); TP = .02
lang_all = np.array([r['lang'] for r in R])
S = {k: np.load(PRE + f'pretrained_scores_{k}.npz')['scores'].astype(float) for k, _ in MODELS}
F = {}
for f in glob.glob('rev/fold_*.npz'):
    z = np.load(f, allow_pickle=True); m = json.loads(str(z['meta']))
    F[m['lang']] = ({k: z[k].astype(float) for k in z.files if k != 'meta'}, m)
LT = [l for l in TEST if l in F]; LD = [l for l in DEV if l in F]

def sm(L): L = L - L.max(1, keepdims=True); E = np.exp(L); return E / E.sum(1, keepdims=True)
def me(P):
    r, c = linear_sum_assignment(-np.log(P + 1e-12)); o = P.argmax(1).copy(); o[r] = c; return o
def tidx(m): return np.array([k == 'test' for k in m['kind']])
def poly_logits(l, seed):
    V, m = F[l]; t = tidx(m)
    return WP[0] * V[f'view0_s{seed}'][t] + sum(WP[v] * V[f'view{v}'][t] / TP for v in (1, 2, 3))
def pre_scores(k, l):
    s = S[k][lang_all == l]; assert len(s) == len(F[l][1]['y']); return s
def acc_me(P, y): return float((me(P) == y).mean())
def boot(d, B=10000):
    r = np.random.default_rng(0); return np.percentile([r.choice(d, len(d)).mean() for _ in range(B)], [2.5, 97.5])

ST = {}
ys = {l: np.array(F[l][1]['y']) for l in F}
poly = np.array([np.mean([acc_me(sm(poly_logits(l, s)), ys[l]) for s in (0, 1, 2)]) for l in LT])
ST['poly'] = float(100 * poly.mean())
for k, name in MODELS:
    a = np.array([acc_me(sm(pre_scores(k, l) / TP), ys[l]) for l in LT]); d = np.round(a - poly, 10)
    lo, hi = boot(d)
    ST[k] = dict(name=name, acc_me=float(100 * a.mean()), diff=float(100 * d.mean()), lo=float(100 * lo), hi=float(100 * hi),
                 wins=int((d > 0).sum()), losses=int((d < 0).sum()), p=float(wilcoxon(a, poly, zero_method='zsplit').pvalue),
                 per_lang={l: float(x) for l, x in zip(LT, a)})
# lexical-support strata (support = best AWED similarity to same-concept training words)
BINS = [(0, .5), (.5, .7), (.7, .85), (.85, 1.01)]
strat = {n: [[] for _ in BINS] for n in ['polynet'] + [k for k, _ in MODELS]}
for l in LT:
    V, m = F[l]; t = tidx(m); y = ys[l]; sup = V['view3'][t][np.arange(len(y)), y]
    preds = {'polynet': np.mean([me(sm(poly_logits(l, s))) == y for s in (0, 1, 2)], 0)}
    for k, _ in MODELS: preds[k] = (me(sm(pre_scores(k, l) / TP)) == y).astype(float)
    for i, s_ in enumerate(sup):
        b = next(j for j, (lo, hi) in enumerate(BINS) if lo <= s_ < hi)
        for n in strat: strat[n][b].append(preds[n][i])
ST['strata'] = {n: [float(100 * np.mean(v)) for v in vs] for n, vs in strat.items()}
ST['strata_n'] = [len(v) for v in strat['polynet']]
# fusion PolyNET + LaBSE, weight and temperature chosen on dev languages
def fused(l, w, Tl, seed=0): return sm(poly_logits(l, seed) + w * pre_scores('LaBSE', l) / Tl)
grid = list(itertools.product([0, .25, .5, 1, 2, 4], [.01, .02, .05, .1]))
dev = {(w, Tl): np.mean([acc_me(fused(l, w, Tl), ys[l]) for l in LD]) for w, Tl in grid}
labse_dev = np.mean([acc_me(sm(pre_scores('LaBSE', l) / TP), ys[l]) for l in LD])
wb, Tb = max(dev, key=dev.get)
fz = np.array([np.mean([acc_me(fused(l, wb, Tb, s), ys[l]) for s in (0, 1, 2)]) for l in LT])
lab = np.array([ST['LaBSE']['per_lang'][l] for l in LT])
d = np.round(fz - lab, 10); lo, hi = boot(d)
ST['fusion'] = dict(w=wb, T=Tb, dev=float(100 * dev[(wb, Tb)]), labse_dev=float(100 * labse_dev), acc_me=float(100 * fz.mean()),
                    diff_vs_labse=float(100 * d.mean()), lo=float(100 * lo), hi=float(100 * hi),
                    wins=int((d > 0).sum()), losses=int((d < 0).sum()),
                    p=float(wilcoxon(fz, lab, zero_method='zsplit').pvalue) if np.any(d != 0) else 1.0)
# languages where PolyNET beats LaBSE
ST['poly_beats_labse'] = sorted([(l, float(100 * p_), float(100 * q)) for l, p_, q in zip(LT, poly, lab) if p_ > q + 1e-9],
                                key=lambda x: x[2] - x[1])
ST['labse_worst'] = sorted([(l, float(100 * q)) for l, q in zip(LT, lab)], key=lambda x: x[1])[:6]
json.dump(ST, open('results/pretrained.json', 'w'), indent=1)
def sci(x):
    e = int(np.floor(np.log10(x))); return f'${x / 10 ** e:.2f}\\times10^{{{e}}}$'
with open('paper/tab_pretrained.tex', 'w') as f:
    f.write(f"PolyNET (ours, 3 seeds) & 34.5\\,k & {ST['poly']:.1f} & -- & -- & -- \\\\\n\\midrule\n")
    size = {'LaBSE': '471\\,M', 'multilingual-e5-base': '278\\,M', 'paraphrase-multilingual-mpnet-base-v2': '278\\,M'}
    for k, n in MODELS:
        s = ST[k]
        f.write(f"{n} & {size[k]} & {s['acc_me']:.1f} & {s['diff']:+.1f} & [{s['lo']:+.1f}, {s['hi']:+.1f}] & {sci(s['p'])} \\\\\n")
    fu = ST['fusion']
    f.write(f"\\midrule\nPolyNET $\\times$ LaBSE (fusion) & 471\\,M & {fu['acc_me']:.1f} & {fu['diff_vs_labse']:+.1f}$^\\dagger$ & "
            f"[{fu['lo']:+.1f}, {fu['hi']:+.1f}]$^\\dagger$ & {sci(fu['p'])}$^\\dagger$ \\\\\n")
print(json.dumps({k: v for k, v in ST.items() if k not in MODELS[0][0]}, indent=1, default=float)[:3000])
for k, _ in MODELS: print(k, {a: b for a, b in ST[k].items() if a != 'per_lang'})
