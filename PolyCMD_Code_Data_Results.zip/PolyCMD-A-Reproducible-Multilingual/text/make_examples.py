import json, subprocess
from models import romanize
R = json.load(open('lexicon.json'))
by = {}
for r in R: by.setdefault(r['lang'], {})[r['concept']] = r
langs = ['en','hi','es','ar','fr','bn','pt','ru','ur','am','th','ja','ko','kn','vi']   # world top-10 first
cons = ['num_3','num_7','meter','second','degree','monday','march']
NATIVE = {'Latin','Cyrillic','Ethiopic','Thai','Bengali','Han','Kana','Hangul','Devanagari'}
def cell(L, c):
    r = by[L].get(c)
    if not r: return '--'
    w = r['word']; rom = romanize(w)
    if r['script'] == 'Latin': return w
    f = {'Han':'\\jp ','Kana':'\\jp ','Hangul':'\\kr ','Devanagari':'\\dv '}.get(r['script'], '')
    if L == 'zh': f = '\\zhf '
    if r['script'] in NATIVE: return f'{{{f}{w}}}\\newline{{\\scriptsize\\ttfamily {rom}}}'
    return f'{{\\scriptsize\\ttfamily {rom}}}$^\\dagger$'
scr = {L: by[L]['meter']['script'] for L in langs}; scr['ja'] = 'Han/Kana'; scr['zh'] = 'Han'
hdr = ' & '.join(['Lang.', 'Script'] + ['three','seven','meter','second','degree','Monday','March'])
rows = [f"\\texttt{{{L}}} & {scr[L]} & " + ' & '.join(cell(L, c) for c in cons) + ' \\\\' for L in langs]
doc = r"""\documentclass[border=1pt]{standalone}
\usepackage{fontspec,booktabs,array}
\setmainfont{FreeSerif}\newfontfamily\jp{Noto Sans CJK JP}\newfontfamily\kr{Noto Sans CJK KR}\newfontfamily\zhf{Noto Sans CJK SC}\newfontfamily\dv[Script=Devanagari]{FreeSerif}
\setmonofont{DejaVu Sans Mono}[Scale=0.85]
\begin{document}\footnotesize
\begin{tabular}{@{}ll*{7}{>{\raggedright\arraybackslash}p{13.6mm}}@{}}\toprule
""" + hdr + r" \\ \midrule" + '\n' + '\n'.join(rows) + r"""
\bottomrule\end{tabular}\end{document}"""
open('paper/tab_examples_src.tex', 'w').write(doc)
subprocess.run(['xelatex', '-interaction=nonstopmode', 'tab_examples_src.tex'], cwd='paper', capture_output=True)
print('ok')
