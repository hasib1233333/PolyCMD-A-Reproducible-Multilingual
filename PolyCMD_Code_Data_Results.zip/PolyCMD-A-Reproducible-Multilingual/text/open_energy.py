"""Open-set rejection with the un-normalised fused score (energy-style score:
logsumexp of the fused log-potentials), which is not saturated by the low
temperature the way the max posterior is. Usage: open_energy.py <langs...>"""
import sys, json, numpy as np
from common import *; from models import *
TUNE = json.load(open('results/tuned.json')); W = tuple(TUNE['weights']); T = TUNE['T']; TS = (1, T, T, T)
def energy(m, words):
    S = m.view_scores(words)
    Lg = sum(W[k] * S[k] / TS[k] for k in S)
    mx = Lg.max(1); return mx + np.log(np.exp(Lg - mx[:, None]).sum(1))
import os
for L in sys.argv[1:]:
    if os.path.exists(f'results/energy_{L}.json'): continue
    Wtr, ytr, Wte, yte, _ = split(L); dis = [d['word'] for d in DIS if d['lang'] == L]
    m = PolyNET2(W, TS, net_kw=dict(epochs=60), seed=0).fit(Wtr, ytr, C)
    json.dump({'pos': energy(m, Wte).tolist(), 'neg': energy(m, dis).tolist()}, open(f'results/energy_{L}.json', 'w'))
    print(L, flush=True)
