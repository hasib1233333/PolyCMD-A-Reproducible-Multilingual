"""Build the multilingual robot-command lexicon from verifiable sources.

Sources: Unicode CLDR (via Babel) for unit, weekday and month names;
num2words for cardinal number words. No word is hand-typed.
Output: lexicon.json  [{lang, script, family, concept, category, word}]
"""
import json, re, unicodedata, subprocess, sys
from babel import Locale
from num2words import num2words

# num2words code -> (CLDR locale, family) ; families from standard classifications
LANGS = {
 'en':('en','Germanic'),'de':('de','Germanic'),'nl':('nl','Germanic'),'da':('da','Germanic'),
 'no':('nb','Germanic'),'sv':('sv','Germanic'),'is':('is','Germanic'),
 'fr':('fr','Romance'),'es':('es','Romance'),'pt':('pt','Romance'),'it':('it','Romance'),
 'ro':('ro','Romance'),'ca':('ca','Romance'),
 'ru':('ru','Slavic'),'uk':('uk','Slavic'),'be':('be','Slavic'),'pl':('pl','Slavic'),
 'cs':('cs','Slavic'),'sk':('sk','Slavic'),'sl':('sl','Slavic'),'sr':('sr','Slavic'),
 'lt':('lt','Baltic'),'lv':('lv','Baltic'),
 'fi':('fi','Uralic'),'hu':('hu','Uralic'),
 'tr':('tr','Turkic'),'az':('az','Turkic'),'kz':('kk','Turkic'),
 'ar':('ar','Semitic'),'he':('he','Semitic'),'am':('am','Semitic'),
 'fa':('fa','Iranian'),'tg':('tg','Iranian'),
 'bn':('bn','Indo-Aryan'),
 'kn':('kn','Dravidian'),'te':('te','Dravidian'),
 'th':('th','Kra-Dai'),'vi':('vi','Austroasiatic'),'id':('id','Austronesian'),
 'ja':('ja','Japonic'),'hi':('hi','Indo-Aryan'),'ur':('ur','Indo-Aryan'),'ko':('ko','Koreanic'),'cy':('cy','Celtic'),
}
UNITS = {'meter':'length-meter','centimeter':'length-centimeter','millimeter':'length-millimeter',
         'kilometer':'length-kilometer','second':'duration-second','minute':'duration-minute',
         'hour':'duration-hour','day':'duration-day','week':'duration-week',
         'degree':'angle-degree','radian':'angle-radian','kilogram':'mass-kilogram',
         'gram':'mass-gram','liter':'volume-liter'}
DAYS = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday']
MONTHS = ['january','february','march','april','may','june','july','august',
          'september','october','november','december']

def number_word(code, n):
    """Cardinal number word. num2words where supported; otherwise the CLDR
    RBNF spell-out rules (zh, hi via unicode-rbnf; ur parsed from CLDR's
    common/rbnf/ur.xml, stored in data/)."""
    if code in ('zh', 'hi'):
        from unicode_rbnf import RbnfEngine
        return RbnfEngine.for_language(code).format_number(n).text
    if code == 'ur':
        txt = open('data/cldr_rbnf_ur.xml', encoding='utf-8').read()
        block = txt.split('%spellout-cardinal:')[1]
        return re.search(rf'^\s*{n}: ([^;]+);', block, re.M).group(1)
    return num2words(n, lang=code)

def script_of(word):
    names = []
    for ch in word:
        if ch.isalpha():
            n = unicodedata.name(ch, 'UNKNOWN').split(' ')[0]
            names.append({'CJK':'Han','HIRAGANA':'Kana','KATAKANA':'Kana','HANGUL':'Hangul','DEVANAGARI':'Devanagari'}.get(n, n.title()))
    return max(set(names), key=names.count) if names else 'Unknown'

def clean(s):
    s = re.sub(r'\{0\}', ' ', s)
    s = re.sub(r'[\d  .,;:()\[\]\-–]+', ' ', s)
    s = re.sub(r'\s+', ' ', s).strip().lower()
    return s

rows = []
for code, (loc, fam) in LANGS.items():
    L = Locale.parse(loc)
    entries = []
    for n in range(1, 11):
        entries.append((f'num_{n}', 'number', number_word(code, n)))
    for c, key in UNITS.items():
        from babel.units import format_unit
        p = format_unit(1, key, length='long', locale=loc)
        if key in p:  # CLDR 'long' aliases to 'short' in some locales (ja, ko, fa, vi)
            p = format_unit(1, key, length='short', locale=loc)
        w = clean(p)
        if re.fullmatch(r'[a-z]{1,3}', w):  # abbreviations (s, km, min) are not words
            continue
        entries.append((c, 'unit', w))
    # Babel 2.18 leaks stand-alone month aliases between locales loaded in one
    # process (az -> others), so calendar names are read in a fresh process.
    import subprocess, sys
    cal = json.loads(subprocess.check_output([sys.executable, '-c',
        "import json;from babel.dates import get_month_names as M,get_day_names as D;"
        f"print(json.dumps([D('wide','stand-alone',locale='{loc}')[i] for i in range(7)]+"
        f"[M('wide','stand-alone',locale='{loc}')[i] for i in range(1,13)]))"]))
    for i, d in enumerate(DAYS):
        entries.append((d, 'weekday', cal[i]))
    for i, m in enumerate(MONTHS):
        entries.append((m, 'month', cal[7 + i]))
    for concept, cat, w in entries:
        if cat in ('month', 'weekday') and re.search(r'\d', w):
            continue  # numeric calendar forms (e.g. ja 1月, vi tháng 1) are not lexical words
        w = clean(w)
        if not w or not any(ch.isalpha() for ch in w) or re.search(r'length|duration|angle|mass|volume', w):
            continue  # CLDR fell back to the unit key: no localized form
        rows.append(dict(lang=code, family=fam, concept=concept, category=cat,
                         word=w, script=script_of(w)))

# drop homographs: a surface form naming two concepts in one language is ambiguous
from collections import Counter as _C
dup = _C((r['lang'], r['word']) for r in rows)
rows = [r for r in rows if dup[(r['lang'], r['word'])] == 1]
json.dump(rows, open('lexicon.json', 'w'), ensure_ascii=False, indent=0)

# Open-set distractors: CLDR territory names (real words that are not commands)
import random
random.seed(0)
TERR = ['DE','FR','JP','BR','IN','EG','CA','MX','IT','ES','CN','RU','KE','AR','TR',
        'PL','SE','NO','TH','VN','ID','IR','SA','NG','PE','CL','CO','GR','PT','UA']
dis = []
for code, (loc, fam) in LANGS.items():
    T = json.loads(subprocess.check_output([sys.executable, '-c',
        f"import json;from babel import Locale;L=Locale.parse('{loc}');"
        f"print(json.dumps([L.territories.get(t,'') for t in {TERR!r}]))"]))
    for t in T:
        w = clean(t)
        if w and ' ' not in w and not any(w == r['word'] for r in rows if r['lang'] == code):
            dis.append(dict(lang=code, family=fam, word=w, script=script_of(w)))
json.dump(dis, open('distractors.json', 'w'), ensure_ascii=False, indent=0)
print(len(dis), 'distractor words')
print(len(rows), 'entries;', len(LANGS), 'languages;', len({r['concept'] for r in rows}), 'concepts')
from collections import Counter
print(Counter(r['script'] for r in rows))
print({c:Counter(r['script'] for r in rows if r['lang']==c).most_common(2) for c in LANGS})
for code in ['ru','ar','ja','ko','bn','th','am','kn','he','fa']:
    print(code, [r['word'] for r in rows if r['lang'] == code][:12])
