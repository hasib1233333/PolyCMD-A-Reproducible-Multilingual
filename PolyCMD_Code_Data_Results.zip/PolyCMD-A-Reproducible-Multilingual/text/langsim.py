"""Cross-lingual phonological similarity: mean AWED similarity of translation
equivalents after romanization, raw-Unicode edit similarity for contrast."""
import json, numpy as np
from common import *; from models import awed, _indel, romanize, raw, EditNN
by = {}
for r in R: by.setdefault(r['lang'], {})[r['concept']] = r['word']
Ls = sorted(by, key=lambda l: (R[[x['lang'] for x in R].index(l)]['family'], l))
n = len(Ls); A = np.zeros((n, n)); B = np.zeros((n, n))
for i, a in enumerate(Ls):
    for j, b in enumerate(Ls):
        if j < i: A[i, j] = A[j, i]; B[i, j] = B[j, i]; continue
        sa, sb = [], []
        for c in set(by[a]) & set(by[b]):
            p, q = romanize(by[a][c]), romanize(by[b][c])
            sa.append(1 - awed(p, q) / max(sum(map(_indel, p)), sum(map(_indel, q))))
            u, v = raw(by[a][c]), raw(by[b][c])
            sb.append(1 - EditNN.lev(u, v) / max(len(u), len(v)))
        A[i, j], B[i, j] = np.mean(sa), np.mean(sb)
fam = {r['lang']: r['family'] for r in R}
json.dump({'langs': Ls, 'fam': [fam[l] for l in Ls], 'awed_rom': A.tolist(), 'edit_raw': B.tolist()},
          open('results/langsim.json', 'w'))
off = ~np.eye(n, dtype=bool)
print('mean off-diag sim: romanized AWED %.3f  raw edit %.3f' % (A[off].mean(), B[off].mean()))
