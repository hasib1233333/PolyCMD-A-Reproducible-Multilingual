"""Representations and models for multilingual robot word grounding.

Proposed: PolyNET -- a NETtalk-style sliding-window network operating on a
script-invariant phonological code, fused with an n-gram prototype memory.
All models are implemented in NumPy only.
"""
import numpy as np, unicodedata, re
from anyascii import anyascii

# ---------------------------------------------------------------- encoders
def romanize(w):
    """Script bridge: Unicode -> lowercase Latin approximation."""
    r = anyascii(unicodedata.normalize('NFC', w)).lower()
    return re.sub(r'[^a-z]', '', r) or '?'

def raw(w):
    return re.sub(r'\s+', '', unicodedata.normalize('NFC', w.lower()))

# coarse articulatory features for romanized letters (NETtalk used
# articulatory output features; here they are used on the input side)
VOW = set('aeiouy')
FEAT = {  # place / manner / voicing
 'p':'lab stop -v','b':'lab stop +v','m':'lab nas +v','f':'lab fric -v','v':'lab fric +v','w':'lab appr +v',
 't':'alv stop -v','d':'alv stop +v','n':'alv nas +v','s':'alv fric -v','z':'alv fric +v','l':'alv liq +v',
 'r':'alv liq +v','c':'pal fric -v','j':'pal fric +v','x':'vel fric -v','k':'vel stop -v','g':'vel stop +v',
 'q':'vel stop -v','h':'glot fric -v',
 'a':'low back +v','e':'mid front +v','i':'high front +v','o':'mid back +v','u':'high back +v','y':'high front +v'}
FNAMES = sorted({t for v in FEAT.values() for t in v.split()} | {'vowel', 'bound'})
ALPHA = 'abcdefghijklmnopqrstuvwxyz'

def phon_vec(ch):
    v = np.zeros(len(FNAMES))
    if ch == '_':
        v[FNAMES.index('bound')] = 1; return v
    for t in FEAT.get(ch, '').split():
        v[FNAMES.index(t)] = 1
    if ch in VOW:
        v[FNAMES.index('vowel')] = 1
    return v

def skeleton(s):
    """Consonant skeleton: vowels vary most across transliterations."""
    k = re.sub(r'[aeiouy]', '', s)
    return k if k else s

# ------------------------------------------------------- n-gram prototype
def ngrams(s, n=(1, 2, 3)):
    s = f'_{s}_'
    return [s[i:i + k] for k in n for i in range(len(s) - k + 1)]

class NgramKNN:
    """Cosine kNN over character n-gram counts (strong classical baseline)."""
    def __init__(self, enc, n=(1, 2, 3)):
        self.enc, self.n = enc, n
    def _vec(self, ws):
        rows = []
        for w in ws:
            d = {}
            for g in ngrams(self.enc(w), self.n):
                j = self.voc.get(g)
                if j is not None:
                    d[j] = d.get(j, 0) + 1
            rows.append(d)
        M = np.zeros((len(ws), len(self.voc)))
        for i, d in enumerate(rows):
            for j, c in d.items():
                M[i, j] = c
        M /= np.linalg.norm(M, axis=1, keepdims=True) + 1e-9
        return M
    def fit(self, words, y, C):
        self.voc = {}
        for w in words:
            for g in ngrams(self.enc(w), self.n):
                self.voc.setdefault(g, len(self.voc))
        self.X, self.y, self.C = self._vec(words), np.asarray(y), C
        return self
    def add(self, words, y):
        self.X = np.vstack([self.X, self._vec(words)]); self.y = np.r_[self.y, y]
    def scores(self, words):
        S = self._vec(words) @ self.X.T
        out = np.full((len(words), self.C), 0.0)
        for c in range(self.C):
            m = self.y == c
            if m.any():
                out[:, c] = S[:, m].max(1)
        return out

class EditNN:
    """Nearest neighbour under normalised Levenshtein distance."""
    def __init__(self, enc): self.enc = enc
    def fit(self, words, y, C):
        self.W = [self.enc(w) for w in words]; self.y = np.asarray(y); self.C = C; return self
    def add(self, words, y):
        self.W += [self.enc(w) for w in words]; self.y = np.r_[self.y, y]
    @staticmethod
    def lev(a, b):
        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            cur = [i]
            for j, cb in enumerate(b, 1):
                cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
            prev = cur
        return prev[-1]
    def scores(self, words):
        out = np.full((len(words), self.C), -1.0)
        for i, w in enumerate(words):
            q = self.enc(w)
            for t, c in zip(self.W, self.y):
                s = 1 - self.lev(q, t) / max(len(q), len(t))
                if s > out[i, c]:
                    out[i, c] = s
        return out

# ------------------------------------------------------- NETtalk window net
class WindowNet:
    """NETtalk-style network: a (2h+1)-character window slides over the word;
    each window -> sigmoid hidden layer -> concept logits; the word decision
    is the mean of window logits (multiple-instance pooling).

    mode='raw'  : one-hot over the training Unicode alphabet (original NETtalk input)
    mode='phon' : romanized letter one-hot + articulatory features (+ skeleton channel)
    """
    def __init__(self, mode='phon', half=3, hidden=96, epochs=60, lr=3e-3,
                 noise=0.1, seed=0, wd=1e-4):
        self.mode, self.h, self.H, self.E = mode, half, hidden, epochs
        self.lr, self.noise, self.seed, self.wd = lr, noise, seed, wd

    # -- per-character integer codes; T maps code -> input feature vector
    def _codes(self, w):
        if self.mode == 'raw':
            s = raw(w)
            return [self.cmap.get(ch, self.cmap['?']) for ch in s]
        return [self.cmap.get(ch, self.cmap['?']) for ch in romanize(w)]

    def _augment(self, cs, rng):
        out = []
        for ch in cs:                                   # character-level augmentation
            r = rng.random()
            if r < self.noise / 3: continue                             # deletion
            if r < 2 * self.noise / 3: out.append(int(rng.integers(self.nreal))); continue
            out.append(ch)
            if r < self.noise: out.append(int(rng.integers(self.nreal)))  # insertion
        return out or cs

    def _win_idx(self, cs):
        """(L, 2h+1) code matrix for one word, padded with the boundary code."""
        p = [self.pad] * self.h
        a = np.array(p + list(cs) + p)
        L = len(cs)
        return np.stack([a[i:i + L] for i in range(2 * self.h + 1)], 1)

    def _pre(self, I):
        """Hidden pre-activation for window code matrix I (N, S)."""
        A = np.zeros((len(I), self.H)) + self.b1
        for s in range(I.shape[1]):
            A += self.E[s][I[:, s]]
        return A

    def _refresh(self):
        W1r = self.W1.reshape(2 * self.h + 1, self.D1, self.H)
        self.E = W1r if self.T is None else np.einsum('vd,sdh->svh', self.T, W1r)

    def fit(self, words, y, C):
        rng = np.random.default_rng(self.seed)
        if self.mode == 'raw':
            chars = sorted({c for w in words for c in raw(w)})
            self.cmap = {c: i for i, c in enumerate(chars)}
            self.nreal = len(chars); self.cmap['?'] = len(chars); self.pad = len(chars) + 1
            self.D1 = len(chars) + 2; self.T = None
        else:
            self.cmap = {c: i for i, c in enumerate(ALPHA)}
            self.nreal = 26; self.cmap['?'] = 26; self.pad = 27
            self.D1 = 26 + len(FNAMES)
            self.T = np.zeros((28, self.D1))
            for i, ch in enumerate(ALPHA):
                self.T[i, i] = 1; self.T[i, 26:] = phon_vec(ch)
            self.T[27, 26:] = phon_vec('_')
        S = 2 * self.h + 1; D = S * self.D1; self.C = C
        self.W1 = rng.normal(0, 1 / np.sqrt(S * (1 if self.T is None else 4)), (D, self.H)); self.b1 = np.zeros(self.H)
        self.W2 = rng.normal(0, 1 / np.sqrt(self.H), (self.H, C)); self.b2 = np.zeros(C)
        P = [self.W1, self.b1, self.W2, self.b2]
        m = [np.zeros_like(p) for p in P]; v = [np.zeros_like(p) for p in P]; t = 0
        y = np.asarray(y); B = 32
        codes = [self._codes(w) for w in words]
        for ep in range(self.E):
            for idx in np.array_split(rng.permutation(len(words)), max(1, len(words) // B)):
                Is = [self._win_idx(self._augment(codes[i], rng) if self.noise > 0 else codes[i]) for i in idx]
                seg = np.repeat(np.arange(len(idx)), [len(x) for x in Is])
                I = np.vstack(Is); n = np.bincount(seg).astype(float)
                self._refresh()
                Hh = 1 / (1 + np.exp(-self._pre(I)))
                Z = Hh @ self.W2 + self.b2
                Zw = np.zeros((len(idx), C)); np.add.at(Zw, seg, Z); Zw /= n[:, None]
                Pw = np.exp(Zw - Zw.max(1, keepdims=True)); Pw /= Pw.sum(1, keepdims=True)
                G = Pw.copy(); G[np.arange(len(idx)), y[idx]] -= 1; G /= len(idx)
                Gz = G[seg] / n[seg][:, None]
                gW2 = Hh.T @ Gz + self.wd * self.W2; gb2 = Gz.sum(0)
                Gh = Gz @ self.W2.T * Hh * (1 - Hh)
                gE = np.zeros((S, self.T.shape[0] if self.T is not None else self.D1, self.H))
                for s_ in range(S):
                    np.add.at(gE[s_], I[:, s_], Gh)
                gW1r = gE if self.T is None else np.einsum('vd,svh->sdh', self.T, gE)
                gW1 = gW1r.reshape(D, self.H) + self.wd * self.W1; gb1 = Gh.sum(0)
                t += 1
                for k, (p, g) in enumerate(zip(P, [gW1, gb1, gW2, gb2])):
                    m[k] = .9 * m[k] + .1 * g; v[k] = .999 * v[k] + .001 * g * g
                    p -= self.lr * (m[k] / (1 - .9 ** t)) / (np.sqrt(v[k] / (1 - .999 ** t)) + 1e-8)
        self._refresh()
        return self

    def _hidden(self, w):
        return 1 / (1 + np.exp(-self._pre(self._win_idx(self._codes(w) or [self.cmap['?']]))))

    def embed(self, words):
        """Mean hidden activation = word embedding (used for memory / few-shot)."""
        return np.array([self._hidden(w).mean(0) for w in words])

    def scores(self, words):
        out = []
        for w in words:
            z = (self._hidden(w) @ self.W2 + self.b2).mean(0)
            z = np.exp(z - z.max()); out.append(z / z.sum())
        return np.array(out)

# ------------------------------------------------------------ PolyNET
class PolyNET:
    """Proposed model. Fuses three script-invariant views:
       (i) phonological window network (NETtalk-style, trained),
       (ii) romanized n-gram prototype memory,
       (iii) consonant-skeleton n-gram prototype memory.
    Scores are converted to per-view posteriors with a temperature softmax
    and combined by a product of experts (log-linear fusion).
    New words heard at run time are written into the memories (few-shot).
    """
    def __init__(self, temps=(1.0, 0.05, 0.05), weights=(1.0, 1.0, 0.5), use_net=True,
                 use_rom=True, use_skel=True, net_kw=None, seed=0):
        self.T, self.w = temps, weights
        self.use = (use_net, use_rom, use_skel)
        self.net_kw = dict(net_kw or {}); self.net_kw.setdefault('seed', seed)
    def fit(self, words, y, C):
        self.C = C
        if self.use[0]: self.net = WindowNet(mode='phon', **self.net_kw).fit(words, y, C)
        if self.use[1]: self.rom = NgramKNN(romanize).fit(words, y, C)
        if self.use[2]: self.skl = NgramKNN(lambda w: skeleton(romanize(w)), n=(1, 2)).fit(words, y, C)
        return self
    def add(self, words, y):
        if self.use[1]: self.rom.add(words, y)
        if self.use[2]: self.skl.add(words, y)
    def scores(self, words):
        L = np.zeros((len(words), self.C))
        if self.use[0]: L += self.w[0] * np.log(self.net.scores(words) + 1e-9) / self.T[0]
        for k, mem in ((1, 'rom'), (2, 'skl')):
            if self.use[k]:
                L += self.w[k] * getattr(self, mem).scores(words) / self.T[k]
        L -= L.max(1, keepdims=True); P = np.exp(L); return P / P.sum(1, keepdims=True)

# ------------------------------------------- articulatory-weighted edit distance
def _sub_cost(a, b):
    if a == b: return 0.0
    va, vb = a in VOW, b in VOW
    if va and vb: return 0.3                       # vowel quality varies most
    if va != vb: return 1.0
    fa, fb = set(FEAT.get(a, '').split()), set(FEAT.get(b, '').split())
    return 1.0 - len(fa & fb) / 3.0 * 0.8          # share place/manner/voicing -> cheaper

_SUB = {(a, b): _sub_cost(a, b) for a in ALPHA for b in ALPHA}
def _indel(c): return 0.5 if c in VOW else 1.0

def awed(a, b):
    prev = [0.0]
    for cb in b: prev.append(prev[-1] + _indel(cb))
    for ca in a:
        cur = [prev[0] + _indel(ca)]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + _indel(ca), cur[j - 1] + _indel(cb),
                           prev[j - 1] + _SUB.get((ca, cb), 1.0)))
        prev = cur
    return prev[-1]

class AWEDNN(EditNN):
    """Nearest neighbour under articulatory-weighted edit distance on romanized forms."""
    def __init__(self): super().__init__(romanize)
    def scores(self, words):
        out = np.full((len(words), self.C), -1.0)
        for i, w in enumerate(words):
            q = self.enc(w)
            for t, c in zip(self.W, self.y):
                s = 1 - awed(q, t) / max(sum(map(_indel, q)), sum(map(_indel, t)))
                if s > out[i, c]: out[i, c] = s
        return out

class PolyNET2(PolyNET):
    """PolyNET with the AWED view; views = (net, rom-ngram, skeleton-ngram, awed)."""
    def __init__(self, weights=(1.0, 1.0, 0.5, 1.0), temps=(1.0, .05, .05, .05),
                 use=(True, True, True, True), net_kw=None, seed=0):
        self.w, self.T, self.use = weights, temps, use
        self.net_kw = dict(net_kw or {}); self.net_kw.setdefault('seed', seed)
    def fit(self, words, y, C):
        self.C = C
        self.views = {}
        if self.use[0]: self.views[0] = WindowNet(mode='phon', **self.net_kw).fit(words, y, C)
        if self.use[1]: self.views[1] = NgramKNN(romanize).fit(words, y, C)
        if self.use[2]: self.views[2] = NgramKNN(lambda w: skeleton(romanize(w)), n=(1, 2)).fit(words, y, C)
        if self.use[3]: self.views[3] = AWEDNN().fit(words, y, C)
        return self
    def add(self, words, y):
        for k, v in self.views.items():
            if k: v.add(words, y)
    def view_scores(self, words):
        S = {}
        for k, v in self.views.items():
            S[k] = np.log(v.scores(words) + 1e-9) if k == 0 else v.scores(words)
        return S
    def fuse(self, S, w=None, T=None):
        w, T = w or self.w, T or self.T
        L = sum(w[k] * S[k] / T[k] for k in S)
        L = L - L.max(1, keepdims=True); P = np.exp(L); return P / P.sum(1, keepdims=True)
    def scores(self, words):
        return self.fuse(self.view_scores(words))

def mutual_exclusivity(P):
    """Transductive decoding: words heard in one session from one speaker name
    distinct concepts (mutual-exclusivity bias). Solve the assignment that
    maximises total log-posterior subject to one word per concept."""
    from scipy.optimize import linear_sum_assignment
    r, c = linear_sum_assignment(-np.log(P + 1e-12))
    out = P.argmax(1).copy(); out[r] = c
    return out
