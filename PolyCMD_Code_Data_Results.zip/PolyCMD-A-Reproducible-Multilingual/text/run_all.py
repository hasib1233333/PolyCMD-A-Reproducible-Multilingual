"""All experiments, leave-one-language-out over the 34 held-out test languages.
Usage: python3 run_all.py <lang> [<lang> ...]   -> results/fold_<lang>.json
"""
import sys, json, time, numpy as np
from common import *
from models import *

TUNE = json.load(open('results/tuned.json')); W = tuple(TUNE['weights']); T = TUNE['T']; TS = (1, T, T, T)
SEEDS = [0, 1, 2]
NOISE = [0.0, 0.05, 0.1, 0.2, 0.3]

def corrupt(w, p, rng):
    """Character noise on the original Unicode string (typing / recognition errors)."""
    s = list(w.replace(' ', ''))
    if p == 0 or len(s) < 2: return w
    out = []
    for i, ch in enumerate(s):
        r = rng.random()
        if r < p / 3: continue                                   # deletion
        if r < 2 * p / 3: out.append(s[rng.integers(len(s))]); continue   # substitution (same script)
        out.append(ch)
        if r < p: out.append(ch)                                 # duplication
    return ''.join(out) or w

def acc(pred, y): return float((np.asarray(pred) == y).mean())

def auroc(pos, neg):
    pos, neg = np.asarray(pos), np.asarray(neg)
    return float(((pos[:, None] > neg[None]).mean() + .5 * (pos[:, None] == neg[None]).mean()))

def run(L):
    t0 = time.time()
    Wtr, ytr, Wte, yte, te = split(L)
    cats = [r['category'] for r in te]
    dis = [d['word'] for d in DIS if d['lang'] == L]
    out = {'lang': L, 'n': len(Wte), 'cats': cats, 'y': yte.tolist(),
           'script': te[0]['script'], 'family': te[0]['family']}

    # ------------------------------------------------ baselines (deterministic)
    base = {'knn_raw': NgramKNN(raw), 'knn_rom': NgramKNN(romanize),
            'edit_raw': EditNN(raw), 'edit_rom': EditNN(romanize), 'awed': AWEDNN()}
    preds, probs = {}, {}
    for k, m in base.items():
        m.fit(Wtr, ytr, C); S = m.scores(Wte); P = softmax_sim(S, T)
        preds[k] = S.argmax(1); probs[k] = P
        preds[k + '+ME'] = mutual_exclusivity(P)
        out.setdefault('open', {})[k] = auroc(S.max(1), m.scores(dis).max(1)) if dis else None
    # NETtalk original (raw Unicode window net), and phonological window net
    raw_nets = [WindowNet('raw', epochs=60, seed=s).fit(Wtr, ytr, C) for s in SEEDS]
    Ps = [n.scores(Wte) for n in raw_nets]
    out.setdefault('seed_acc', {})['nettalk_raw'] = [acc(P.argmax(1), yte) for P in Ps]
    preds['nettalk_raw'] = Ps[0].argmax(1); preds['nettalk_raw+ME'] = mutual_exclusivity(Ps[0])

    # ------------------------------------------------ PolyNET (3 seeds)
    polys = [PolyNET2(W, TS, net_kw=dict(epochs=60), seed=s).fit(Wtr, ytr, C) for s in SEEDS]
    Ss = [p.view_scores(Wte) for p in polys]
    Pp = [p.fuse(S) for p, S in zip(polys, Ss)]
    out['seed_acc']['polynet'] = [acc(P.argmax(1), yte) for P in Pp]
    out['seed_acc']['polynet+ME'] = [acc(mutual_exclusivity(P), yte) for P in Pp]
    # the phonological window net alone is PolyNET's view 0 (same seeds, same training)
    Pn = [np.exp(S[0]) for S in Ss]
    out['seed_acc']['net_phon'] = [acc(P_.argmax(1), yte) for P_ in Pn]
    preds['net_phon'] = Pn[0].argmax(1); preds['net_phon+ME'] = mutual_exclusivity(Pn[0])
    P = Pp[0]; poly = polys[0]; S0 = Ss[0]
    preds['polynet'] = P.argmax(1); preds['polynet+ME'] = mutual_exclusivity(P)
    # ablations (seed 0)
    abl = {'-net': (0, W[1], W[2], W[3]), '-rom': (W[0], 0, W[2], W[3]), '-skel': (W[0], W[1], 0, W[3]),
           '-awed': (W[0], W[1], W[2], 0), 'net only': (1, 0, 0, 0), 'awed only': (0, 0, 0, 1)}
    for k, w in abl.items():
        Pa = poly.fuse(S0, w)
        preds['abl ' + k] = Pa.argmax(1); preds['abl ' + k + '+ME'] = mutual_exclusivity(Pa)
    out['acc'] = {k: acc(v, yte) for k, v in preds.items()}
    out['pred'] = {k: np.asarray(v).tolist() for k, v in preds.items()}
    Pd = poly.scores(dis) if dis else None
    # open-set: un-normalised fused score (energy-style), see open_energy.py
    def _energy(words):
        S = poly.view_scores(words); Lg = sum(W[k] * S[k] / TS[k] for k in S)
        mx = Lg.max(1); return mx + np.log(np.exp(Lg - mx[:, None]).sum(1))
    json.dump({'pos': _energy(Wte).tolist(), 'neg': _energy(dis).tolist() if dis else []},
              open(f'results/energy_{L}.json', 'w'))
    out['open']['polynet'] = auroc(P.max(1), Pd.max(1)) if dis else None

    # ------------------------------------------------ session size (mutual exclusivity)
    rng = np.random.default_rng(0); sess = {}
    for k in [1, 2, 4, 8, 16, 32, len(Wte)]:
        a = []
        for _ in range(40 if k < len(Wte) else 1):
            idx = rng.choice(len(Wte), min(k, len(Wte)), replace=False)
            a.append(acc(mutual_exclusivity(P[idx]), yte[idx]))
        sess[str(min(k, len(Wte)))] = float(np.mean(a))
    out['session'] = sess

    # ------------------------------------------------ few-shot: k demonstrated words
    fs = {}
    for k in [0, 1, 2, 5, 10, 20]:
        ai, am = [], []
        for rep in range(5):
            r2 = np.random.default_rng(rep); idx = r2.permutation(len(Wte))
            sh, q = idx[:k], idx[k:]
            m = PolyNET2(W, TS); m.C = C; m.views = dict(poly.views)
            m.views = {kk: (v if kk == 0 else type(v).__new__(type(v))) for kk, v in poly.views.items()}
            for kk in (1, 2, 3):   # shallow-copy memories so the base model is untouched
                m.views[kk].__dict__ = {a_: (b_.copy() if hasattr(b_, 'copy') else b_)
                                        for a_, b_ in poly.views[kk].__dict__.items()}
            if k: m.add([Wte[i] for i in sh], yte[sh])
            Pq = m.scores([Wte[i] for i in q])
            ai.append(acc(Pq.argmax(1), yte[q]))
            Pm = Pq.copy(); Pm[:, yte[sh]] = 1e-12        # demonstrated concepts are taken
            am.append(acc(mutual_exclusivity(Pm), yte[q]))
        fs[str(k)] = (float(np.mean(ai)), float(np.mean(am)))
    out['fewshot'] = fs

    # ------------------------------------------------ noise robustness
    nz = {}
    edit_rom, knn_raw = base['edit_rom'], base['knn_raw']
    net_raw = raw_nets[0]
    for p in NOISE:
        r3 = np.random.default_rng(7); Wn = [corrupt(w, p, r3) for w in Wte]
        Pn = poly.scores(Wn); Pe = softmax_sim(edit_rom.scores(Wn), T)
        nz[str(p)] = {'polynet': acc(Pn.argmax(1), yte), 'polynet+ME': acc(mutual_exclusivity(Pn), yte),
                      'edit_rom': acc(Pe.argmax(1), yte), 'edit_rom+ME': acc(mutual_exclusivity(Pe), yte),
                      'knn_raw': acc(knn_raw.scores(Wn).argmax(1), yte),
                      'nettalk_raw': acc(net_raw.scores(Wn).argmax(1), yte)}
    out['noise'] = nz

    # ------------------------------------------------ open-set scores for ROC plot
    out['open_scores'] = {'pos': P.max(1).tolist(), 'neg': Pd.max(1).tolist() if dis else []}
    out['time_s'] = time.time() - t0
    json.dump(out, open(f'results/fold_{L}.json', 'w'))
    print(L, f"{out['acc']['polynet+ME']:.3f}", f"{out['time_s']:.0f}s", flush=True)

if __name__ == '__main__':
    for L in sys.argv[1:]:
        run(L)
